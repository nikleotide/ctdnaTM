library(testthat)
library(ctdnaTM)

test_that("config: defaults, get, set, reset", {
  ctdna_opts(.reset = TRUE)
  expect_equal(ctdna_opts("tf"), "methylTF")
  ctdna_opts(tf = "TF_X", display_floor = 0.005)
  expect_equal(ctdna_opts("tf"), "TF_X")
  expect_equal(ctdna_opts("display_floor"), 0.005)
  ctdna_opts(.reset = TRUE)
  expect_equal(ctdna_opts("tf"), "methylTF")
  expect_equal(ctdna_opts("display_floor"), 0.001)
})

test_that("config: unknown key errors", {
  expect_error(ctdna_opts(nope = 1), "Unknown key")
  expect_error(ctdna_opts("nope"), "Unknown key")
})

test_that("helpers: ctdna_floor_tf and ctdna_stratify_recist", {
  expect_equal(ctdna_floor_tf(c(0, 0.0005, 0.01)), c(0.001, 0.001, 0.01))
  expect_equal(as.character(ctdna_stratify_recist(c("CR","SD"), "two")), c("R","NR"))
  expect_equal(as.character(ctdna_stratify_recist(c("CR","uPR","SD","PD"), "three")),
               c("CR/PR","uCR/PR","SD/PD/NE/NA","SD/PD/NE/NA"))
})

test_that("data generators return canonical columns", {
  ctdna_opts(.reset = TRUE)
  d <- ctdna_make_example_multimodal(n_subjects = 10)$ctdna
  expect_true(all(c("subject_id","time_point","dose","RECIST","methylTF","maxAF",
                    "best_pct_change","MR") %in% names(d)))
  mm <- ctdna_make_example_multimodal(n_subjects = 10)
  expect_named(mm, c("ctdna","genomic_74","genomic_500","expression","tmb","ihc"))
  expect_true(all(c("panel","alteration_type","mutation_status","vaf") %in%
                  names(mm$genomic_74)))
  expect_true(all(c("panel","alteration_type","mutation_status","vaf") %in%
                  names(mm$genomic_500)))
  # 500-gene panel is a strict superset of 74
  expect_true(all(unique(mm$genomic_74$gene) %in% unique(mm$genomic_500$gene)))
  expect_true(length(unique(mm$genomic_500$gene)) >
              length(unique(mm$genomic_74$gene)))
  # platform attribute set
  expect_equal(attr(mm, "platform"), "guardant_health_infinity")
})

test_that("make_example_* honor renamed ctdna_opts() columns", {
  ctdna_opts(tf = "TF_methyl_v3", subject = "patient_id")
  d <- ctdna_make_example_multimodal(n_subjects = 5)$ctdna
  expect_true("TF_methyl_v3" %in% names(d))
  expect_true("patient_id" %in% names(d))
  expect_false("methylTF" %in% names(d))
  expect_false("subject_id" %in% names(d))
  mm <- ctdna_make_example_multimodal(n_subjects = 5)
  expect_true("TF_methyl_v3" %in% names(mm$ctdna))
  expect_true("patient_id" %in% names(mm$genomic_74))
  ctdna_opts(.reset = TRUE)
})

test_that("ctdna_ratio adds baseline_tf and ratio", {
  r <- ctdna_ratio(ctdna_make_example_multimodal(n_subjects = 10)$ctdna)
  expect_true(all(c("baseline_tf","ratio") %in% names(r)))
  expect_true(all(r$baseline_tf > 0))
})

test_that("ctdna_summary returns one row per subject", {
  d <- ctdna_make_example_multimodal(n_subjects = 15)$ctdna
  s <- ctdna_summary(d)
  expect_equal(nrow(s), 15)
  expect_true(all(c("baseline_tf","best_ratio","last_tf") %in% names(s)))
})

test_that("ctdna_assemble_modalities accepts genomic_74/genomic_500", {
  mm <- ctdna_make_example_multimodal(n_subjects = 10)
  ok <- ctdna_assemble_modalities(ctdna = mm$ctdna,
                            genomic_74 = mm$genomic_74,
                            genomic_500 = mm$genomic_500,
                            tmb = mm$tmb)
  expect_named(ok, c("ctdna","genomic_74","genomic_500","tmb"))

  # Missing column triggers error under strict=TRUE
  bad <- mm$tmb; names(bad)[names(bad) == "tmb"] <- "tmb_v2"
  expect_error(ctdna_assemble_modalities(tmb = bad), "missing required column")
  expect_warning(ctdna_assemble_modalities(tmb = bad, strict = FALSE), "missing required column")
})

test_that("ctdna_platforms() lists at least GH Infinity", {
  pf <- ctdna_platforms()
  expect_s3_class(pf, "data.frame")
  expect_true("guardant_health_infinity" %in% pf$platform)
})

test_that("ctdna_prepare() with GH Infinity vendor data: full pipeline", {
  sim <- ctdna_make_mock_study(n_patients = 10)
  prepped <- suppressMessages(ctdna_prepare(
    infinity_report    = sim$infinity_report,
    tf_change          = sim$tf_change,
    panel_74_response  = sim$panel_74_response,
    panel_500_response = sim$panel_500_response,
    clinical           = sim$clinical,
    verbose            = FALSE
  ))
  expect_true("ctdna" %in% names(prepped))
  expect_true("genomic_74" %in% names(prepped))
  expect_true("genomic_500" %in% names(prepped))
  expect_equal(attr(prepped, "platform"), "guardant_health_infinity")

  # ctdna long-format has one row per (subject_id × time_point)
  expect_true(all(c("subject_id", "time_point", "methylTF",
                    "RECIST", "best_pct_change") %in%
                    names(prepped$ctdna)))
  # TF should be in fraction units (0-1, not percentage)
  expect_true(all(prepped$ctdna$methylTF <= 1, na.rm = TRUE))

  # genomic frames have detected + wt rows
  expect_true(all(c("subject_id", "gene", "mutation_status",
                    "alteration_type", "panel") %in%
                    names(prepped$genomic_74)))
  expect_true("wt"  %in% prepped$genomic_74$mutation_status)
  expect_true("mut" %in% prepped$genomic_74$mutation_status ||
              nrow(prepped$genomic_74) == 0)
})

test_that("ctdna_prepare() rejects unsupported platform", {
  expect_error(ctdna_prepare(vendor = "bogus", technology = "x"),
               "not registered")
})

test_that("ctdna_prepare() filters MR_QC_status != PASS rows", {
  sim <- ctdna_make_mock_study(n_patients = 10)
  tfc <- sim$tf_change
  # Force every 3rd row to FAIL
  tfc$MR_QC_status <- ifelse(seq_len(nrow(tfc)) %% 3 == 0,
                              "FAIL", "PASS")
  n_pass_pairs <- sum(tfc$MR_QC_status == "PASS")

  prepped <- suppressMessages(ctdna_prepare(
    infinity_report = sim$infinity_report,
    tf_change       = tfc,
    clinical        = sim$clinical,
    qc_filter       = TRUE,
    verbose         = FALSE
  ))
  # PASS pairs unstacked → at most 2× pairs in long format,
  # deduplicated at baseline. Just verify it produced fewer rows than
  # unfiltered run.
  unfiltered <- suppressMessages(ctdna_prepare(
    infinity_report = sim$infinity_report,
    tf_change       = tfc,
    clinical        = sim$clinical,
    qc_filter       = FALSE,
    verbose         = FALSE
  ))
  expect_lt(nrow(prepped$ctdna), nrow(unfiltered$ctdna))
})

test_that("stats: ctdna_pval_label, ctdna_run_group_test, ctdna_cor_test, ctdna_paired_test, ctdna_cohen_kappa", {
  expect_equal(ctdna_pval_label(0.00001), "p<0.001")
  expect_match(ctdna_pval_label(0.04), "p=0\\.0[34][0-9]?")
  set.seed(1)
  d <- data.frame(v = c(rnorm(20, 0), rnorm(20, 0.5), rnorm(20, 1)),
                  g = rep(c("a","b","c"), each = 20))
  expect_equal(ctdna_run_group_test(d, "v", "g", "auto")$name, "Kruskal-Wallis")
  expect_equal(ctdna_run_group_test(d[d$g != "c", ], "v", "g", "auto")$name, "Wilcoxon")
  expect_equal(ctdna_run_group_test(d, "v", "g", "none")$method, "none")
  r <- ctdna_cor_test(1:10, c(2:11) + rnorm(10, 0, 0.1))
  expect_equal(r$name, "Spearman")
  expect_true(abs(r$rho) > 0.9)
  pt <- ctdna_paired_test(rnorm(20), rnorm(20, 0.5))
  expect_equal(pt$method, "paired_wilcox")
  expect_true(!is.na(pt$p))
  tab <- table(a = c("R","NR","R","R"), b = c("R","NR","R","NR"))
  expect_true(is.numeric(ctdna_cohen_kappa(tab)))
})

test_that("plots accept a stat argument and return ggplot", {
  d <- ctdna_make_example_multimodal(n_subjects = 30)$ctdna
  expect_s3_class(ctdna_plot_baseline(d[d$time_point == "Baseline", ], stat = "wilcox"), "ggplot")
  expect_s3_class(ctdna_plot_baseline(d[d$time_point == "Baseline", ], stat = "auto"), "ggplot")
  expect_s3_class(ctdna_plot_baseline_dose_recist(d[d$time_point == "Baseline", ], stat = "t"), "ggplot")
  expect_s3_class(ctdna_plot_reduction(d, scheme = "three", stat = "wilcox"), "ggplot")
  expect_s3_class(ctdna_plot_longitudinal(d, stat = "paired_wilcox"), "ggplot")
  expect_s3_class(ctdna_plot_longitudinal_recist(d, stat = "kruskal"), "ggplot")
  expect_s3_class(ctdna_plot_reduction_vs_tumor(d, stat = "spearman"), "ggplot")
  expect_s3_class(ctdna_plot_mut_methyl(d[d$time_point == "Baseline", ], stat = "spearman"), "ggplot")

  mr <- ctdna_plot_mr_recist(d, mr_timepoint = "use_column", stat = "both")
  expect_s3_class(mr$plot, "ggplot")
  expect_true(is.numeric(mr$kappa))
})

test_that("multi-modal plots work with genomic_74 / genomic_500", {
  mm <- ctdna_make_example_multimodal(n_subjects = 30)
  expect_s3_class(ctdna_plot_vs_expression(mm$ctdna, mm$expression, "CD8A", stat = "spearman"), "ggplot")
  expect_s3_class(ctdna_plot_vs_mutation(mm$ctdna, mm$genomic_74, "TP53",
                                          panel = "74genes", stat = "wilcox"), "ggplot")
  # New: stratify by alteration_type (multi-state)
  expect_s3_class(ctdna_plot_vs_mutation(mm$ctdna, mm$genomic_74, "TP53",
                                          panel = "74genes",
                                          by = "alteration_type",
                                          stat = "kruskal"), "ggplot")
  expect_s3_class(ctdna_plot_vs_tmb(mm$ctdna, mm$tmb, panel = "74genes", stat = "spearman"), "ggplot")
  expect_s3_class(ctdna_plot_vs_ihc(mm$ctdna, mm$ihc, "PDL1", stat = "spearman"), "ggplot")
  # Mutation concordance: 74-gene vs 500-gene panels
  combined <- rbind(mm$genomic_74, mm$genomic_500)
  mc <- ctdna_mutation_concordance(combined, "74genes", "500genes", stat = "both")
  expect_s3_class(mc$plot, "ggplot")
  expect_true(is.numeric(mc$kappa))
})

test_that("invalid stat is rejected", {
  d <- ctdna_make_example_multimodal(n_subjects = 10)$ctdna
  expect_error(ctdna_plot_baseline(d[d$time_point == "Baseline", ], stat = "bogus"))
  expect_error(ctdna_plot_reduction(d, stat = "kendall"), "should be one of")  # not allowed for reduction
})

test_that("colors and theme return expected types", {
  cc <- ctdna_colors()
  expect_true(is.character(cc) && !is.null(names(cc)))
  expect_equal(length(ctdna_dose_palette(5)), 5)
  expect_s3_class(ctdna_theme(), "theme")
})

# -------- ctdna_make_mock_study() --------------------------------------------------
test_that("ctdna_make_mock_study produces all 8 outputs with correct GH column counts", {
  sim <- ctdna_make_mock_study(n_patients = 10)
  expect_named(sim, c("infinity_report", "tf_change",
                      "panel_74_response", "panel_500_response",
                      "methylation_response", "clinical", "ihc", "wes",
                      "rnaseq"))

  # Exact GH Infinity column counts
  expect_equal(ncol(sim$infinity_report),      56)
  expect_equal(ncol(sim$tf_change),            27)
  expect_equal(ncol(sim$panel_74_response),    28)
  expect_equal(ncol(sim$panel_500_response),   28)
  expect_equal(ncol(sim$methylation_response), 23)

  # MR_panel values per file
  expect_true(all(sim$tf_change$MR_panel             == "TF.methyl"))
  expect_true(all(sim$panel_74_response$MR_panel     == "74genes"))
  expect_true(all(sim$panel_500_response$MR_panel    == "500genes"))
  expect_true(all(sim$methylation_response$MR_panel  == "legacy.methyl"))

  # Cross-data Patient_ID consistency: same 10 patients across all frames
  pid_inf <- unique(sim$infinity_report$Patient_ID)
  pid_rna <- unique(sim$rnaseq$sample_metadata$Patient_ID)
  pid_wes <- unique(sim$wes$Patient_ID)
  pid_ihc <- unique(sim$ihc$Patient_ID)
  expect_setequal(pid_inf, pid_rna)
  expect_setequal(pid_inf, pid_wes)
  expect_setequal(pid_inf, pid_ihc)
  expect_equal(length(pid_inf), 10)

  # Visit_A == "C1D1" everywhere; Visit_B always later
  expect_true(all(sim$tf_change$Visit_name_A == "C1D1"))
  expect_true(all(sim$tf_change$Bloodcoll_date_B > sim$tf_change$Bloodcoll_date_A))

  # RNA-seq sublist shape
  expect_named(sim$rnaseq, c("counts", "tpm", "sample_metadata"))
  expect_true(is.matrix(sim$rnaseq$counts))
  expect_true(is.matrix(sim$rnaseq$tpm))
  expect_equal(dim(sim$rnaseq$counts), dim(sim$rnaseq$tpm))
  expect_equal(ncol(sim$rnaseq$counts), nrow(sim$rnaseq$sample_metadata))

  # Platform attribute
  expect_equal(attr(sim, "platform"), "guardant_health_infinity")
})

# -------- ctdna_compute_mr() -------------------------------------------------------
test_that("ctdna_compute_mr computes best-ratio and timepoint MR", {
  mm <- ctdna_make_example_multimodal(n_subjects = 20, seed = 1)
  best <- ctdna_compute_mr(mm$ctdna)
  expect_true(all(c("subject_id","baseline_tf","ratio","MR","time_used")
                  %in% names(best)))
  expect_true(all(best$MR %in% c("Response","NonResponse", NA)))
  expect_equal(unique(best$time_used), "best")

  tp <- ctdna_compute_mr(mm$ctdna, at = "C5D1")
  expect_equal(unique(tp$time_used), "C5D1")

  # Threshold parameter changes the MR call distribution
  strict <- ctdna_compute_mr(mm$ctdna, threshold = 0.1)
  # With a stricter threshold, fewer responders
  expect_lte(sum(strict$MR == "Response", na.rm = TRUE),
             sum(best$MR == "Response", na.rm = TRUE))

  # Unknown timepoint errors
  expect_error(ctdna_compute_mr(mm$ctdna, at = "Z9D9"), "not found")
})

# -------- ctdna_filter_alterations() -----------------------------------------------
test_that("ctdna_filter_alterations works on vendor and canonical schemas", {
  sim <- ctdna_make_mock_study(n_patients = 15, seed = 1)

  # Vendor infinity_report — default filter shrinks rows
  f1 <- ctdna_filter_alterations(sim$infinity_report, verbose = FALSE)
  expect_lt(nrow(f1), nrow(sim$infinity_report))

  # FALSE disables a filter dimension
  f2 <- ctdna_filter_alterations(sim$infinity_report,
                            functional_impact = FALSE,
                            min_vaf = FALSE, verbose = FALSE)
  expect_gte(nrow(f2), nrow(f1))

  # WES has gnomAD_AF and KG_AF columns
  f3 <- ctdna_filter_alterations(sim$wes, verbose = FALSE)
  expect_true(all(f3$gnomAD_AF <= 0.01 | is.na(f3$gnomAD_AF)))

  # Canonical schema (mm$genomic_74) — alteration_type / mutation_status
  mm <- ctdna_make_example_multimodal(n_subjects = 15, seed = 1)
  f4 <- ctdna_filter_alterations(mm$genomic_74, verbose = FALSE)
  expect_true(all(f4$mutation_status != "wt"))

  # Missing column → skip silently (no error)
  expect_no_error(
    ctdna_filter_alterations(sim$infinity_report,
                       max_gnomad_af = 0.005, verbose = FALSE)
  )
})

# -------- ctdna_plot_oncoprint() ---------------------------------------------------
test_that("ctdna_plot_oncoprint accepts vendor, canonical, and gene-set inputs", {
  sim <- ctdna_make_mock_study(n_patients = 20, seed = 1)

  # Auto-genes with inline filter
  o1 <- ctdna_plot_oncoprint(sim$infinity_report,
                       filter = list(verbose = FALSE))
  expect_s3_class(o1, "ctdna_oncoprint")

  # Specific gene list
  o2 <- ctdna_plot_oncoprint(sim$infinity_report,
                       gene_sets = list(Selected = c("TP53","KRAS","EGFR")),
                       filter = list(verbose = FALSE))
  expect_s3_class(o2, "ctdna_oncoprint")

  # Pathway-grouped (named list -> facet)
  o3 <- ctdna_plot_oncoprint(sim$infinity_report,
                       gene_sets = list(
                         RTK = c("EGFR","ERBB2","MET"),
                         RAS = c("KRAS","NRAS","BRAF")),
                       filter = list(verbose = FALSE))
  expect_s3_class(o3, "ctdna_oncoprint")

  # Pre-filtered input, no filter_args
  pre <- ctdna_filter_alterations(sim$infinity_report, verbose = FALSE)
  o4 <- ctdna_plot_oncoprint(pre, gene_sets = list(Selected = c("TP53","KRAS")))
  expect_s3_class(o4, "ctdna_oncoprint")

  # WES input
  o5 <- ctdna_plot_oncoprint(sim$wes,
                       filter = list(verbose = FALSE))
  expect_s3_class(o5, "ctdna_oncoprint")
})

# -------- ctdna_plot_mr_recist with new args ---------------------------------------
test_that("ctdna_plot_mr_recist supports mr_timepoint and mr_threshold", {
  mm <- ctdna_make_example_multimodal(n_subjects = 30, seed = 1)
  p1 <- ctdna_plot_mr_recist(mm$ctdna)
  expect_s3_class(p1$plot, "ggplot")
  expect_match(p1$mr_source, "best")

  p2 <- ctdna_plot_mr_recist(mm$ctdna, mr_timepoint = "C5D1")
  expect_match(p2$mr_source, "C5D1")

  p3 <- ctdna_plot_mr_recist(mm$ctdna, mr_timepoint = "use_column")
  expect_match(p3$mr_source, "MR")

  # Different thresholds give different MR calls (one is stricter)
  p_strict <- ctdna_plot_mr_recist(mm$ctdna, mr_threshold = 0.1)
  expect_match(p_strict$mr_source, "0.1")
})

# -------- ctdna_opts(load = cfg) --------------------------------------------
test_that("ctdna_opts supports bulk loading via load=", {
  ctdna_opts(.reset = TRUE)
  # Configure
  ctdna_opts(tf = "TF_v3", display_floor = 5e-4)
  cfg <- ctdna_opts()

  # Reset and bulk-load
  ctdna_opts(.reset = TRUE)
  expect_equal(ctdna_opts("tf"), "methylTF")
  ctdna_opts(load = cfg)
  expect_equal(ctdna_opts("tf"), "TF_v3")
  expect_equal(ctdna_opts("display_floor"), 5e-4)

  # Bad key in load list errors out
  expect_error(ctdna_opts(load = list(bogus = 1)), "Unknown")
  # Non-list errors
  expect_error(ctdna_opts(load = "not a list"), "named list")

  ctdna_opts(.reset = TRUE)
})

# -------- legend_position threading -----------------------------------------
test_that("legend_position routes to ggplot theme", {
  mm <- ctdna_make_example_multimodal(n_subjects = 20, seed = 1)
  ctd <- mm$ctdna
  for (pos in c("right","left","top","bottom","none")) {
    p <- ctdna_plot_vs_tmb(ctd, mm$tmb, legend_position = pos)
    expect_equal(p$theme$legend.position, pos)
  }
  # Default falls back to ctdna_opts
  ctdna_opts(legend_position = "bottom")
  p <- ctdna_plot_vs_tmb(ctd, mm$tmb)
  expect_equal(p$theme$legend.position, "bottom")
  ctdna_opts(.reset = TRUE)
})

# -------- stat_position routing ---------------------------------------------
test_that("stat_position routes label to subtitle / caption / on_plot / none", {
  mm <- ctdna_make_example_multimodal(n_subjects = 20, seed = 1)
  ctd <- mm$ctdna

  # subtitle (default): label in subtitle, caption empty
  p_sub <- ctdna_plot_vs_tmb(ctd, mm$tmb, stat_position = "subtitle")
  expect_true(nzchar(p_sub$labels$subtitle))

  # caption: label in caption, subtitle empty
  p_cap <- ctdna_plot_vs_tmb(ctd, mm$tmb, stat_position = "caption")
  expect_true(is.null(p_cap$labels$subtitle) || !nzchar(p_cap$labels$subtitle))
  expect_true(nzchar(p_cap$labels$caption))

  # on_plot: label as a geom_text layer inside the panel
  p_op <- ctdna_plot_vs_tmb(ctd, mm$tmb, stat_position = "on_plot")
  layer_classes <- vapply(p_op$layers, function(l) class(l$geom)[1], character(1))
  expect_true("GeomCustomAnn" %in% layer_classes)

  # none: no stats anywhere
  p_none <- ctdna_plot_vs_tmb(ctd, mm$tmb, stat_position = "none")
  expect_true(is.null(p_none$labels$subtitle) || !nzchar(p_none$labels$subtitle))
})

# -------- ctdna_to_log2tpm -------------------------------------
test_that("ctdna_to_log2tpm converts TPM <-> log2(TPM+1)", {
  df <- data.frame(subject_id = c("S1","S2","S3"),
                   gene = c("A","B","C"),
                   expression = c(0, 5.4, 412),
                   stringsAsFactors = FALSE)
  attr(df, "units") <- "tpm"

  out <- suppressMessages(ctdna_to_log2tpm(df))
  expect_equal(attr(out, "units"), "log2_tpm_plus_one")
  expect_equal(out$expression, log2(c(0, 5.4, 412) + 1), tolerance = 1e-6)

  # Round trip: log2 -> tpm -> log2
  ctdna_opts(expression_unit = "tpm")
  back <- suppressMessages(ctdna_to_log2tpm(out))
  expect_equal(attr(back, "units"), "tpm")
  expect_equal(back$expression, c(0, 5.4, 412), tolerance = 1e-6)
  ctdna_opts(.reset = TRUE)

  # Auto-detect: large values -> TPM
  df_auto <- data.frame(subject_id = "S1", gene = "A", expression = 150)
  out_auto <- suppressMessages(ctdna_to_log2tpm(df_auto))
  expect_equal(attr(out_auto, "units"), "log2_tpm_plus_one")
  expect_lt(out_auto$expression, 10)  # converted

  # Auto-detect: small values -> already log2
  df_log <- data.frame(subject_id = "S1", gene = "A", expression = 5.0)
  out_log <- suppressMessages(ctdna_to_log2tpm(df_log))
  expect_equal(attr(out_log, "units"), "log2_tpm_plus_one")
  expect_equal(out_log$expression, 5.0)
})

test_that("ctdna_assemble_modalities canonicalizes expression unit", {
  # Build a TPM-shaped expression frame
  expr_tpm <- data.frame(subject_id = c("S001","S001","S002","S002"),
                         gene = c("A","B","A","B"),
                         expression = c(10, 200, 5, 50),
                         stringsAsFactors = FALSE)
  attr(expr_tpm, "units") <- "tpm"

  # Minimal ctdna frame so assemble validates
  mm <- ctdna_make_example_multimodal(n_subjects = 10, seed = 1)
  ctd <- mm$ctdna

  out <- suppressMessages(ctdna_assemble_modalities(
    ctdna = ctd, expression = expr_tpm))
  expect_equal(attr(out$expression, "units"), "log2_tpm_plus_one")
  # Values were converted
  expect_lt(max(out$expression$expression), 10)
})

# -------- ctdna_scale_dose_shape --------------------------------------------
test_that("ctdna_scale_dose_shape provides a shape scale", {
  s <- ctdna_scale_dose_shape()
  expect_s3_class(s, "ScaleDiscrete")
})

# -------- ctdna_table -------------------------------------------------------
test_that("ctdna_table renders a styled ggplot table", {
  tab <- as.data.frame(matrix(c(12, 3, 1, 9), 2, 2,
                              dimnames = list(MR = c("Response","NonResponse"),
                                              RECIST = c("CR/PR","SD/PD/NE"))))
  p <- ctdna_table(tab,
                    title    = "Test",
                    subtitle = "kappa = 0.62",
                    caption  = "Source: X",
                    highlight_diag = TRUE)
  expect_s3_class(p, "ggplot")
  expect_equal(p$labels$title,    "Test")
  expect_equal(p$labels$subtitle, "kappa = 0.62")
  expect_equal(p$labels$caption,  "Source: X")

  # Accepts data frame, matrix, table
  p2 <- ctdna_table(matrix(1:6, 2, 3))
  expect_s3_class(p2, "ggplot")

  p3 <- ctdna_table(table(letters[1:3], letters[1:3]))
  expect_s3_class(p3, "ggplot")
})

# -------- New oncoprint API -------------------------------------------------
test_that("ctdna_plot_oncoprint with named gene_sets and top_annotations", {
  sim <- ctdna_make_mock_study(n_patients = 20, seed = 1)

  # Default - gene_sets NULL collapses to single "All genes" band
  o1 <- ctdna_plot_oncoprint(sim$infinity_report,
                              filter = list(verbose = FALSE))
  expect_s3_class(o1, "ctdna_oncoprint")

  # Named single gene set
  o2 <- ctdna_plot_oncoprint(sim$infinity_report,
                              gene_sets = list(Selected = c("TP53","KRAS","EGFR")),
                              filter = list(verbose = FALSE))
  expect_s3_class(o2, "ctdna_oncoprint")

  # Pathway list -> band per set
  o3 <- ctdna_plot_oncoprint(
    sim$infinity_report,
    gene_sets = list(
      RTK_RAS = c("KRAS","EGFR","BRAF"),
      TP53    = "TP53"),
    filter = list(verbose = FALSE))
  expect_s3_class(o3, "ctdna_oncoprint")

  # Top annotations are accepted (passed to whichever engine is active)
  o4 <- ctdna_plot_oncoprint(
    sim$infinity_report,
    gene_sets = list(Sel = c("TP53","KRAS","EGFR")),
    patient_data    = sim$clinical,
    top_annotations = c("RECIST","Dose"),
    filter = list(verbose = FALSE))
  expect_s3_class(o4, "ctdna_oncoprint")

  # Engine selection — force fallback
  o5 <- ctdna_plot_oncoprint(sim$infinity_report,
                              engine = "ggplot",
                              filter = list(verbose = FALSE))
  expect_equal(o5$engine, "ggplot2")
  expect_s3_class(o5$plot, "ggplot")

  # Positional vector must error (clarifies the API)
  expect_error(
    ctdna_plot_oncoprint(sim$infinity_report,
                          gene_sets = c("TP53","KRAS"),
                          filter = list(verbose = FALSE)),
    "NAMED list"
  )
})

# -------- plot_mr_recist returns table_plot ---------------------------------
test_that("plot_mr_recist returns a publication-style table_plot", {
  mm <- ctdna_make_example_multimodal(n_subjects = 30, seed = 1)
  mr <- ctdna_plot_mr_recist(mm$ctdna)
  expect_s3_class(mr$table_plot, "ggplot")
  # The subtitle reports Agreement / kappa / N
  expect_match(mr$plot$labels$subtitle, "Agreement")
  expect_match(mr$plot$labels$subtitle, "kappa")
})

# -------- Seed reproducibility ----------------------------------------------
test_that("seed argument controls mock-data generators", {
  s1 <- ctdna_make_mock_study(n_patients = 5, seed = 99)
  s2 <- ctdna_make_mock_study(n_patients = 5, seed = 99)
  s3 <- ctdna_make_mock_study(n_patients = 5, seed = 7)
  expect_identical(s1$clinical, s2$clinical)
  expect_false(identical(s1$clinical, s3$clinical))

  m1 <- ctdna_make_example_multimodal(n_subjects = 5, seed = 99)
  m2 <- ctdna_make_example_multimodal(n_subjects = 5, seed = 99)
  expect_identical(m1$ctdna, m2$ctdna)
})

# -------- plot_reduction_vs_tumor uses RECIST=color, dose=shape -------------
test_that("plot_reduction_vs_tumor encodes RECIST as colour and dose as shape", {
  mm <- ctdna_make_example_multimodal(n_subjects = 20, seed = 1)
  p <- ctdna_plot_reduction_vs_tumor(mm$ctdna)
  expect_s3_class(p, "ggplot")
  # Inspect aes mapping
  mapping_names <- names(p$mapping)
  expect_true("colour" %in% mapping_names || "color" %in% mapping_names)
  expect_true("shape" %in% mapping_names)
})

# -------- ctdna_metric_at + at/metric in plot_reduction ---------------------
test_that("ctdna_metric_at computes per-subject value at best / visit / last", {
  mm <- ctdna_make_example_multimodal(n_subjects = 20, seed = 1)
  ctd <- mm$ctdna

  # best ratio
  a <- ctdna_metric_at(ctd)
  expect_true("value" %in% names(a))
  expect_true("time_used" %in% names(a))

  # TF at a specific visit
  b <- ctdna_metric_at(ctd, metric = "tf", at = "C5D1")
  expect_true(all(is.na(b$value) | b$value > 0))
  expect_true(all(is.na(b$time_used) | b$time_used == "C5D1"))

  # pct_change at last
  c <- ctdna_metric_at(ctd, metric = "pct_change", at = "last")
  # Most subjects in this mock study respond, so pct_change negative
  resp <- na.omit(c$value)
  expect_true(median(resp) < 0)

  # Unknown visit errors
  expect_error(ctdna_metric_at(ctd, at = "X9D9"), "not found")
})

test_that("plot_reduction accepts at, metric, and mr_threshold", {
  mm <- ctdna_make_example_multimodal(n_subjects = 25, seed = 1)
  # Default — same as before (best ratio)
  p_def <- ctdna_plot_reduction(mm$ctdna)
  expect_s3_class(p_def, "ggplot")

  # Ratio at a specific visit
  p_at <- ctdna_plot_reduction(mm$ctdna, at = "C5D1", metric = "ratio")
  expect_match(p_at$labels$y, "TF\\(C5D1\\)", fixed = FALSE)

  # Percent change at best
  p_pc <- ctdna_plot_reduction(mm$ctdna, metric = "pct_change")
  expect_match(p_pc$labels$y, "Percent change")

  # TF (absolute) at last
  p_tf <- ctdna_plot_reduction(mm$ctdna, metric = "tf", at = "last")
  expect_match(p_tf$labels$y, "TF at last")

  # mr_threshold is honoured
  p_thr <- ctdna_plot_reduction(mm$ctdna, mr_threshold = 0.3)
  expect_match(p_thr$labels$caption, "MR threshold = 0.3")
})

# -------- plot_baseline scheme is honoured ----------------------------------
test_that("plot_baseline accepts scheme + applies it to RECIST groups", {
  mm <- ctdna_make_example_multimodal(n_subjects = 30, seed = 1)
  # scheme = "two" -> R vs NR
  p2 <- ctdna_plot_baseline(mm$ctdna, group = "RECIST", vars = "methylTF",
                              scheme = "two")
  expect_s3_class(p2, "ggplot")

  # scheme = "three" -> CR/PR, SD, PD/NE/NA
  p3 <- ctdna_plot_baseline(mm$ctdna, group = "RECIST", vars = "methylTF",
                              scheme = "three")
  expect_s3_class(p3, "ggplot")

  # Same plot built non-RECIST group ignores scheme without error
  p_dose <- ctdna_plot_baseline(mm$ctdna, group = "dose", vars = "methylTF")
  expect_s3_class(p_dose, "ggplot")
})

# -------- Oncoprint: regression for "cannot map colors" error --------------
test_that("oncoprint never errors on RECIST color mapping (with raw values)", {
  sim <- ctdna_make_mock_study(n_patients = 20, seed = 1)
  # ggplot fallback path
  o1 <- ctdna_plot_oncoprint(sim$infinity_report,
    gene_sets = list(RTK_RAS = c("KRAS","EGFR","BRAF","MET"), TP53 = "TP53"),
    patient_data    = sim$clinical,
    top_annotations = c("RECIST","Dose","Cancertype"),
    filter = list(clinvar = c("Pathogenic","Likely pathogenic"),
                   functional_impact = FALSE,
                   verbose = FALSE),
    engine = "ggplot")
  expect_s3_class(o1, "ctdna_oncoprint")

  # Test the palette helper directly with all raw RECIST values
  raw_recist <- c("CR","PR","uCR","uPR","SD","PD","NE","NA")
  pal <- ctdnaTM:::.oncoprint_anno_palette("RECIST", raw_recist)
  expect_true(all(raw_recist %in% names(pal)))
  expect_true(all(grepl("^#", pal)))

  # Empty vals
  pal2 <- ctdnaTM:::.oncoprint_anno_palette("RECIST", character(0))
  expect_equal(length(pal2), 0)

  # Unknown value -> grey fallback, no error
  pal3 <- ctdnaTM:::.oncoprint_anno_palette("RECIST",
                                              c("CR","weird_value"))
  expect_true("weird_value" %in% names(pal3))
  expect_equal(pal3["weird_value"], c(weird_value = "#9E9E9E"))
})

test_that("ctdna_colors contains both collapsed and raw RECIST values", {
  cpal <- ctdna_colors()
  # Collapsed labels
  expect_true(all(c("CR/PR","uCR/PR","SD","PD/NE/NA") %in% names(cpal)))
  # Raw values that used to break the oncoprint
  expect_true(all(c("CR","PR","uCR","uPR","PD","NE","NA") %in% names(cpal)))
})

# -------- ctdna_help: categorized function listing -------------------------
test_that("ctdna_help returns a data frame of all exports", {
  df <- ctdna_help(show_args = FALSE)
  expect_s3_class(df, "data.frame")
  expect_true(nrow(df) >= 40)
  expect_true(all(c("name","category","summary","args") %in% names(df)))
  # Every plot function should be in the catalog
  plot_fns <- grep("^ctdna_plot_", getNamespaceExports("ctdnaTM"), value = TRUE)
  expect_true(all(plot_fns %in% df$name))
})

test_that("ctdna_help supports category and search filters", {
  helpers <- ctdna_help("Helpers", show_args = FALSE)
  expect_true(all(helpers$category == "Helpers"))

  plots <- ctdna_help("plot", show_args = FALSE)
  expect_true(all(grepl("plot", plots$category, ignore.case = TRUE)))

  recist <- ctdna_help(search = "RECIST", show_args = FALSE)
  expect_true(nrow(recist) > 0)

  # Bad category should error
  expect_error(ctdna_help("does_not_exist"), "No category matches")
})

# -------- scheme parameter is available everywhere needed -------------------
test_that("every RECIST-using plot function exposes scheme", {
  # Plot fns that involve RECIST (everything except mutation_concordance,
  # which compares panel calls only)
  plot_fns <- grep("^ctdna_plot_", getNamespaceExports("ctdnaTM"), value = TRUE)
  for (fn in plot_fns) {
    args <- names(formals(fn))
    expect_true("scheme" %in% args, info = sprintf("%s missing scheme arg", fn))
  }
})

# -------- New oncoprint args: cancer_type + sort_genes modes ----------------
test_that("ctdna_plot_oncoprint cancer_type filters to one or more indications", {
  sim <- ctdna_make_mock_study(n_patients = 40, seed = 1)
  inds <- unique(sim$clinical$Cancertype)
  expect_true("NSCLC" %in% inds)

  # Single indication
  n_nsclc <- sum(sim$clinical$Cancertype == "NSCLC")
  o1 <- ctdna_plot_oncoprint(sim$infinity_report,
                              patient_data = sim$clinical,
                              cancer_type  = "NSCLC",
                              filter = list(verbose = FALSE),
                              engine = "ggplot")
  expect_s3_class(o1, "ctdna_oncoprint")
  # Title auto-populated
  expect_match(o1$plot$labels$title, "NSCLC")

  # Multiple indications
  o2 <- ctdna_plot_oncoprint(sim$infinity_report,
                              patient_data = sim$clinical,
                              cancer_type  = c("NSCLC","CRC"),
                              filter = list(verbose = FALSE),
                              engine = "ggplot")
  expect_s3_class(o2, "ctdna_oncoprint")

  # cancer_type requires patient_data
  expect_error(
    ctdna_plot_oncoprint(sim$infinity_report, cancer_type = "NSCLC",
                          filter = list(verbose = FALSE), engine = "ggplot"),
    "patient_data"
  )

  # Bogus indication errors out helpfully
  expect_error(
    ctdna_plot_oncoprint(sim$infinity_report,
                          patient_data = sim$clinical,
                          cancer_type  = "Nonexistent",
                          filter = list(verbose = FALSE), engine = "ggplot"),
    "No patients"
  )
})

test_that("ctdna_plot_oncoprint sort_genes accepts global/within_set/none + legacy bool", {
  sim <- ctdna_make_mock_study(n_patients = 30, seed = 1)
  gs  <- list(RTK_RAS = c("KRAS","EGFR","BRAF","MET"),
              TP53    = "TP53")
  for (mode in c("global","within_set","none")) {
    o <- ctdna_plot_oncoprint(sim$infinity_report,
                                gene_sets = gs, sort_genes = mode,
                                filter = list(verbose = FALSE),
                                engine = "ggplot")
    expect_s3_class(o, "ctdna_oncoprint")
  }
  # Legacy boolean form
  for (b in c(TRUE, FALSE)) {
    o <- ctdna_plot_oncoprint(sim$infinity_report,
                                gene_sets = gs, sort_genes = b,
                                filter = list(verbose = FALSE),
                                engine = "ggplot")
    expect_s3_class(o, "ctdna_oncoprint")
  }
})

# -------- Column-by-column filter registry ---------------------------------
test_that("ctdna_filter_opts get / set / reset / load round-trips", {
  ctdna_filter_opts(.reset = TRUE)

  # Get one
  e <- ctdna_filter_opts("VAF_percentage")
  expect_true(is.list(e))
  expect_named(e, c("enabled","op","value","desc"))
  expect_equal(e$op, ">=")

  # Set (partial: value only)
  ctdna_filter_opts(VAF_percentage = list(enabled = TRUE, value = 1.5))
  e2 <- ctdna_filter_opts("VAF_percentage")
  expect_true(e2$enabled)
  expect_equal(e2$value, 1.5)

  # Snapshot, reset, load
  cfg <- ctdna_filter_opts()
  ctdna_filter_opts(.reset = TRUE)
  expect_false(ctdna_filter_opts("VAF_percentage")$enabled)
  ctdna_filter_opts(load = cfg)
  expect_true(ctdna_filter_opts("VAF_percentage")$enabled)
  expect_equal(ctdna_filter_opts("VAF_percentage")$value, 1.5)

  ctdna_filter_opts(.reset = TRUE)
})

test_that("ctdna_apply_filter respects registry and overrides", {
  ctdna_filter_opts(.reset = TRUE)
  sim <- ctdna_make_mock_study(n_patients = 20, seed = 1)
  n0 <- nrow(sim$infinity_report)

  # Default registry filters (Sample_status + Variant_type + Functional + Somatic)
  n_def <- nrow(ctdna_apply_filter(sim$infinity_report))
  expect_lt(n_def, n0)

  # Stricter VAF via per-call override
  n_strict <- nrow(ctdna_apply_filter(sim$infinity_report,
    overrides = list(VAF_percentage = list(enabled = TRUE, value = 5.0))))
  expect_lt(n_strict, n_def)

  # The global registry was not mutated by the override
  expect_false(ctdna_filter_opts("VAF_percentage")$enabled)
})

test_that("ctdna_plot_oncoprint applies filter_scheme through the three-level system", {
  ctdna_filter_opts(.reset = TRUE)
  sim <- ctdna_make_mock_study(n_patients = 30, seed = 1)

  # Build a specific scheme with per-gene-set overrides
  ctdna_filter_scheme_create("test_per_set",
    gene_sets = list(
      RTK_RAS = c("KRAS","EGFR","BRAF","MET"),
      HRR     = c("BRCA1","BRCA2","ATM","PALB2")),
    overrides = list(
      RTK_RAS = list(VAF_percentage = list(enabled = TRUE, value = 3.0)),
      HRR     = list(ClinVar = list(enabled = TRUE,
                                      value = c("Pathogenic","Likely pathogenic")))),
    overwrite = TRUE)

  # Apply the named scheme through the oncoprint
  o <- ctdna_plot_oncoprint(sim$infinity_report,
    gene_sets = list(
      RTK_RAS = c("KRAS","EGFR","BRAF","MET"),
      HRR     = c("BRCA1","BRCA2","ATM","PALB2")),
    filter_scheme = "test_per_set",
    engine = "ggplot")
  expect_s3_class(o, "ctdna_oncoprint")

  # Unknown scheme name errors with the right message
  expect_error(
    ctdna_plot_oncoprint(sim$infinity_report,
      gene_sets = list(A = "TP53"),
      filter_scheme = "does_not_exist",
      engine = "ggplot"),
    "No filter scheme"
  )

  ctdna_filter_scheme_delete("test_per_set")
})

# -------- Three-level filter system: schemes + has_value -------------------
test_that("three-level filter system: default, modified, specific scheme", {
  ctdna_filter_reset_general()
  sim <- ctdna_make_mock_study(n_patients = 20, seed = 1)

  # Level 1: default general
  n1 <- nrow(ctdna_filter_apply_scheme(sim$infinity_report))
  expect_gt(n1, 0)

  # Level 2: modified general (stricter VAF)
  ctdna_filter_opts(VAF_percentage = list(enabled = TRUE, value = 5.0))
  n2 <- nrow(ctdna_filter_apply_scheme(sim$infinity_report))
  expect_lt(n2, n1)   # tighter = fewer rows

  # Level 3: named specific scheme
  ctdna_filter_scheme_create("L3test",
    gene_sets = list(HRR = c("BRCA1","BRCA2")),
    overrides = list(HRR = list(ClinVar = list(enabled = TRUE,
                                                 value = "Pathogenic"))),
    overwrite = TRUE)
  out <- ctdna_filter_apply_scheme(sim$infinity_report,
                                     filter_scheme = "L3test")
  # The result carries provenance metadata
  used <- attr(out, "ctdna_filter_used")
  expect_equal(used$scheme, "L3test")
  expect_equal(used$mode, "dynamic")

  ctdna_filter_scheme_delete("L3test")
  ctdna_filter_reset_general()
})

test_that("dynamic vs frozen schemes behave differently on general changes", {
  ctdna_filter_reset_general()
  sim <- ctdna_make_mock_study(n_patients = 20, seed = 1)

  ctdna_filter_scheme_create("dyn",
    gene_sets = list(HRR = c("BRCA1","BRCA2")),
    overrides = list(),
    frozen = FALSE, overwrite = TRUE)
  ctdna_filter_scheme_create("frz",
    gene_sets = list(HRR = c("BRCA1","BRCA2")),
    overrides = list(),
    frozen = TRUE, overwrite = TRUE)

  # Tighten general AFTER creating both
  ctdna_filter_opts(VAF_percentage = list(enabled = TRUE, value = 10))

  n_dyn <- nrow(ctdna_filter_apply_scheme(sim$infinity_report,
                                            filter_scheme = "dyn"))
  n_frz <- nrow(ctdna_filter_apply_scheme(sim$infinity_report,
                                            filter_scheme = "frz"))
  # Dynamic picks up the tightening; frozen does not, so frozen >= dynamic.
  expect_gte(n_frz, n_dyn)

  ctdna_filter_scheme_delete("dyn")
  ctdna_filter_scheme_delete("frz")
  ctdna_filter_reset_general()
})

test_that("has_value operator keeps annotated or novel rows", {
  ctdna_filter_reset_general()
  sim <- ctdna_make_mock_study(n_patients = 15, seed = 1)
  total <- nrow(sim$infinity_report)

  # Keep only novel (no dbSNP value)
  ctdna_filter_opts(dbSNP = list(enabled = TRUE, op = "has_value", value = FALSE))
  n_novel <- nrow(ctdna_filter_apply_scheme(sim$infinity_report))

  # Keep only annotated (has dbSNP value)
  ctdna_filter_opts(dbSNP = list(enabled = TRUE, op = "has_value", value = TRUE))
  n_anno <- nrow(ctdna_filter_apply_scheme(sim$infinity_report))

  # The two partitions should be disjoint and cover everything that the
  # default general accepts (Sample_status etc.). Therefore both should
  # be > 0 and sum to <= total.
  expect_gt(n_novel, 0)
  expect_gt(n_anno, 0)
  expect_lte(n_novel + n_anno, total)
  ctdna_filter_reset_general()
})

test_that("scheme lifecycle helpers: list / get / delete / freeze / save / load", {
  ctdna_filter_reset_general()
  for (s in c("a","b","c")) {
    try(ctdna_filter_scheme_delete(s), silent = TRUE)
  }

  ctdna_filter_scheme_create("a", gene_sets = list(X = "TP53"))
  ctdna_filter_scheme_create("b", gene_sets = list(X = "KRAS"), frozen = TRUE)

  lst <- ctdna_filter_scheme_list()
  expect_true(all(c("a","b") %in% lst$name))
  expect_equal(lst$mode[lst$name == "b"], "frozen")

  expect_equal(ctdna_filter_scheme_get("a")$name, "a")

  # Freeze the dynamic one
  ctdna_filter_scheme_freeze("a")
  expect_equal(ctdna_filter_scheme_get("a")$frozen, TRUE)

  # Save + reload
  f <- tempfile(fileext = ".rds")
  ctdna_filter_scheme_save(f)
  ctdna_filter_scheme_delete("a")
  ctdna_filter_scheme_delete("b")
  expect_false("a" %in% ctdna_filter_scheme_list()$name)
  ctdna_filter_scheme_load(f)
  expect_true("a" %in% ctdna_filter_scheme_list()$name)

  ctdna_filter_scheme_delete("a")
  ctdna_filter_scheme_delete("b")
  unlink(f)
})

test_that("filter_scheme is accepted by every alteration-aware plot function", {
  ctdna_filter_reset_general()
  sim <- ctdna_make_mock_study(n_patients = 20, seed = 1)
  mm  <- ctdna_make_example_multimodal(n_subjects = 20, seed = 1)

  ctdna_filter_scheme_create("fs_test",
    gene_sets = list(TP53 = "TP53", HRR = c("BRCA1","BRCA2")),
    overrides = list(HRR = list(ClinVar = list(enabled = TRUE,
                                                 value = "Pathogenic"))),
    overwrite = TRUE)

  expect_s3_class(
    ctdna_plot_oncoprint(sim$infinity_report,
      gene_sets = list(HRR = c("BRCA1","BRCA2"), TP53 = "TP53"),
      filter_scheme = "fs_test", engine = "ggplot"),
    "ctdna_oncoprint")

  expect_silent(
    ctdna_plot_alteration_grid(sim$infinity_report,
      gene_sets = list(TP53 = "TP53"),
      patient_data = sim$clinical,
      filter_scheme = "fs_test"))

  expect_silent(
    ctdna_plot_vs_mutation(mm$ctdna, mm$genomic_74, gene = "TP53",
      panel = "74genes", filter_scheme = "fs_test"))

  mut_long <- rbind(mm$genomic_74, mm$genomic_500)
  expect_silent(
    ctdna_mutation_concordance(mut_long, panel_a = "74genes",
      panel_b = "500genes", filter_scheme = "fs_test"))

  ctdna_filter_scheme_delete("fs_test")
})
