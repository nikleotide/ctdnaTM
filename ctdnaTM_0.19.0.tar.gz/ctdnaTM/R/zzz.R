# ============================================================================
# ctdnaTM — package onAttach hook
# ============================================================================

.onAttach <- function(libname, pkgname) {
  v <- utils::packageVersion(pkgname)
  packageStartupMessage(
    sprintf("ctdnaTM v%s - ctDNA Deliverables", v),
    "\nDeveloped by Hamid Nikbakht"
  )
  if (!requireNamespace("ComplexHeatmap", quietly = TRUE)) {
    packageStartupMessage(
      "Tip: install ComplexHeatmap for publication-quality oncoprint:",
      "\n  install.packages('BiocManager')",
      "\n  BiocManager::install('ComplexHeatmap')"
    )
  }
  packageStartupMessage("Type `?ctdnaTM` for an overview, `ctdna_opts()` for config.")
}
