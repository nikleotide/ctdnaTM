# ============================================================================
# ctdnaTM — multi-modal integration
# ============================================================================
# Every cross-modality plot accepts a `stat` parameter with a recommended
# default. See each function's docs for the recommendation.

.ctdna_metric_col <- function(metric) {
  if (!metric %in% c("best_ratio","baseline_tf","last_tf"))
    stop("metric must be one of: best_ratio, baseline_tf, last_tf")
  metric
}

#' Merge per-subject ctDNA summary with another modality
#'
#' Convenience wrapper around [ctdna_summary()] + [merge()].
#'
#' @param ctdna_df Longitudinal ctDNA data.
#' @param other_df Modality data with a subject column.
#' @param by Join key (default `ctdna_opts("subject")`).
#' @return Merged data frame.
#' @export
ctdna_merge_modalities <- function(ctdna_df, other_df, by = .o("subject")) {
  cs <- ctdna_summary(ctdna_df)
  merge(cs, other_df, by = by, all = FALSE)
}


# ---- ctDNA x RNA-seq --------------------------------------------------------

#' Plot ctDNA metric vs gene expression
#'
#' Filters a long-format expression frame to a single gene and correlates
#' with a per-subject ctDNA metric.
#'
#' @section Recommended statistic:
#' `"spearman"` (default): expression values are often non-normal
#' (especially without log/voom transformation) and ctDNA metrics span
#' orders of magnitude. Use `"pearson"` only if both axes are clearly
#' normal on the chosen scale.
#'
#' @param ctdna_df Longitudinal ctDNA data.
#' @param expr_df Long-format expression: subject + gene + expression.
#' @param gene Gene symbol.
#' @param metric ctDNA metric: `"best_ratio"` (default), `"baseline_tf"`,
#'   `"last_tf"`.
#' @param log_x Log-scale x-axis (default TRUE).
#' @param recist_color Color points by RECIST.
#' @param scheme RECIST scheme.
#' @param stat One of `"spearman"` (default), `"pearson"`, `"kendall"`,
#'   `"none"`. Recommended: `"spearman"`.
#' @param show_stats,title,subtitle,caption,xlab,ylab,point_size,point_alpha
#'   Display.
#' @export
ctdna_plot_vs_expression <- function(ctdna_df, expr_df, gene,
                                     metric = .o("ctdna_metric"),
                                     log_x = TRUE,
                                     recist_color = TRUE,
                                     scheme = c("two","three","four"),
                                     stat = c("spearman","pearson","kendall","none"),
                                     show_stats = .o("show_stats"),
                                     title = NULL, subtitle = NULL,
                                     caption = NULL,
                                     xlab = NULL, ylab = NULL,
                                     point_size = .o("point_size") + 1,
                                     point_alpha = .o("point_alpha"),
    stat_position = .o("stat_position"),
    legend_position = .o("legend_position")) {
  .stats_label <- NULL

  scheme <- match.arg(scheme); stat <- match.arg(stat)
  metric <- .ctdna_metric_col(metric)
  gcol <- .o("gene"); ecol <- .o("expression")
  # Canonicalize expression unit (no-op if already canonical)
  expr_df <- .canonicalize_expression(expr_df)
  expr <- expr_df[expr_df[[gcol]] == gene, c(.o("subject"), ecol), drop = FALSE]
  if (nrow(expr) == 0) stop("Gene not found in expression frame: ", gene)
  d <- ctdna_merge_modalities(ctdna_df, expr)
  d$.x <- if (log_x) ctdna_floor_tf(d[[metric]]) else d[[metric]]
  d$.y <- d[[ecol]]
  d$.r <- ctdna_stratify_recist(d[[.o("recist")]], scheme)
  if (is.null(title)) title <- sprintf("ctDNA (%s) vs %s expression", metric, gene)
  if (show_stats && stat != "none" ) {
    ct <- ctdna_cor_test(if (log_x) log10(d$.x) else d$.x, d$.y, method = stat)
    .stats_label <- sprintf("%s rho = %.2f, %s, n = %d",
                        ct$name, ct$rho, ctdna_pval_label(ct$p), ct$n)
  }
  if (is.null(xlab)) xlab <- if (log_x) sprintf("%s (log)", metric) else metric
  if (is.null(ylab)) {
    unit_lbl <- switch(.o("expression_unit"),
                       log2_tpm_plus_one = "log2(TPM+1)",
                       tpm               = "TPM",
                       .o("expression_unit"))
    ylab <- sprintf("%s expression [%s]", gene, unit_lbl)
  }

  p <- ggplot2::ggplot(d, ggplot2::aes(.data$.x, .data$.y))
  if (recist_color) {
    p <- p + ggplot2::geom_point(ggplot2::aes(color = .data$.r),
                                 size = point_size, alpha = point_alpha) +
      ctdna_scale_recist() + ggplot2::labs(color = "RECIST")
  } else {
    p <- p + ggplot2::geom_point(size = point_size, alpha = point_alpha,
                                 color = "grey20")
  }
  p <- p + ggplot2::geom_smooth(method = "lm", se = TRUE,
                                color = "grey30", fill = "grey80",
                                linetype = "dashed", linewidth = 0.6,
                                formula = y ~ x, alpha = 0.4) +
    ctdna_theme()
  if (log_x) p <- p + ggplot2::scale_x_log10()
    # Route stats label per stat_position option
  if (!is.null(.stats_label)) {
    .routed <- .route_stats(.stats_label, stat_position, subtitle, caption)
    subtitle <- .routed$subtitle; caption <- .routed$caption
  
    on_plot_label <- .routed$on_plot
  } else on_plot_label <- NULL
  # (on_plot_label annotated below after .finalize)
  .annotate_stat(.finalize(p, title, subtitle, caption, xlab, ylab, legend_position = legend_position), on_plot_label)
}


# ---- ctDNA x mutation status ------------------------------------------------

#' Plot ctDNA metric stratified by mutation status of a gene
#'
#' @section Recommended statistic:
#' `"wilcox"` (default): rank-sum between mutation carriers and
#' non-carriers — handles skewed ctDNA values. Use `"t"` only if the
#' ctDNA metric is normal on the working scale. Use `"kruskal"` when
#' grouping by `alteration_type` (multi-state).
#'
#' @param ctdna_df Longitudinal ctDNA data.
#' @param mut_df Long-format mutations: subject + gene + mutation_status
#'   (+ optional panel, alteration_type).
#' @param gene Gene symbol.
#' @param panel Optional: restrict to a panel (e.g. `"74genes"`, `"500genes"`).
#' @param by Stratify by `"mutation_status"` (default; binary wt vs mut)
#'   or `"alteration_type"` (snv / cnv_amp / cnv_loss / lgr / fusion / wt).
#'   Resolved via `ctdna_opts(mutation)` / `ctdna_opts(alteration)`.
#' @param metric ctDNA metric.
#' @param stat One of `"wilcox"` (default), `"t"`, `"kruskal"`, `"none"`.
#'   Recommended: `"wilcox"` (two groups) or `"kruskal"` (multi-state).
#' @param show_stats,title,subtitle,caption,xlab,ylab,point_size,point_alpha
#'   Display.
#' @export
ctdna_plot_vs_mutation <- function(ctdna_df, mut_df, gene,
                                   panel = NULL,
                                   by = c("mutation_status", "alteration_type"),
                                   metric = .o("ctdna_metric"),
                                   recist_facet = FALSE,
                                   scheme = c("two","three","four"),
                                   filter_scheme = NULL,
                                   stat = c("wilcox","t","kruskal","none"),
                                   show_stats = .o("show_stats"),
                                   title = NULL, subtitle = NULL,
                                   caption = NULL,
                                   xlab = "Mutation status",
                                   ylab = NULL,
                                   point_size = .o("point_size"),
                                   point_alpha = .o("point_alpha"),
    stat_position = .o("stat_position"),
    legend_position = .o("legend_position")) {
  .stats_label <- NULL

  stat <- match.arg(stat)
  by   <- match.arg(by)
  scheme <- match.arg(scheme)
  metric <- .ctdna_metric_col(metric)
  # Three-level filter system applied to mutation frame before per-gene lookup
  mut_df <- ctdna_filter_apply_scheme(mut_df, filter_scheme = filter_scheme)
  gcol <- .o("gene"); mcol <- .o("mutation"); pcol <- .o("panel")
  acol <- .o("alteration")
  group_col <- if (by == "mutation_status") mcol else acol
  mut <- mut_df[mut_df[[gcol]] == gene, , drop = FALSE]
  if (!is.null(panel) && pcol %in% names(mut))
    mut <- mut[mut[[pcol]] == panel, , drop = FALSE]
  if (nrow(mut) == 0) stop("Gene/panel not found in mutation frame.")
  if (!group_col %in% names(mut))
    stop(sprintf("Column '%s' (selected via by='%s') not found in mutation data.",
                 group_col, by))
  mut <- mut[, c(.o("subject"), group_col), drop = FALSE]
  d <- ctdna_merge_modalities(ctdna_df, mut)
  d$.y <- ctdna_floor_tf(d[[metric]])
  d[[group_col]] <- factor(d[[group_col]])
  if (recist_facet && .o("recist") %in% names(d)) {
    d$.r <- ctdna_stratify_recist(d[[.o("recist")]], scheme)
  }

  if (is.null(title))
    title <- sprintf("ctDNA (%s) by %s %s%s", metric, gene, by,
                     if (!is.null(panel)) sprintf(" [%s]", panel) else "")
  if (show_stats && stat != "none" ) {
    r <- ctdna_run_group_test(d, ".y", group_col, method = stat)
    .stats_label <- sprintf("%s %s, n = %d", r$name, ctdna_pval_label(r$p), nrow(d))
  }
  if (is.null(ylab)) ylab <- sprintf("%s (log)", metric)
  if (identical(xlab, "Mutation status") && by == "alteration_type")
    xlab <- "Alteration type"

  p <- ggplot2::ggplot(d, ggplot2::aes(.data[[group_col]], .data$.y,
                                       color = .data[[group_col]],
                                       fill  = .data[[group_col]])) +
    ggplot2::geom_boxplot(outlier.shape = NA, alpha = 0.3,
                          linewidth = 0.7, fatten = 2.2, width = 0.55) +
    ggplot2::geom_jitter(width = 0.15, size = point_size, alpha = point_alpha,
                         shape = 21, stroke = 0.3, color = "grey20") +
    ctdna_scale_dose(aesthetics = c("color", "fill")) +
    .log_clearance() + ctdna_theme() +
    NULL  # legend_position handled by .finalize
  if (recist_facet && ".r" %in% names(d)) {
    p <- p + ggplot2::facet_wrap(~ .data$.r) +
      ggplot2::labs(subtitle = if (is.null(subtitle))
                                  sprintf("Faceted by RECIST (scheme=%s)", scheme)
                                else subtitle)
  }
  counts <- as.data.frame(table(d[[group_col]]))
  names(counts) <- c("g","n"); counts$label <- paste0("n=", counts$n)
  # Put n into the x-tick label to avoid overlap with data
  new_labels <- setNames(
    paste0(as.character(counts$g), "\n(n=", counts$n, ")"),
    as.character(counts$g))
  p <- p + ggplot2::scale_x_discrete(labels = new_labels) +
    ggplot2::theme(
      plot.margin = ggplot2::margin(8, 8, 14, 8),
      axis.text.x = ggplot2::element_text(margin = ggplot2::margin(t = 4)))
    # Route stats label per stat_position option
  if (!is.null(.stats_label)) {
    .routed <- .route_stats(.stats_label, stat_position, subtitle, caption)
    subtitle <- .routed$subtitle; caption <- .routed$caption
  
    on_plot_label <- .routed$on_plot
  } else on_plot_label <- NULL
  # (on_plot_label annotated below after .finalize)
  .annotate_stat(.finalize(p, title, subtitle, caption, xlab, ylab, legend_position = legend_position), on_plot_label)
}


# ---- ctDNA x TMB ------------------------------------------------------------

#' Plot ctDNA metric vs TMB from a chosen panel
#'
#' @section Recommended statistic:
#' `"spearman"` (default): TMB is right-skewed and ctDNA metrics span
#' orders of magnitude. Pearson is rarely appropriate.
#'
#' @param ctdna_df Longitudinal ctDNA data.
#' @param tmb_df Data with subject + TMB column (+ optional panel).
#' @param panel Optional panel filter.
#' @param metric ctDNA metric.
#' @param tmb_col Column name in `tmb_df` (default `ctdna_opts("tmb")`).
#' @param stat One of `"spearman"` (default), `"pearson"`, `"kendall"`,
#'   `"none"`. Recommended: `"spearman"`.
#' @param show_stats,title,subtitle,caption,xlab,ylab,point_size,point_alpha
#'   Display.
#' @export
ctdna_plot_vs_tmb <- function(ctdna_df, tmb_df,
                              panel = NULL,
                              metric = .o("ctdna_metric"),
                              tmb_col = .o("tmb"),
                              recist_color = FALSE,
                              scheme = c("two","three","four"),
                              stat = c("spearman","pearson","kendall","none"),
                              show_stats = .o("show_stats"),
                              title = NULL, subtitle = NULL,
                              caption = NULL,
                              xlab = NULL, ylab = NULL,
                              point_size = .o("point_size") + 1,
                              point_alpha = .o("point_alpha"),
    stat_position = .o("stat_position"),
    legend_position = .o("legend_position")) {
  .stats_label <- NULL

  stat <- match.arg(stat)
  scheme <- match.arg(scheme)
  metric <- .ctdna_metric_col(metric)
  pcol <- .o("panel")
  tmb <- tmb_df
  if (!is.null(panel) && pcol %in% names(tmb))
    tmb <- tmb[tmb[[pcol]] == panel, , drop = FALSE]
  tmb <- tmb[, c(.o("subject"), tmb_col), drop = FALSE]
  d <- ctdna_merge_modalities(ctdna_df, tmb)
  d$.x <- ctdna_floor_tf(d[[metric]])
  d$.y <- d[[tmb_col]]
  if (recist_color && .o("recist") %in% names(d)) {
    d$.r <- ctdna_stratify_recist(d[[.o("recist")]], scheme)
  }
  if (is.null(title))
    title <- sprintf("ctDNA (%s) vs TMB%s", metric,
                     if (!is.null(panel)) sprintf(" [%s]", panel) else "")
  if (show_stats && stat != "none" ) {
    ct <- ctdna_cor_test(log10(d$.x), d$.y, method = stat)
    .stats_label <- sprintf("%s rho = %.2f, %s, n = %d",
                        ct$name, ct$rho, ctdna_pval_label(ct$p), ct$n)
  }
  if (is.null(xlab)) xlab <- sprintf("%s (log)", metric)
  if (is.null(ylab)) ylab <- "TMB (mut/Mb)"

  p <- if (recist_color && ".r" %in% names(d)) {
    ggplot2::ggplot(d, ggplot2::aes(.data$.x, .data$.y, color = .data$.r)) +
      ggplot2::geom_point(size = point_size, alpha = point_alpha) +
      ggplot2::geom_smooth(method = "lm", se = TRUE, inherit.aes = FALSE,
                           ggplot2::aes(.data$.x, .data$.y),
                           color = "grey30", fill = "grey80",
                           linetype = "dashed", linewidth = 0.6,
                           formula = y ~ x, alpha = 0.4) +
      ctdna_scale_recist() +
      ggplot2::labs(color = "RECIST")
  } else {
    ggplot2::ggplot(d, ggplot2::aes(.data$.x, .data$.y)) +
      ggplot2::geom_point(size = point_size, alpha = point_alpha,
                          color = "grey20") +
      ggplot2::geom_smooth(method = "lm", se = TRUE,
                           color = "grey30", fill = "grey80",
                           linetype = "dashed", linewidth = 0.6,
                           formula = y ~ x, alpha = 0.4)
  }
  p <- p + ggplot2::scale_x_log10() + ctdna_theme()
    # Route stats label per stat_position option
  if (!is.null(.stats_label)) {
    .routed <- .route_stats(.stats_label, stat_position, subtitle, caption)
    subtitle <- .routed$subtitle; caption <- .routed$caption
  
    on_plot_label <- .routed$on_plot
  } else on_plot_label <- NULL
  # (on_plot_label annotated below after .finalize)
  .annotate_stat(.finalize(p, title, subtitle, caption, xlab, ylab, legend_position = legend_position), on_plot_label)
}


# ---- ctDNA x IHC ------------------------------------------------------------

#' Plot ctDNA metric vs IHC marker score
#'
#' @section Recommended statistic:
#' `"spearman"` (default): IHC scores are often bounded/skewed.
#'
#' @param ctdna_df Longitudinal ctDNA data.
#' @param ihc_df Long-format IHC: subject + marker + score.
#' @param marker Marker name.
#' @param metric ctDNA metric.
#' @param stat One of `"spearman"` (default), `"pearson"`, `"kendall"`,
#'   `"none"`. Recommended: `"spearman"`.
#' @param show_stats,title,subtitle,caption,xlab,ylab,point_size,point_alpha
#'   Display.
#' @export
ctdna_plot_vs_ihc <- function(ctdna_df, ihc_df, marker,
                              metric = .o("ctdna_metric"),
                              recist_color = FALSE,
                              scheme = c("two","three","four"),
                              stat = c("spearman","pearson","kendall","none"),
                              show_stats = .o("show_stats"),
                              title = NULL, subtitle = NULL,
                              caption = NULL,
                              xlab = NULL, ylab = NULL,
                              point_size = .o("point_size") + 1,
                              point_alpha = .o("point_alpha"),
    stat_position = .o("stat_position"),
    legend_position = .o("legend_position")) {
  .stats_label <- NULL

  stat <- match.arg(stat)
  scheme <- match.arg(scheme)
  metric <- .ctdna_metric_col(metric)
  mcol <- .o("marker"); scol <- .o("ihc_score")
  ihc <- ihc_df[ihc_df[[mcol]] == marker, c(.o("subject"), scol), drop = FALSE]
  if (nrow(ihc) == 0) stop("Marker not found in IHC frame: ", marker)
  d <- ctdna_merge_modalities(ctdna_df, ihc)
  d$.x <- ctdna_floor_tf(d[[metric]])
  d$.y <- d[[scol]]
  if (recist_color && .o("recist") %in% names(d)) {
    d$.r <- ctdna_stratify_recist(d[[.o("recist")]], scheme)
  }
  if (is.null(title))
    title <- sprintf("ctDNA (%s) vs %s IHC score", metric, marker)
  if (show_stats && stat != "none" ) {
    ct <- ctdna_cor_test(log10(d$.x), d$.y, method = stat)
    .stats_label <- sprintf("%s rho = %.2f, %s, n = %d",
                        ct$name, ct$rho, ctdna_pval_label(ct$p), ct$n)
  }
  if (is.null(xlab)) xlab <- sprintf("%s (log)", metric)
  if (is.null(ylab)) ylab <- sprintf("%s IHC score", marker)

  p <- if (recist_color && ".r" %in% names(d)) {
    ggplot2::ggplot(d, ggplot2::aes(.data$.x, .data$.y, color = .data$.r)) +
      ggplot2::geom_point(size = point_size, alpha = point_alpha) +
      ggplot2::geom_smooth(method = "lm", se = TRUE, inherit.aes = FALSE,
                            ggplot2::aes(.data$.x, .data$.y),
                            color = "grey30", fill = "grey80",
                            linetype = "dashed", linewidth = 0.6,
                            formula = y ~ x, alpha = 0.4) +
      ctdna_scale_recist() + ggplot2::labs(color = "RECIST")
  } else {
    ggplot2::ggplot(d, ggplot2::aes(.data$.x, .data$.y)) +
      ggplot2::geom_point(size = point_size, alpha = point_alpha,
                          color = "grey20") +
      ggplot2::geom_smooth(method = "lm", se = TRUE,
                           color = "grey30", fill = "grey80",
                           linetype = "dashed", linewidth = 0.6,
                           formula = y ~ x, alpha = 0.4)
  }
  p <- p + ggplot2::scale_x_log10() + ctdna_theme()
    # Route stats label per stat_position option
  if (!is.null(.stats_label)) {
    .routed <- .route_stats(.stats_label, stat_position, subtitle, caption)
    subtitle <- .routed$subtitle; caption <- .routed$caption
  
    on_plot_label <- .routed$on_plot
  } else on_plot_label <- NULL
  # (on_plot_label annotated below after .finalize)
  .annotate_stat(.finalize(p, title, subtitle, caption, xlab, ylab, legend_position = legend_position), on_plot_label)
}


# ---- Cross-platform mutation concordance ------------------------------------

#' Concordance of mutation calls between two panels
#'
#' Compares per-(subject x gene) mutation calls between two assay panels
#' on the SAME patients. Typical uses: comparing 74-gene vs 500-gene
#' ctDNA panels, or comparing a tissue panel (WES) against a plasma
#' panel for the overlapping gene set.
#'
#' \strong{What the plot shows.} A bar chart of \emph{per-gene agreement
#' percentages}, where each bar is the fraction of patients on whom
#' both panels gave the same call (e.g. both "mut" or both "wt") for
#' that gene. Bars sorted by agreement ascending so the most-discordant
#' genes are at the left.
#'
#' \strong{What the statistics report.} The subtitle reports three
#' values aggregated across all (subject, gene) pairs (not per gene):
#' \itemize{
#'   \item \strong{Agreement \%} - fraction of pairs where both panels
#'     gave the same call (diagonal of the 2x2 contingency table).
#'   \item \strong{Cohen's kappa} - chance-adjusted agreement; 0 = no
#'     better than chance, 1 = perfect agreement.
#'   \item \strong{McNemar p} - tests whether one panel systematically
#'     calls more "mut" than the other (marginal homogeneity, 2x2 only).
#' }
#' The returned list includes \code{table_plot}, a publication-style
#' \code{ctdna_table()} rendering of the overall 2x2 contingency.
#'
#' @section Recommended statistic:
#' `"both"` (default): % agreement and Cohen's kappa together. Add or
#' switch to `"mcnemar"` if you specifically need a marginal-homogeneity
#' test (only valid 2x2).
#'
#' @param mut_df Long-format mutations: subject + gene + mutation_status + panel.
#' @param panel_a Reference panel name (e.g. "74genes").
#' @param panel_b Comparator panel name (e.g. "500genes").
#' @param genes Optional gene subset. If NULL, uses overlapping genes
#'   between the two panels.
#' @param stat One of `"both"` (default), `"kappa"`, `"agreement"`,
#'   `"mcnemar"`, `"none"`.
#' @param show_stats,title,subtitle,caption,xlab,ylab,stat_position,legend_position
#'   Display options (see [ctdna_plot_baseline]).
#' @return A list with components:
#'   \itemize{
#'     \item \code{plot} - per-gene agreement barplot (ggplot)
#'     \item \code{table} - overall 2x2 contingency table
#'     \item \code{table_plot} - publication-style ggplot rendering of \code{table}
#'     \item \code{agreement} - overall agreement (fraction in 0-1)
#'     \item \code{kappa} - Cohen's kappa
#'     \item \code{mcnemar_p} - McNemar p-value (NA if not 2x2)
#'     \item \code{per_gene} - per-gene agreement data frame
#'   }
#' @export
ctdna_mutation_concordance <- function(mut_df,
                                 panel_a = "ctDNA", panel_b = "WES",
                                 genes = NULL,
                                 filter_scheme = NULL,
                                 stat = c("both","kappa","agreement","mcnemar","none"),
                                 show_stats = .o("show_stats"),
                                 title = NULL, subtitle = NULL,
                                 caption = NULL,
                                 xlab = NULL, ylab = NULL,
    stat_position = .o("stat_position"),
    legend_position = .o("legend_position")) {
  .stats_label <- NULL

  stat <- match.arg(stat)
  scol <- .o("subject"); gcol <- .o("gene"); mcol <- .o("mutation"); pcol <- .o("panel")
  # Three-level filter system applied to mutation frame before per-panel split
  mut_df <- ctdna_filter_apply_scheme(mut_df, filter_scheme = filter_scheme,
                                        gene_col = gcol)
  if (!is.null(genes)) mut_df <- mut_df[mut_df[[gcol]] %in% genes, ]
  a <- mut_df[mut_df[[pcol]] == panel_a, c(scol, gcol, mcol)]
  b <- mut_df[mut_df[[pcol]] == panel_b, c(scol, gcol, mcol)]
  names(a)[3] <- "status_a"; names(b)[3] <- "status_b"
  m <- merge(a, b, by = c(scol, gcol))
  if (nrow(m) == 0) stop("No overlapping subject-gene rows between panels.")
  tab <- table(A = m$status_a, B = m$status_b)
  ct <- ctdna_concordance_test(tab, method = stat)
  per_gene <- do.call(rbind, lapply(split(m, m[[gcol]]), function(s) {
    t2 <- table(A = s$status_a, B = s$status_b)
    cm <- intersect(rownames(t2), colnames(t2))
    a2 <- sum(diag(as.matrix(t2)[cm, cm, drop = FALSE])) / sum(t2)
    data.frame(gene = unique(s[[gcol]]), n = nrow(s),
               agreement = a2, stringsAsFactors = FALSE)
  }))

  if (is.null(title))
    title <- sprintf("Mutation concordance: %s vs %s", panel_a, panel_b)
  if (show_stats && stat != "none" ) {
    parts <- c()
    if (stat %in% c("both","agreement"))
      parts <- c(parts, sprintf("Agreement = %.0f%%", 100 * ct$agreement))
    if (stat %in% c("both","kappa"))
      parts <- c(parts, sprintf("Cohen's kappa = %.2f", ct$kappa))
    if (stat == "mcnemar" && !is.na(ct$mcnemar_p))
      parts <- c(parts, sprintf("McNemar %s", ctdna_pval_label(ct$mcnemar_p)))
    parts <- c(parts, sprintf("N = %d", sum(tab)))
    .stats_label <- paste(parts, collapse = "  |  ")
  }
  per_gene$gene <- factor(per_gene$gene,
                          levels = per_gene$gene[order(per_gene$agreement)])
  # Embed n into the x-axis tick label so each bar has its sample size
  # underneath the gene name, freeing the bar-top label for the
  # agreement % only.
  gene_levels <- levels(per_gene$gene)
  new_x_labels <- setNames(
    sprintf("%s\n(n=%d)", gene_levels,
            per_gene$n[match(gene_levels, as.character(per_gene$gene))]),
    gene_levels)

  p <- ggplot2::ggplot(per_gene, ggplot2::aes(.data$gene, .data$agreement,
                                              fill = .data$agreement)) +
    ggplot2::geom_col() +
    ggplot2::geom_text(ggplot2::aes(label = sprintf("%.0f%%",
                                                    100 * .data$agreement)),
                       vjust = -0.5, size = 2.8, color = "grey20") +
    ggplot2::scale_fill_gradient(low = "#DEEBF7",
                                 high = "#3182BD",
                                 limits = c(0, 1), guide = "none") +
    ggplot2::scale_x_discrete(labels = new_x_labels) +
    ggplot2::scale_y_continuous(labels = scales::percent_format(),
                                limits = c(0, 1.15),
                                expand = ggplot2::expansion(mult = c(0, 0))) +
    ggplot2::labs(x = "Gene", y = "Per-gene agreement") +
    ctdna_theme() +
    ggplot2::theme(
      axis.text.x = ggplot2::element_text(angle = 90, vjust = 0.5,
                                           hjust = 1, size = 7,
                                           lineheight = 0.85),
      plot.margin = ggplot2::margin(8, 8, 8, 8))
  # Route stats label per stat_position option
  if (!is.null(.stats_label)) {
    .routed <- .route_stats(.stats_label, stat_position, subtitle, caption)
    subtitle <- .routed$subtitle; caption <- .routed$caption
    on_plot_label <- .routed$on_plot
  } else on_plot_label <- NULL
  p <- .annotate_stat(.finalize(p, title, subtitle, caption, xlab, ylab,
                                  legend_position = legend_position),
                       on_plot_label)
  table_plot <- ctdna_table(
    as.data.frame.matrix(tab),
    title    = sprintf("%s x %s mutation status (overall)", panel_a, panel_b),
    subtitle = sprintf("Agreement %.0f%% | Cohen's kappa = %.2f | N = %d",
                       100 * ct$agreement, ct$kappa, sum(tab)),
    caption  = "Counts of (subject,gene) pairs where both panels reported a call.",
    highlight_diag = TRUE)
  list(plot = p, table = tab, table_plot = table_plot,
       agreement = ct$agreement, kappa = ct$kappa, mcnemar_p = ct$mcnemar_p,
       per_gene = per_gene)
}


# ---- Combinatorial alteration grid ------------------------------------------
#
# Faceted stacked bar plot showing the rate of "any alteration" in
# pre-defined gene sets across patient subgroups (response category x
# indication / cancer type). Adapted from a common TM deliverable —
# columns are gene sets, rows are indications, x within each panel is
# the response category, fill is alt vs wt with text labels showing
# percentages and counts.
#
# Statistics: per panel, Fisher's exact test on the (response x alt/wt)
# contingency table; reported as p-value above each panel.
# -----------------------------------------------------------------------------

#' Combinatorial alteration grid (indication x gene set)
#'
#' Stacked-bar grid showing the proportion of patients with any
#' alteration in each of several gene sets, broken down by response
#' category and faceted by indication.
#'
#' Mirrors the deck-style "Combinatorial Alteration Status" plot:
#' rows = indication (e.g. cancer type), columns = gene set, x-axis
#' within each panel = response category, fill = "alt" vs "wt", with
#' percentage and count labels in each bar and a Fisher's-exact p-value
#' annotated in the top-left of each panel.
#'
#' "Alt" is defined as: the patient has at least one detected alteration
#' in any gene of that set (after filtering). "Wt" is the complement.
#'
#' @param df Alteration data frame (vendor or canonical schema).
#' @param gene_sets Named list of gene-symbol vectors (one column per set).
#' @param patient_data Per-patient frame with at least the patient ID,
#'   response category, and indication columns.
#' @param response_col Name of the response category column in
#'   \code{patient_data} (default \code{"RECIST"}).
#' @param indication_col Name of the indication / cancer-type column in
#'   \code{patient_data} (default \code{"Cancertype"}).
#' @param response_levels Optional level order for the x-axis (defaults
#'   to alphabetical order of values found in the data).
#' @param filter Optional named list of arguments forwarded to
#'   \code{\link{ctdna_filter_alterations}} before computing alt/wt
#'   status. NULL = use \code{df} as given.
#' @param patient_col,gene_col Column overrides (auto-detected when NULL).
#' @param stat \code{"fisher"} (default), \code{"chisq"}, or \code{"none"}.
#' @param show_counts If TRUE, write "n / total" in the bar segments.
#' @param title,subtitle,caption Display options.
#' @return list(plot, summary, stats) where \code{summary} is a long-
#'   format per-cell summary and \code{stats} is one p-value per panel.
#' @examples
#' sim <- ctdna_make_mock_study(n_patients = 100, seed = 1)
#' ctdna_plot_alteration_grid(
#'   sim$infinity_report,
#'   gene_sets = list(
#'     KRAS  = "KRAS",
#'     AV    = c("ALK","ROS1","NTRK1","BRAF","RET"),
#'     Hansh = c("BRCA1","BRCA2","ATM","CHEK2","PALB2"),
#'     TSG   = c("TP53","RB1","MYC"),
#'     TOP1  = c("TOP1","TOP2A","ERCC1")
#'   ),
#'   patient_data   = sim$clinical,
#'   response_col   = "RECIST",
#'   indication_col = "Cancertype",
#'   filter         = list(functional_impact = c("High","Moderate"),
#'                          verbose = FALSE))$plot
#' @export
ctdna_plot_alteration_grid <- function(df,
                                        gene_sets,
                                        patient_data,
                                        response_col    = "RECIST",
                                        indication_col  = "Cancertype",
                                        response_levels = NULL,
                                        scheme          = c("raw","two","three","four"),
                                        filter          = NULL,
                                        filter_scheme   = NULL,
                                        patient_col     = NULL,
                                        gene_col        = NULL,
                                        stat            = c("fisher","chisq","none"),
                                        show_counts     = TRUE,
                                        title    = "Combinatorial alteration status",
                                        subtitle = NULL,
                                        caption  = NULL) {
  stat <- match.arg(stat)
  scheme <- match.arg(scheme)

  if (!is.list(gene_sets) || is.null(names(gene_sets)))
    stop("`gene_sets` must be a NAMED list of gene-symbol vectors.")
  if (!is.data.frame(patient_data))
    stop("`patient_data` must be a data frame with patient ID + ",
         "response_col + indication_col.")

  # Apply scheme collapse to the response column if requested
  if (scheme != "raw" && response_col %in% names(patient_data)) {
    patient_data[[response_col]] <- ctdna_stratify_recist(
      patient_data[[response_col]], scheme)
  }

  if (!is.null(filter)) {
    if (!is.list(filter))
      stop("`filter` must be NULL or a named list of args to ctdna_filter_alterations()")
    df <- do.call(ctdna_filter_alterations, c(list(df = df), filter))
  }

  # Three-level filter system: NULL = general, name = specific scheme
  df <- ctdna_filter_apply_scheme(df, filter_scheme = filter_scheme,
                                    gene_col = gene_col)

  if (is.null(patient_col))
    patient_col <- .alt_col(df, c("Patient_ID", .o("subject"), "subject_id"))
  if (is.null(gene_col))
    gene_col    <- .alt_col(df, c("Gene", .o("gene"), "gene"))
  pid_p <- intersect(c(patient_col, "Patient_ID", "subject_id"),
                      names(patient_data))[1]
  if (is.na(pid_p))
    stop("Could not find a patient ID column in patient_data.")

  # All patients (from patient_data, so wt patients without alteration
  # rows still show up)
  all_pat <- patient_data[[pid_p]]

  # For each (patient, gene_set), is there any alteration?
  rows <- list()
  for (set_name in names(gene_sets)) {
    set_genes <- as.character(gene_sets[[set_name]])
    has_alt_pats <- unique(df[[patient_col]][
      !is.na(df[[gene_col]]) & df[[gene_col]] %in% set_genes])
    rows[[set_name]] <- data.frame(
      Patient_ID = all_pat,
      gene_set   = set_name,
      value      = ifelse(all_pat %in% has_alt_pats, "alt", "wt"),
      stringsAsFactors = FALSE)
  }
  long <- do.call(rbind, rows)
  names(long)[1] <- pid_p
  long$gene_set <- factor(long$gene_set, levels = names(gene_sets))

  # Join clinical
  pd <- patient_data[, c(pid_p, response_col, indication_col), drop = FALSE]
  long <- merge(long, pd, by = pid_p)

  if (is.null(response_levels))
    response_levels <- sort(unique(long[[response_col]]))
  long[[response_col]]   <- factor(long[[response_col]],   levels = response_levels)
  long[[indication_col]] <- factor(long[[indication_col]])
  long$value <- factor(long$value, levels = c("alt","wt"))

  # Per-cell summary
  summary <- aggregate(
    stats::as.formula(paste0("rep(1, nrow(long)) ~ ", indication_col, " + ",
                              response_col, " + gene_set + value")),
    data = transform(long, .one = 1),
    FUN  = length)
  names(summary)[5] <- "n"
  totals <- aggregate(
    stats::as.formula(paste0("n ~ ", indication_col, " + ",
                              response_col, " + gene_set")),
    data = summary, FUN = sum)
  names(totals)[4] <- "total"
  summary <- merge(summary, totals, by = c(indication_col, response_col, "gene_set"))
  summary$pct <- summary$n / summary$total

  # Per-panel stats
  stats_df <- NULL
  if (stat != "none") {
    keys <- unique(long[, c(indication_col, "gene_set")])
    stats_rows <- list()
    for (i in seq_len(nrow(keys))) {
      ind <- keys[i, indication_col]; gs <- keys[i, "gene_set"]
      sub <- long[long[[indication_col]] == ind & long$gene_set == gs, ]
      tab <- table(sub[[response_col]], sub$value)
      if (nrow(tab) < 2 || ncol(tab) < 2) {
        p <- NA_real_
      } else {
        if (stat == "fisher") {
          p <- tryCatch(stats::fisher.test(tab, workspace = 2e6,
                                            simulate.p.value = TRUE,
                                            B = 5000)$p.value,
                         error = function(e) NA_real_)
        } else {
          p <- tryCatch(suppressWarnings(
                          stats::chisq.test(tab)$p.value),
                         error = function(e) NA_real_)
        }
      }
      stats_rows[[i]] <- data.frame(
        setNames(list(ind, gs, p),
                  c(indication_col, "gene_set", "p")),
        stringsAsFactors = FALSE)
    }
    stats_df <- do.call(rbind, stats_rows)
    stats_df$label <- ctdna_pval_label(stats_df$p)
  }

  # Plot
  p <- ggplot2::ggplot(summary,
                       ggplot2::aes(x = .data[[response_col]], y = .data$pct,
                                    fill = .data$value)) +
    ggplot2::geom_col(width = 0.85, position = "stack") +
    ggplot2::scale_fill_manual(
      values = c(alt = "#F2786F", wt = "#3CB6BD"),
      breaks = c("alt","wt"),
      labels = c("alt","wt"),
      name   = "value") +
    ggplot2::scale_y_continuous(labels = scales::percent_format(),
                                 limits = c(0, 1.18),
                                 expand = ggplot2::expansion(mult = c(0, 0))) +
    ggplot2::facet_grid(stats::as.formula(paste0(indication_col,
                                                  " ~ gene_set")),
                         scales = "free", space = "fixed") +
    ctdna_theme() +
    ggplot2::theme(
      axis.text.x = ggplot2::element_text(angle = 90, vjust = 0.5, hjust = 1,
                                           size = 8),
      strip.text = ggplot2::element_text(face = "bold"),
      panel.spacing = grid::unit(0.4, "lines")) +
    ggplot2::labs(x = "Response category",
                   y = "Percent genetic alteration",
                   title = title, subtitle = subtitle, caption = caption)

  if (show_counts) {
    # Compute stack positions per (indication, response, gene_set)
    summary <- summary[order(summary[[response_col]],
                              summary[[indication_col]],
                              summary$gene_set, summary$value), ]
    keys <- with(summary, paste(get(indication_col),
                                  get(response_col), gene_set))
    summary$ymin <- 0; summary$ymax <- 0
    for (k in unique(keys)) {
      idx <- which(keys == k)
      sub <- summary[idx, ]
      sub <- sub[order(sub$value), ]   # alt first, then wt
      cum <- 0
      for (j in seq_len(nrow(sub))) {
        summary$ymin[idx[j]] <- cum
        cum <- cum + sub$pct[j]
        summary$ymax[idx[j]] <- cum
      }
    }
    summary$ymid <- (summary$ymin + summary$ymax) / 2

    # Label rules:
    # (a) alt segment >= 30% of bar: two-line label INSIDE the segment
    #     at its centre (well clear of the p-value annotation at bottom).
    # (b) alt segment between 0% and 30%: compact single-line label
    #     ABOVE the bar (each bar at its own x, so no horizontal overlap).
    label_df  <- summary[summary$value == "alt", , drop = FALSE]
    label_df$pct_text <- sprintf("%.0f%%", 100 * label_df$pct)
    label_df$n_text   <- sprintf("%d/%d",  label_df$n, label_df$total)

    big   <- label_df[label_df$pct >= 0.30, , drop = FALSE]
    small <- label_df[label_df$pct <  0.30 & label_df$pct > 0, , drop = FALSE]

    if (nrow(big) > 0) {
      big$lbl <- paste0(big$pct_text, "\n", big$n_text)
      p <- p + ggplot2::geom_text(
        data = big,
        ggplot2::aes(x = .data[[response_col]],
                      y = .data$ymid,
                      label = .data$lbl),
        size = 2.4, color = "grey10", fontface = "bold",
        lineheight = 0.85,
        inherit.aes = FALSE)
    }
    if (nrow(small) > 0) {
      small$lbl <- paste0(small$pct_text, " ", small$n_text)
      p <- p + ggplot2::geom_text(
        data = small,
        ggplot2::aes(x = .data[[response_col]],
                      y = 1.03,
                      label = .data$lbl),
        size = 2.2, color = "grey25", inherit.aes = FALSE,
        vjust = 0)
    }
  }

  if (!is.null(stats_df)) {
    # Place p-value at the TOP-LEFT corner inside each panel; clears the
    # alt-segment labels (which sit at any x-position within the panel
    # at y = ymid or y = 1.03 above the bar). The bar at x=1 is rare
    # for small labels in practice.
    p <- p + ggplot2::geom_text(
      data = stats_df,
      ggplot2::aes(x = -Inf, y = 1.15, label = .data$label),
      hjust = -0.08, vjust = 1, size = 2.4, color = "grey30",
      fontface = "italic",
      inherit.aes = FALSE)
  }

  list(plot = p, summary = summary, stats = stats_df)
}
