# ============================================================================
# ctdnaTM — configuration, helpers, theme, colors, example data
# ============================================================================

# Private env holding the live config
.env <- new.env(parent = emptyenv())

# Dose palette. Matches the source deck's baseline / reduction plots
# (blue / yellow / gray for 2.8 / 4.8 / 5.8 mg/kg). Same primaries as
# the RECIST palette by design — when plots are stratified by dose OR
# RECIST (not both), the colors are consistent across the deck.
.dose_pal <- c("#1F77B4", "#E6B800", "#7F7F7F", "#4A4A4A", "#D62728")

# Factory defaults
.defaults <- list(
  # ---- ctDNA column names ----
  subject       = "subject_id",
  time          = "time_point",
  baseline      = "Baseline",
  dose          = "dose",
  cohort        = "cohort",
  recist        = "RECIST",
  tf            = "methylTF",
  maxaf         = "maxAF",
  cfdna_conc    = "cfdna.conc",
  n_somatic     = "n.somatic",
  tmb           = "tmb",
  mr            = "MR",
  best_change   = "best_pct_change",

  # ---- Numeric parameters ----
  display_floor = 0.001,   # pinning value for log-scale plots: any TF/MR
                           # value below this gets shown at this value
                           # (so they don't disappear at -Inf on log axes)
  loq           = 0.01,
  discord_log10 = 1,

  # ---- RECIST value mapping ----
  recist_crpr   = c("CR", "PR", "CR/PR"),
  recist_ucrpr  = c("uCR", "uPR", "uCR/PR"),
  recist_sd     = c("SD"),
  recist_pdnena = c("PD", "NE", "NA"),

  # ---- Statistics defaults ----
  pairwise_test = "wilcox",
  cor_method    = "spearman",
  alpha         = 0.05,

  # ---- Plot display defaults ----
  point_size      = 2,
  point_alpha     = 0.85,
  show_stats      = TRUE,
  show_n          = TRUE,
  median_color    = "grey20",
  clearance_color = "grey40",
  stat_position   = "subtitle",   # where stats labels appear:
                                  # "subtitle" / "caption" / "on_plot" / "none"
  legend_position = "right",      # ggplot legend position:
                                  # "right" / "left" / "top" / "bottom" / "none"

  # ---- Expression units ----
  # Canonical unit for the multi-modal expression frame; canonicalize_expression()
  # auto-converts TPM matrices to log2(tpm+1). Two valid values:
  #   "log2_tpm_plus_one" (default) — recommended; ratios are linear in log space
  #   "tpm" — raw TPM (rarely a good default for stats / plots)
  expression_unit = "log2_tpm_plus_one",

  # ---- Multi-modal column names ----
  gene          = "gene",
  expression    = "expression",
  mutation      = "mutation_status",
  panel         = "panel",
  marker        = "marker",
  ihc_score     = "score",
  alteration    = "alteration_type",
  ctdna_metric  = "best_ratio"
)

.env$cfg <- .defaults

#' Get, set, print, reset, or bulk-load ctdnaTM options
#'
#' Single entry point for configuration. Works like base R `options()`.
#'
#' Modes (mutually exclusive):
#' \itemize{
#'   \item No args → print and invisibly return current config
#'   \item One or more unnamed character keys → get values
#'   \item Named arguments → set values
#'   \item \code{.reset = TRUE} → restore factory defaults
#'   \item \code{load = list(...)} → bulk-load a saved config (replaces
#'         the older \code{do.call(ctdna_opts, cfg)} idiom)
#' }
#'
#' @param ... Unnamed character key(s) to get, or named values to set.
#' @param load Optional named list of options to apply in one call
#'   (typically read back from \code{readRDS()}).
#' @param .reset If TRUE, reset to factory defaults.
#' @return Invisibly, the current config (or the requested value).
#' @examples
#' \dontrun{
#' # Configure for a study and save the config
#' ctdna_opts(tf = "TF_methyl_v3", maxaf = "MAX_AF")
#' saveRDS(ctdna_opts(), "study123_config.rds")
#'
#' # In a fresh session — load the config in one call
#' cfg <- readRDS("study123_config.rds")
#' ctdna_opts(load = cfg)
#' }
#' @export
ctdna_opts <- function(..., load = NULL, .reset = FALSE) {
  if (isTRUE(.reset)) { .env$cfg <- .defaults; return(invisible(.env$cfg)) }
  if (!is.null(load)) {
    if (!is.list(load) || is.null(names(load)))
      stop("`load` must be a named list of option values.")
    bad <- setdiff(names(load), names(.defaults))
    if (length(bad))
      stop("Unknown key(s) in load: ", paste(bad, collapse = ", "))
    for (k in names(load)) .env$cfg[[k]] <- load[[k]]
    return(invisible(.env$cfg))
  }
  args <- list(...)
  if (length(args) == 0) { .print_opts(); return(invisible(.env$cfg)) }
  if (is.null(names(args)) || all(names(args) == "")) {
    keys <- unlist(args)
    bad <- setdiff(keys, names(.defaults))
    if (length(bad)) stop("Unknown key(s): ", paste(bad, collapse = ", "))
    if (length(keys) == 1) return(.env$cfg[[keys]])
    return(.env$cfg[keys])
  }
  bad <- setdiff(names(args), names(.defaults))
  if (length(bad))
    stop("Unknown key(s): ", paste(bad, collapse = ", "),
         "\nValid: ", paste(names(.defaults), collapse = ", "))
  for (k in names(args)) .env$cfg[[k]] <- args[[k]]
  invisible(.env$cfg)
}

.print_opts <- function() {
  cfg <- .env$cfg
  fmt <- function(v) if (length(v) > 1) paste0("[", paste(v, collapse = ", "), "]") else as.character(v)
  mark <- function(k) if (!identical(cfg[[k]], .defaults[[k]])) " *" else ""
  groups <- list(
    "ctDNA columns" = c("subject","time","baseline","dose","cohort","recist",
                        "tf","maxaf","cfdna_conc","n_somatic","tmb","mr",
                        "best_change"),
    "Numeric"       = c("display_floor","loq","discord_log10","alpha"),
    "RECIST values" = c("recist_crpr","recist_ucrpr","recist_sd","recist_pdnena"),
    "Statistics"    = c("pairwise_test","cor_method"),
    "Plot defaults" = c("point_size","point_alpha","show_stats","show_n",
                        "median_color","clearance_color",
                        "stat_position","legend_position"),
    "Units"         = c("expression_unit"),
    "Multi-modal"   = c("gene","expression","mutation","panel","marker",
                        "ihc_score","alteration","ctdna_metric")
  )
  cat("ctdnaTM options (* = modified)\n")
  for (g in names(groups)) {
    cat(sprintf("\n  %s\n", g))
    for (k in groups[[g]])
      cat(sprintf("    %-15s : %s%s\n", k, fmt(cfg[[k]]), mark(k)))
  }
  cat("\n  set:   ctdna_opts(tf = 'TF_v3')   get: ctdna_opts('tf')   reset: ctdna_opts(.reset = TRUE)\n")
}

# Internal shortcut
.o <- function(k) .env$cfg[[k]]


# ---- Utilities --------------------------------------------------------------

# Null-coalescing helper (avoid taking on rlang dep)
`%||%` <- function(a, b) if (is.null(a)) b else a

#' Pin tiny ctDNA values for log-scale display
#'
#' Replaces any value smaller than \code{at} with \code{at}. Used before
#' a log scale so that undetectable / sub-floor measurements still appear
#' on the plot instead of becoming \code{-Inf}. Default is
#' \code{ctdna_opts("display_floor")} (0.001 by default).
#' @param x Numeric vector (ctDNA TF or MR values, in fraction units).
#' @param at Floor value (default \code{ctdna_opts("display_floor")}).
#' @return Numeric vector the same length as x, with values \eqn{\geq} at.
#' @export
ctdna_floor_tf <- function(x, at = .o("display_floor")) pmax(as.numeric(x), at)

#' Stratify RECIST into 2/3/4 groups
#'
#' Mapping of raw labels to canonical groups is taken from ctdna_opts()
#' so non-standard labels can be remapped via the config.
#'
#' @param x Character vector of raw RECIST values.
#' @param scheme One of `"two"`, `"three"`, `"four"`.
#' @return Ordered factor.
#' @export
ctdna_stratify_recist <- function(x, scheme = c("two", "three", "four")) {
  scheme <- match.arg(scheme)
  x <- as.character(x); x[is.na(x)] <- "NA"
  is_crpr  <- x %in% .o("recist_crpr")
  is_ucrpr <- x %in% .o("recist_ucrpr")
  is_sd    <- x %in% .o("recist_sd")
  out <- switch(scheme,
    two   = ifelse(is_crpr, "R", "NR"),
    three = ifelse(is_crpr, "CR/PR", ifelse(is_ucrpr, "uCR/PR", "SD/PD/NE/NA")),
    four  = ifelse(is_crpr, "CR/PR", ifelse(is_ucrpr, "uCR/PR",
                  ifelse(is_sd, "SD", "PD/NE/NA")))
  )
  lvls <- switch(scheme,
    two   = c("R", "NR"),
    three = c("CR/PR", "uCR/PR", "SD/PD/NE/NA"),
    four  = c("CR/PR", "uCR/PR", "SD", "PD/NE/NA"))
  factor(out, levels = lvls)
}

#' On-treatment / baseline ratio with LOQ exclusion
#' @param df Long data frame.
#' @return Filtered data with `baseline_tf` and `ratio` added.
#' @export
ctdna_ratio <- function(df) {
  s <- .o("subject"); t <- .o("time"); tf <- .o("tf")
  bl <- .o("baseline"); loq <- .o("loq")
  stopifnot(all(c(s, t, tf) %in% names(df)))
  base <- df[df[[t]] == bl, c(s, tf), drop = FALSE]
  names(base)[2] <- "baseline_tf"
  out <- merge(df, base, by = s, all.x = TRUE)
  out <- out[!is.na(out$baseline_tf) & out$baseline_tf > 0, , drop = FALSE]
  drop_row <- out$baseline_tf < loq & out[[tf]] < loq & out[[t]] != bl
  out <- out[!drop_row, , drop = FALSE]
  out$ratio <- out[[tf]] / out$baseline_tf
  out
}

#' Per-subject ctDNA summary for multi-modal integration
#'
#' Collapses a longitudinal ctDNA dataset into one row per subject with
#' canonical metrics (baseline TF, best ratio, last TF) and metadata.
#' Bridge between ctDNA and other modalities.
#'
#' @param df Longitudinal ctDNA data frame.
#' @return Data frame: one row per subject.
#' @export
ctdna_summary <- function(df) {
  s <- .o("subject"); t <- .o("time"); tf <- .o("tf"); bl <- .o("baseline")
  ratio_df <- ctdna_ratio(df)
  rdf <- ratio_df[ratio_df[[t]] != bl, , drop = FALSE]
  best <- stats::aggregate(ratio ~ get(s), data = rdf, FUN = min)
  names(best) <- c(s, "best_ratio")
  last_tp <- utils::tail(sort(unique(df[[t]][df[[t]] != bl])), 1)
  last_df <- df[df[[t]] == last_tp, c(s, tf), drop = FALSE]
  names(last_df)[2] <- "last_tf"
  base_df <- df[df[[t]] == bl, c(s, tf), drop = FALSE]
  names(base_df)[2] <- "baseline_tf"
  meta_cols <- intersect(c(.o("recist"), .o("dose"), .o("cohort"),
                            .o("mr"), .o("best_change")), names(df))
  meta <- unique(df[, c(s, meta_cols), drop = FALSE])
  Reduce(function(a, b) merge(a, b, by = s, all = TRUE),
         list(base_df, best, last_df, meta))
}


#' Compute molecular response (MR) from longitudinal ctDNA data
#'
#' Derives a per-subject Response / NonResponse call from a longitudinal
#' ctDNA frame, by comparing the on-treatment tumor fraction (TF) to
#' baseline. Two modes are available:
#' \itemize{
#'   \item \code{at = "best"} (default): per subject, take the BEST
#'     (deepest) on-treatment / baseline ratio. The subject is called
#'     \code{"Response"} if that best ratio is \eqn{\le} \code{threshold},
#'     else \code{"NonResponse"}.
#'   \item \code{at = "<time_point>"} (e.g. \code{"C5D1"}): use the TF
#'     at that specific time-point. The subject is called
#'     \code{"Response"} if \eqn{TF_t / TF_{baseline} \le} \code{threshold}.
#' }
#'
#' The threshold is a fold-change ratio (not a percent). The default
#' \code{0.5} corresponds to "TF dropped by at least 50%". Subjects
#' missing the requested timepoint return \code{NA}.
#'
#' @param df Longitudinal ctDNA data with canonical columns
#'   (subject, time, tf — names per \code{ctdna_opts()}).
#' @param at \code{"best"} (default) or a string matching one of the
#'   on-treatment time-point labels in the data (e.g. \code{"C5D1"}).
#' @param threshold Ratio (TF / baseline TF) at or below which the
#'   subject is called a molecular responder. Default 0.5.
#' @return Data frame: one row per subject with columns
#'   \code{subject}, \code{baseline_tf}, \code{ratio}, \code{MR}, plus
#'   the time-point used (for traceability).
#' @examples
#' mm <- ctdna_make_example_multimodal(n_subjects = 30)
#' ctdna_compute_mr(mm$ctdna)                       # best-ratio MR
#' ctdna_compute_mr(mm$ctdna, at = "C5D1")          # MR at a specific visit
#' ctdna_compute_mr(mm$ctdna, threshold = 0.3)      # stricter (70% drop required)
#' @export
ctdna_compute_mr <- function(df, at = "best", threshold = 0.5) {
  s_col  <- .o("subject"); t_col <- .o("time")
  tf_col <- .o("tf");      bl    <- .o("baseline")

  base <- df[df[[t_col]] == bl, c(s_col, tf_col), drop = FALSE]
  names(base) <- c(s_col, "baseline_tf")

  if (identical(at, "best") || identical(at, "BEST")) {
    rdf <- ctdna_ratio(df)
    rdf <- rdf[rdf[[t_col]] != bl, , drop = FALSE]
    if (nrow(rdf) == 0) {
      out <- merge(base, data.frame(setNames(list(character(0), numeric(0)),
                   c(s_col, "ratio"))), by = s_col, all.x = TRUE)
      out$MR <- NA_character_
      out$time_used <- "best"
      return(out)
    }
    best <- stats::aggregate(ratio ~ get(s_col), data = rdf, FUN = min)
    names(best) <- c(s_col, "ratio")
    out <- merge(base, best, by = s_col, all.x = TRUE)
    out$time_used <- "best"
  } else {
    if (!at %in% df[[t_col]])
      stop("Time-point '", at, "' not found in column '", t_col,
           "'. Available: ",
           paste(unique(df[[t_col]]), collapse = ", "))
    tp_df <- df[df[[t_col]] == at, c(s_col, tf_col), drop = FALSE]
    names(tp_df) <- c(s_col, "tf_at")
    out <- merge(base, tp_df, by = s_col, all.x = TRUE)
    out$ratio    <- out$tf_at / out$baseline_tf
    out$tf_at    <- NULL
    out$time_used <- at
  }
  out$MR <- ifelse(is.na(out$ratio), NA_character_,
                   ifelse(out$ratio <= threshold, "Response", "NonResponse"))
  out[, c(s_col, "baseline_tf", "ratio", "MR", "time_used")]
}


#' Per-subject ctDNA value at "best" or a specific time-point
#'
#' Computes a single per-subject value from a longitudinal ctDNA frame,
#' on any of three scales, at either the best on-treatment time-point
#' (deepest response) or a specific named visit. Used by the
#' cross-modality plots and \code{ctdna_plot_reduction()} to give the
#' user flexible control over what "ctDNA reduction" means.
#'
#' \strong{Metric definitions:}
#' \itemize{
#'   \item \code{"ratio"} = \eqn{TF_t / TF_{baseline}}. Values in [0, ~1].
#'         0.1 means TF dropped to 10\% of baseline. This is the
#'         classical "molecular reduction" ratio. A threshold of 0.5
#'         (default for MR classification) means "TF dropped by at
#'         least 50\%".
#'   \item \code{"tf"} = raw tumor fraction at the chosen visit
#'         (\eqn{TF_t}). Useful when the absolute value matters.
#'   \item \code{"pct_change"} = \eqn{100 \times (TF_t - TF_{baseline}) /
#'         TF_{baseline}}. Negative values = reduction. -90\% is a
#'         strong response.
#' }
#'
#' \strong{Time-point definitions:}
#' \itemize{
#'   \item \code{at = "best"} - per subject, take the on-treatment
#'         visit with the LOWEST ratio (the deepest molecular response).
#'   \item \code{at = "<visit>"} (e.g. \code{"C5D1"}) - use the value at
#'         that specific visit. Subjects missing the visit return NA.
#'   \item \code{at = "last"} - use the chronologically last on-treatment
#'         visit per subject.
#' }
#'
#' @param df Longitudinal ctDNA data with canonical columns
#'   (subject, time, tf - per current \code{ctdna_opts()}).
#' @param metric \code{"ratio"} (default) / \code{"tf"} / \code{"pct_change"}.
#' @param at \code{"best"} (default) / \code{"last"} / named visit.
#' @return Data frame: one row per subject, with columns
#'   \code{subject}, \code{baseline_tf}, \code{value} (the requested
#'   metric), and \code{time_used} (for traceability).
#' @examples
#' mm <- ctdna_make_example_multimodal(n_subjects = 20, seed = 1)
#'
#' # Default — best-ratio per subject
#' head(ctdna_metric_at(mm$ctdna))
#'
#' # TF at C5D1
#' head(ctdna_metric_at(mm$ctdna, metric = "tf", at = "C5D1"))
#'
#' # Percentage change at the last on-treatment visit
#' head(ctdna_metric_at(mm$ctdna, metric = "pct_change", at = "last"))
#' @export
ctdna_metric_at <- function(df,
                             metric = c("ratio","tf","pct_change"),
                             at     = "best") {
  metric <- match.arg(metric)
  s_col <- .o("subject"); t_col <- .o("time")
  tf_col <- .o("tf"); bl <- .o("baseline")

  base <- df[df[[t_col]] == bl, c(s_col, tf_col), drop = FALSE]
  names(base) <- c(s_col, "baseline_tf")

  if (identical(at, "best") || identical(at, "BEST")) {
    rdf <- ctdna_ratio(df)
    rdf <- rdf[rdf[[t_col]] != bl, , drop = FALSE]
    if (nrow(rdf) == 0) {
      out <- merge(base,
                    data.frame(setNames(list(character(0), numeric(0),
                                              numeric(0), character(0)),
                                         c(s_col, "ratio", "tf_at",
                                           "time_used"))),
                    by = s_col, all.x = TRUE)
      out$value <- NA_real_
      return(out[, c(s_col, "baseline_tf", "value", "time_used")])
    }
    # Per subject, take the visit with the lowest ratio
    rdf <- rdf[order(rdf[[s_col]], rdf$ratio), ]
    rdf <- rdf[!duplicated(rdf[[s_col]]), ]
    rdf$time_used <- rdf[[t_col]]
    # Get the TF at that best visit
    keys <- paste(rdf[[s_col]], rdf$time_used)
    tf_at <- df[paste(df[[s_col]], df[[t_col]]) %in% keys,
                 c(s_col, t_col, tf_col), drop = FALSE]
    names(tf_at)[3] <- "tf_at"
    rdf <- merge(rdf[, c(s_col, "ratio", "time_used")],
                  tf_at, by.x = c(s_col, "time_used"),
                  by.y = c(s_col, t_col), all.x = TRUE)
    out <- merge(base, rdf, by = s_col, all.x = TRUE)
  } else if (identical(at, "last")) {
    on_tx <- df[df[[t_col]] != bl, , drop = FALSE]
    on_tx <- on_tx[order(on_tx[[s_col]], on_tx[[t_col]]), ]
    on_tx <- on_tx[!duplicated(on_tx[[s_col]], fromLast = TRUE), ]
    last_df <- on_tx[, c(s_col, t_col, tf_col), drop = FALSE]
    names(last_df) <- c(s_col, "time_used", "tf_at")
    out <- merge(base, last_df, by = s_col, all.x = TRUE)
    out$ratio <- out$tf_at / out$baseline_tf
  } else {
    if (!at %in% df[[t_col]])
      stop("Time-point '", at, "' not found. Available: ",
           paste(unique(df[[t_col]]), collapse = ", "))
    tp_df <- df[df[[t_col]] == at, c(s_col, tf_col), drop = FALSE]
    names(tp_df) <- c(s_col, "tf_at")
    out <- merge(base, tp_df, by = s_col, all.x = TRUE)
    out$ratio <- out$tf_at / out$baseline_tf
    out$time_used <- at
  }

  out$value <- switch(metric,
    ratio      = out$ratio,
    tf         = out$tf_at,
    pct_change = 100 * (out$tf_at - out$baseline_tf) / out$baseline_tf)
  out[, c(s_col, "baseline_tf", "value", "time_used")]
}


# ---- Color scheme + theme ---------------------------------------------------

#' Unified RECIST color scheme (per pipeline conventions §1.5)
#'
#' CR/PR = light blue, uCR/PR = yellow, SD = gray, PD/NE/NA = red.
#' Hex codes match the source deck's reduction / baseline plots exactly.
#' These are the *outline* / *point* / *median* colors; box fills use the
#' same hue at alpha = 0.3, applied by the plot functions automatically.
#'
#' @export
ctdna_colors <- function() c(
  # Collapsed labels (used by `scheme` outputs)
  "CR/PR"       = "#1F77B4",   # saturated blue
  "uCR/PR"      = "#E6B800",   # saturated gold/yellow
  "SD"          = "#7F7F7F",   # medium gray
  "SD/PD/NE/NA" = "#7F7F7F",
  "PD/NE/NA"    = "#D62728",   # red
  "R"           = "#1F77B4",
  "NR"          = "#7F7F7F",
  # Raw RECIST values (so palettes work even without scheme collapse)
  "CR"          = "#1F77B4",
  "PR"          = "#1F77B4",
  "uCR"         = "#E6B800",
  "uPR"         = "#E6B800",
  "PD"          = "#D62728",
  "NE"          = "#D62728",
  "NA"          = "#D62728"
)

#' Dose color palette
#'
#' Distinct from `ctdna_colors()` so dose and RECIST never visually collide.
#'
#' @param n Number of levels.
#' @export
ctdna_dose_palette <- function(n = 3) {
  if (n <= length(.dose_pal)) .dose_pal[seq_len(n)] else
    grDevices::colorRampPalette(.dose_pal)(n)
}

#' ggplot2 color scale for RECIST (outlines, points, lines)
#' @param ... Passed to ggplot2::scale_color_manual.
#' @export
ctdna_scale_recist <- function(...) {
  ggplot2::scale_color_manual(values = ctdna_colors(), na.value = "grey70", ...)
}

#' ggplot2 fill scale for RECIST (box fills, ribbon fills)
#'
#' Uses the same hex values as [ctdna_scale_recist()]. Pair with
#' `geom_boxplot(alpha = 0.3, ...)` to get the deck's light-fill +
#' strong-outline boxplot style.
#'
#' @param ... Passed to ggplot2::scale_fill_manual.
#' @export
ctdna_scale_recist_fill <- function(...) {
  ggplot2::scale_fill_manual(values = ctdna_colors(), na.value = "grey85", ...)
}

#' ggplot2 color scale for dose
#' @param ... Passed to ggplot2::scale_color_manual.
#' @export
ctdna_scale_dose <- function(...) {
  ggplot2::scale_color_manual(values = ctdna_dose_palette(8),
                              na.value = "grey70", ...)
}

#' ggplot2 fill scale for dose
#'
#' Same hexes as [ctdna_scale_dose()]. Pair with `geom_boxplot(alpha = 0.3)`
#' for the deck's light-fill + strong-outline style.
#'
#' @param ... Passed to ggplot2::scale_fill_manual.
#' @export
ctdna_scale_dose_fill <- function(...) {
  ggplot2::scale_fill_manual(values = ctdna_dose_palette(8),
                             na.value = "grey85", ...)
}

#' Canonical shape scale for dose
#'
#' Use this when RECIST already occupies the colour aesthetic and dose
#' needs a second visual channel. Canonical shapes per dose tier:
#' \itemize{
#'   \item Low  = circle (16)
#'   \item Mid  = triangle (17)
#'   \item High = square (15)
#'   \item additional doses cycle through diamond, plus, cross, asterisk
#' }
#' Combined with [ctdna_scale_recist()] for RECIST colour, this gives a
#' clear two-channel encoding (colour = RECIST, shape = dose).
#'
#' @param ... Passed to ggplot2::scale_shape_manual.
#' @export
ctdna_scale_dose_shape <- function(...) {
  values <- c(Low = 16, Mid = 17, High = 15,
              "Very Low" = 1, "Very High" = 18,
              # numeric ordering fall-throughs
              `1` = 16, `2` = 17, `3` = 15, `4` = 18,
              `5` = 1,  `6` = 2,  `7` = 0,  `8` = 5)
  ggplot2::scale_shape_manual(values = values, na.value = 4, ...)
}

#' ggplot2 theme for ctDNA deliverables
#'
#' Clean theme matching the source deck plots: white panel, light gray
#' strip backgrounds, subtle grid, thin panel border.
#'
#' @param base_size Base font size.
#' @export
ctdna_theme <- function(base_size = 12) {
  ggplot2::theme_bw(base_size = base_size) +
    ggplot2::theme(
      panel.background  = ggplot2::element_rect(fill = "white", color = NA),
      panel.border      = ggplot2::element_rect(color = "grey50",
                                                fill  = NA,
                                                linewidth = 0.4),
      panel.grid.major  = ggplot2::element_line(color = "grey92",
                                                linewidth = 0.3),
      panel.grid.minor  = ggplot2::element_blank(),
      strip.background  = ggplot2::element_rect(fill = "grey85", color = NA),
      strip.text        = ggplot2::element_text(face = "bold",
                                                color = "grey15"),
      axis.title        = ggplot2::element_text(face = "bold"),
      axis.text         = ggplot2::element_text(color = "grey20"),
      plot.title        = ggplot2::element_text(face = "bold",
                                                size = base_size + 1),
      plot.subtitle     = ggplot2::element_text(face = "italic",
                                                color = "grey30",
                                                size = base_size - 1),
      plot.caption      = ggplot2::element_text(color = "grey40",
                                                size = base_size - 2),
      legend.background = ggplot2::element_blank(),
      legend.key        = ggplot2::element_blank()
    )
}


# ---- Example data -----------------------------------------------------------

# Internal helper: rename internal canonical names in a data frame to whatever
# the user has configured via ctdna_opts(). For example, after
#   ctdna_opts(tf = "TF_methyl_v3")
# .apply_opts_names(df, c(methylTF = "tf")) will rename df$methylTF -> df$TF_methyl_v3.
.apply_opts_names <- function(df, name_map) {
  # name_map: named character vector where names are current df column names
  # (canonical) and values are ctdna_opts keys whose live value should be used.
  current <- names(df)
  for (i in seq_along(current)) {
    if (current[i] %in% names(name_map)) {
      current[i] <- .o(name_map[[current[i]]])
    }
  }
  names(df) <- current
  df
}

# Internal: synthetic ctDNA generator used by ctdna_make_example_multimodal().
# Retired from the public API in v0.7.0; kept here as a private helper so
# canonical-shape mock data (used by tests and most existing examples)
# stays available without a public surface for new code.
.make_example_data <- function(n_subjects = 40,
                              time_points = c("Baseline","C2D1","C3D1","C5D1"),
                              doses = c("Low","Mid","High"),
                              seed = 42) {
  set.seed(seed)
  rec_levels <- c("CR","PR","uCR","SD","PD","NE")
  subj <- sprintf("S%03d", seq_len(n_subjects))
  dose <- sample(doses, n_subjects, replace = TRUE)
  rec  <- sample(rec_levels, n_subjects, replace = TRUE,
                 prob = c(0.15, 0.20, 0.10, 0.30, 0.20, 0.05))
  base_tf <- 10 ^ stats::runif(n_subjects, -3, -0.5)
  base_af <- base_tf * 10 ^ stats::rnorm(n_subjects, 0, 0.3)
  dose_eff <- c(Low = 0.3, Mid = 0.7, High = 1.2)
  rec_eff  <- c(CR = 2, PR = 1.5, uCR = 1, SD = 0.6, PD = -0.1, NE = 0.2)
  rows <- list()
  for (i in seq_len(n_subjects)) {
    for (k in seq_along(time_points)) {
      tp <- time_points[k]
      if (k == 1) { tf <- base_tf[i]; af <- base_af[i] }
      else {
        lr <- -(dose_eff[[dose[i]]] + rec_eff[[rec[i]]]) * (0.5 + 0.3 * (k - 1)) +
          stats::rnorm(1, 0, 0.3)
        tf <- max(base_tf[i] * 10 ^ lr, 1e-4)
        af <- max(base_af[i] * 10 ^ (lr + stats::rnorm(1, 0, 0.2)), 1e-4)
      }
      rows[[length(rows) + 1]] <- data.frame(
        subject_id = subj[i], time_point = tp, dose = dose[i],
        RECIST = rec[i], methylTF = tf, maxAF = af,
        stringsAsFactors = FALSE)
    }
  }
  out <- do.call(rbind, rows)
  best <- c(CR = -100, PR = -50, uCR = -25, SD = -10, PD = 25, NE = 0)
  bc <- data.frame(subject_id = subj, RECIST = rec,
                   best_pct_change = best[rec] + stats::rnorm(n_subjects, 0, 8),
                   stringsAsFactors = FALSE)
  out <- merge(out, bc, by = c("subject_id", "RECIST"))
  last <- time_points[length(time_points)]
  rl <- out$methylTF[out$time_point == last] /
        out$methylTF[out$time_point == time_points[1]]
  mr <- data.frame(subject_id = subj,
                   MR = ifelse(rl < 0.5, "Response", "NonResponse"),
                   stringsAsFactors = FALSE)
  out <- merge(out, mr, by = "subject_id")

  # Rename internal canonical names -> current ctdna_opts() values
  .apply_opts_names(out, c(
    subject_id      = "subject",
    time_point      = "time",
    dose            = "dose",
    RECIST          = "recist",
    methylTF        = "tf",
    maxAF           = "maxaf",
    best_pct_change = "best_change",
    MR              = "mr"
  ))
}

#' Generate synthetic multi-modal data
#'
#' Returns a list of long-format data frames sharing a subject key. The
#' ctDNA portion mirrors the **Guardant Health Infinity** product, which
#' delivers three reports per timepoint:
#'
#' - **ctdna**: per-timepoint methylation tumor fraction (the canonical
#'   long-format ctDNA frame consumed by D1-D8 plots)
#' - **genomic_74**: 74-gene panel — per-subject per-gene calls with
#'   `alteration_type` in {wt, snv, cnv_amp, cnv_loss, lgr, fusion} and
#'   `vaf` for SNVs
#' - **genomic_500**: 500-gene panel — same shape, superset of genes
#'
#' Plus the cross-modality companions: expression, tmb (per-panel), ihc.
#'
#' All column names follow the current `ctdna_opts()` configuration —
#' renaming opts before calling this function will produce data with the
#' renamed columns.
#'
#' @param n_subjects Number of subjects.
#' @param seed Random seed for reproducibility.
#' @param vendor Vendor label stored as the list's `platform` attribute.
#' @param technology Technology label, combined with vendor.
#' @return Named list: `ctdna`, `genomic_74`, `genomic_500`, `expression`,
#'   `tmb`, `ihc`. The list has a `platform` attribute (e.g.
#'   `"guardant_health_infinity"`).
#' @export
ctdna_make_example_multimodal <- function(n_subjects = 40, seed = 42,
                                    vendor = "guardant_health",
                                    technology = "infinity") {
  set.seed(seed)
  ctdna <- .make_example_data(n_subjects = n_subjects, seed = seed)
  subj <- unique(ctdna[[.o("subject")]])
  rec_df <- unique(ctdna[, c(.o("subject"), .o("recist"))])
  rec_eff <- c(CR = 2, PR = 1.5, uCR = 1, SD = 0, PD = -1, NE = 0)
  beta <- rec_eff[rec_df[[.o("recist")]]]

  # ---- RNA-seq (long format) ----
  rna_genes <- c("CD8A", "PDL1", "IFNG", "MKI67", "TGFB1")
  expr <- do.call(rbind, lapply(rna_genes, function(g) {
    mu <- ifelse(g %in% c("CD8A","PDL1","IFNG"), 0.7 * beta, -0.5 * beta)
    df <- data.frame(
      subject_id = rec_df[[.o("subject")]],
      gene       = g,
      expression = 5 + mu + stats::rnorm(length(beta), 0, 1),
      stringsAsFactors = FALSE)
    .apply_opts_names(df, c(subject_id = "subject", gene = "gene",
                            expression = "expression"))
  }))
  # Synthetic values are already in log2(TPM+1)-like scale (centred on 5)
  attr(expr, "units") <- "log2_tpm_plus_one"

  # ---- Genomic panels (GH Infinity-style): 74-gene + 500-gene ----
  # Per-subject per-gene calls with alteration_type covering the full
  # spectrum reported by Infinity: SNV, CNV amp/loss, LGR, fusion.
  genes_74 <- c("TP53","KRAS","EGFR","BRAF","PIK3CA","ERBB2","MET","RET",
                "ROS1","ALK","NRAS","PTEN","CDKN2A","FGFR1","FGFR3",
                "IDH1","IDH2","KIT","CCND1","CDK4")
  genes_500_only <- c("BRCA1","BRCA2","ATM","CHEK2","RB1","NF1","APC",
                      "MSH2","MLH1","STK11","PALB2","BARD1","BAP1","BLM")
  genes_500 <- c(genes_74, genes_500_only)
  alt_types <- c("wt","snv","cnv_amp","cnv_loss","lgr","fusion")
  base_probs <- c(0.70, 0.15, 0.05, 0.05, 0.03, 0.02)

  .gen_panel <- function(panel_genes, panel_label) {
    do.call(rbind, lapply(panel_genes, function(g) {
      # Tweak per-gene mutation prior (TP53/KRAS more frequently altered)
      gene_boost <- if (g == "TP53") 0.15
                    else if (g == "KRAS") 0.10
                    else if (g %in% c("PIK3CA","EGFR")) 0.05 else 0
      p <- base_probs
      p[1] <- p[1] - gene_boost; p[2] <- p[2] + gene_boost
      alt <- sample(alt_types, length(subj), replace = TRUE, prob = p)
      vaf <- ifelse(alt == "snv",
                    pmin(stats::rbeta(length(subj), 2, 50) * 100, 50),
                    NA_real_)
      df <- data.frame(
        subject_id      = subj,
        gene            = g,
        panel           = panel_label,
        alteration_type = alt,
        mutation_status = ifelse(alt == "wt", "wt", "mut"),
        vaf             = vaf,
        stringsAsFactors = FALSE)
      .apply_opts_names(df, c(
        subject_id      = "subject",
        gene            = "gene",
        panel           = "panel",
        alteration_type = "alteration",
        mutation_status = "mutation"))
    }))
  }
  genomic_74  <- .gen_panel(genes_74,  "74genes")
  genomic_500 <- .gen_panel(genes_500, "500genes")

  # ---- TMB per panel ----
  tmb_74 <- data.frame(
    subject_id = subj, panel = "74genes",
    tmb = pmax(stats::rgamma(length(subj), 2, 0.5) + 0.5 * beta, 0.1),
    stringsAsFactors = FALSE)
  tmb_500 <- data.frame(
    subject_id = subj, panel = "500genes",
    tmb = tmb_74$tmb + stats::rnorm(length(subj), 0, 1),
    stringsAsFactors = FALSE)
  tmb <- rbind(tmb_74, tmb_500)
  tmb <- .apply_opts_names(tmb, c(subject_id = "subject",
                                  panel = "panel", tmb = "tmb"))

  # ---- IHC ----
  ihc <- do.call(rbind, lapply(c("PDL1", "CD8"), function(m) {
    s <- pmin(pmax(20 * beta + stats::rnorm(length(beta), 30, 15), 0), 100)
    df <- data.frame(
      subject_id = rec_df[[.o("subject")]],
      marker     = m,
      score      = s,
      stringsAsFactors = FALSE)
    .apply_opts_names(df, c(subject_id = "subject", marker = "marker",
                            score = "ihc_score"))
  }))

  out <- list(
    ctdna       = ctdna,
    genomic_74  = genomic_74,
    genomic_500 = genomic_500,
    expression  = expr,
    tmb         = tmb,
    ihc         = ihc
  )
  attr(out, "platform") <- paste(vendor, technology, sep = "_")
  out
}


# ---- Alteration filtering ---------------------------------------------------
#
# ctdna_filter_alterations(): one comprehensive filter for genomic alteration data,
# working on raw vendor frames (Infinity report, WES) AND canonical
# panel frames (genomic_74 / genomic_500). Each filter dimension:
#   - if set to a value (or vector of values), KEEPS rows matching that
#   - if set to FALSE, that filter dimension is disabled
#   - if the underlying column is missing from the data, the filter is
#     skipped silently (and noted in `verbose = TRUE` mode)
#
# All filters AND together. Wild-type rows can optionally be kept
# (canonical-schema data has mutation_status = "wt" for unaltered genes).
# -----------------------------------------------------------------------------

# Vendor-vs-canonical column resolution. Returns the column name to use
# for a given semantic concept, or NULL if absent.
.alt_col <- function(df, candidates) {
  hit <- intersect(candidates, names(df))
  if (length(hit)) hit[1] else NULL
}

# Apply a "keep these values" filter; FALSE disables; NULL disables; auto
# column resolution. Returns possibly-shrunk df + a 1-row diagnostic.
.apply_keep_filter <- function(df, col, values, label, verbose) {
  if (isFALSE(values) || is.null(values) || is.null(col)) {
    if (verbose && (isFALSE(values) || is.null(values)))
      message(sprintf("  %-22s : skipped", label))
    else if (verbose)
      message(sprintf("  %-22s : column not present, skipped", label))
    return(df)
  }
  n0 <- nrow(df)
  keep <- df[[col]] %in% values | is.na(df[[col]])
  df <- df[keep, , drop = FALSE]
  if (verbose)
    message(sprintf("  %-22s : %d -> %d rows (keep %s in '%s')",
                    label, n0, nrow(df),
                    paste(values, collapse = "|"), col))
  df
}

# Apply a numeric-threshold filter (max value allowed); FALSE disables.
.apply_max_filter <- function(df, col, max_value, label, verbose) {
  if (isFALSE(max_value) || is.null(max_value) || is.null(col)) {
    if (verbose && (isFALSE(max_value) || is.null(max_value)))
      message(sprintf("  %-22s : skipped", label))
    else if (verbose)
      message(sprintf("  %-22s : column not present, skipped", label))
    return(df)
  }
  n0 <- nrow(df)
  vals <- suppressWarnings(as.numeric(df[[col]]))
  keep <- is.na(vals) | vals <= max_value
  df <- df[keep, , drop = FALSE]
  if (verbose)
    message(sprintf("  %-22s : %d -> %d rows ('%s' <= %g)",
                    label, n0, nrow(df), col, max_value))
  df
}

# Apply a numeric-threshold filter (min value required); FALSE disables.
.apply_min_filter <- function(df, col, min_value, label, verbose) {
  if (isFALSE(min_value) || is.null(min_value) || is.null(col)) {
    if (verbose && (isFALSE(min_value) || is.null(min_value)))
      message(sprintf("  %-22s : skipped", label))
    else if (verbose)
      message(sprintf("  %-22s : column not present, skipped", label))
    return(df)
  }
  n0 <- nrow(df)
  vals <- suppressWarnings(as.numeric(df[[col]]))
  keep <- is.na(vals) | vals >= min_value
  df <- df[keep, , drop = FALSE]
  if (verbose)
    message(sprintf("  %-22s : %d -> %d rows ('%s' >= %g)",
                    label, n0, nrow(df), col, min_value))
  df
}


#' Comprehensive filter for genomic alterations
#'
#' One function for filtering both raw vendor alteration data (Guardant
#' Health \code{infinity_report}, tissue \code{wes}) and canonical-shape
#' panel data (\code{genomic_74}, \code{genomic_500}). Filter dimensions
#' auto-adapt to whatever columns are present in the input.
#'
#' Each parameter accepts:
#' \itemize{
#'   \item a value or vector of allowed values (for category filters), or
#'     a numeric threshold (for population-frequency / VAF / CN filters)
#'   \item \code{FALSE} to disable that filter dimension
#' }
#' If the underlying column is missing from \code{df}, the filter is
#' skipped silently (reported in \code{verbose = TRUE} mode). All filters
#' combine with AND.
#'
#' Defaults are tuned for "keep clinically relevant somatic alterations":
#' SNV/Indel/CNV/Fusion variants, Somatic / Likely somatic origin,
#' High or Moderate functional impact, common-variant filter at 1% AF in
#' gnomAD / 1000 Genomes, and VAF \eqn{\geq} 0.5% for SNV/Indel.
#'
#' @param df Alteration data frame. Recognised column families:
#'   variant type (\code{Variant_type} / \code{alteration_type}),
#'   somatic status (\code{Somatic_status}),
#'   functional impact (\code{Functional_impact}),
#'   allelic status (\code{Mutant_allele_status}),
#'   molecular consequence (\code{Molecular_consequence}),
#'   ClinVar (\code{ClinVar}),
#'   population frequency (\code{gnomAD_AF}, \code{KG_AF}),
#'   VAF (\code{VAF_percentage} / \code{Tumor_VAF} / \code{vaf}),
#'   copy number (\code{Copy_number}),
#'   panel (\code{panel}).
#' @param variant_type Vector of allowed variant types
#'   (e.g. \code{c("SNV","Indel","CNV","Fusion","LGR")}). FALSE to skip.
#' @param somatic_status Vector of allowed somatic statuses
#'   (default \code{c("Somatic","Likely somatic")}).
#' @param functional_impact Vector of allowed impact tiers
#'   (default \code{c("High","Moderate")}).
#' @param allelic_status Vector of allowed values
#'   (e.g. \code{c("Heterozygous","Homozygous")}). FALSE = skip (default).
#' @param molecular_consequence Vector of allowed values
#'   (e.g. \code{c("missense_variant","stop_gained")}). FALSE = skip (default).
#' @param clinvar Vector of allowed ClinVar significance categories
#'   (e.g. \code{c("Pathogenic","Likely pathogenic")}). FALSE = skip (default).
#' @param max_gnomad_af Maximum gnomAD allele frequency to keep
#'   (default 0.01). FALSE to skip.
#' @param max_kg_af Maximum 1000 Genomes allele frequency
#'   (default 0.01). FALSE to skip.
#' @param min_vaf Minimum VAF (in percentage units) for SNV/Indel
#'   (default 0.5). FALSE to skip.
#' @param max_vaf Maximum VAF in percentage units. FALSE = skip (default).
#' @param min_cn_amp Minimum copy number for amplifications
#'   (CNVs with copy_number below this are dropped; default 4).
#'   FALSE to skip.
#' @param max_cn_loss Maximum copy number for losses
#'   (CNVs with copy_number above this and below \code{min_cn_amp}
#'   are dropped; default 1). FALSE to skip.
#' @param panel If supplied, restrict to rows where \code{panel} matches
#'   (e.g. \code{"74genes"}). FALSE = skip (default).
#' @param keep_wt Keep canonical \code{mutation_status = "wt"} rows?
#'   Default FALSE — most alteration analyses want detected variants only.
#' @param verbose Report each filter's row-count effect (default TRUE).
#' @return Filtered data frame (same columns as input).
#' @examples
#' sim <- ctdna_make_mock_study(n_patients = 20)
#'
#' # Default filters — keeps somatic high/moderate impact variants
#' filtered <- ctdna_filter_alterations(sim$infinity_report, verbose = FALSE)
#' nrow(sim$infinity_report); nrow(filtered)
#'
#' # Pathogenic-only ClinVar focus, drop functional_impact filter
#' ctdna_filter_alterations(
#'   sim$infinity_report,
#'   clinvar = c("Pathogenic","Likely pathogenic"),
#'   functional_impact = FALSE,
#'   verbose = FALSE
#' )
#'
#' # WES with population-frequency filter (gnomAD/KG columns present)
#' ctdna_filter_alterations(sim$wes, max_gnomad_af = 0.001, verbose = FALSE)
#'
#' # Canonical panel data — same function, different schema
#' mm <- ctdna_make_example_multimodal(n_subjects = 20)
#' ctdna_filter_alterations(mm$genomic_74, keep_wt = FALSE, verbose = FALSE)
#' @export
ctdna_filter_alterations <- function(df,
    variant_type          = c("SNV","Indel","CNV","Fusion","LGR",
                              # canonical-schema equivalents:
                              "snv","indel","cnv","cnv_amp","cnv_loss",
                              "fusion","lgr"),
    somatic_status        = c("Somatic","Likely somatic"),
    functional_impact     = c("High","Moderate"),
    allelic_status        = FALSE,
    molecular_consequence = FALSE,
    clinvar               = FALSE,
    max_gnomad_af         = 0.01,
    max_kg_af             = 0.01,
    min_vaf               = 0.5,
    max_vaf               = FALSE,
    min_cn_amp            = 4,
    max_cn_loss           = 1,
    panel                 = FALSE,
    keep_wt               = FALSE,
    verbose               = TRUE) {

  if (!is.data.frame(df)) stop("df must be a data frame.")
  if (verbose) message("ctdna_filter_alterations: starting with ",
                       nrow(df), " rows")

  # Resolve column names across vendor (Infinity, WES) and canonical schemas
  c_variant    <- .alt_col(df, c("Variant_type", "alteration_type"))
  c_somatic    <- .alt_col(df, c("Somatic_status"))
  c_impact     <- .alt_col(df, c("Functional_impact"))
  c_allelic    <- .alt_col(df, c("Mutant_allele_status"))
  c_molconseq  <- .alt_col(df, c("Molecular_consequence"))
  c_clinvar    <- .alt_col(df, c("ClinVar"))
  c_gnomad     <- .alt_col(df, c("gnomAD_AF","gnomad_af","gnomad_AF"))
  c_kg         <- .alt_col(df, c("KG_AF","kg_af","onek_af","ThousandGenomes_AF"))
  c_vaf        <- .alt_col(df, c("VAF_percentage","Tumor_VAF","vaf"))
  c_cn         <- .alt_col(df, c("Copy_number","copy_number"))
  c_mutation   <- .alt_col(df, c("mutation_status", .o("mutation")))
  c_panel      <- .alt_col(df, c("panel", .o("panel")))

  # --- Wild-type drop (canonical-schema only) ---
  if (!isTRUE(keep_wt) && !is.null(c_mutation)) {
    n0 <- nrow(df)
    df <- df[df[[c_mutation]] != "wt" | is.na(df[[c_mutation]]), , drop = FALSE]
    if (verbose)
      message(sprintf("  %-22s : %d -> %d rows (drop mutation_status=='wt')",
                      "keep_wt", n0, nrow(df)))
  }

  # --- Variant-type vs CNV-direction logic ---
  # CNV amplification: keep if copy_number >= min_cn_amp
  # CNV loss:           keep if copy_number <= max_cn_loss
  # Other CNVs (between): drop
  if (!isFALSE(min_cn_amp) || !isFALSE(max_cn_loss)) {
    if (!is.null(c_cn) && !is.null(c_variant)) {
      n0 <- nrow(df)
      cn <- suppressWarnings(as.numeric(df[[c_cn]]))
      vt <- df[[c_variant]]
      is_cnv <- vt %in% c("CNV","cnv","cnv_amp","cnv_loss") & !is.na(cn)
      amp_ok <- if (isFALSE(min_cn_amp))  TRUE else cn >= min_cn_amp
      loss_ok <- if (isFALSE(max_cn_loss)) TRUE else cn <= max_cn_loss
      keep <- !is_cnv | amp_ok | loss_ok
      df <- df[keep, , drop = FALSE]
      if (verbose)
        message(sprintf(
          "  %-22s : %d -> %d rows (CNV amp>=%s OR loss<=%s)",
          "copy_number bounds", n0, nrow(df),
          if (isFALSE(min_cn_amp)) "skip" else format(min_cn_amp),
          if (isFALSE(max_cn_loss)) "skip" else format(max_cn_loss)))
    } else if (verbose) {
      message(sprintf("  %-22s : copy_number column absent, skipped",
                      "copy_number bounds"))
    }
  }

  # --- Category filters ---
  df <- .apply_keep_filter(df, c_variant,   variant_type,
                           "variant_type",   verbose)
  df <- .apply_keep_filter(df, c_somatic,   somatic_status,
                           "somatic_status", verbose)
  df <- .apply_keep_filter(df, c_impact,    functional_impact,
                           "functional_impact", verbose)
  df <- .apply_keep_filter(df, c_allelic,   allelic_status,
                           "allelic_status", verbose)
  df <- .apply_keep_filter(df, c_molconseq, molecular_consequence,
                           "molecular_consequence", verbose)
  df <- .apply_keep_filter(df, c_clinvar,   clinvar,
                           "clinvar",        verbose)
  df <- .apply_keep_filter(df, c_panel,     panel,
                           "panel",          verbose)

  # --- Numeric thresholds ---
  df <- .apply_max_filter(df, c_gnomad, max_gnomad_af, "max_gnomad_af", verbose)
  df <- .apply_max_filter(df, c_kg,     max_kg_af,     "max_kg_af",     verbose)
  df <- .apply_min_filter(df, c_vaf,    min_vaf,       "min_vaf",       verbose)
  df <- .apply_max_filter(df, c_vaf,    max_vaf,       "max_vaf",       verbose)

  if (verbose) message("ctdna_filter_alterations: ", nrow(df), " rows remain")
  df
}


# ---- Column-by-column filter registry (Guardant Infinity) -------------------
#
# A registry-driven, per-column filter for genomic alterations. Each
# Guardant Infinity column has an entry of the form:
#
#   list(enabled = TRUE/FALSE,
#        op      = "%in%" / ">=" / "<=" / "==",
#        value   = allowlist or threshold,
#        desc    = "short description")
#
# Users get the default registry, modify it (turn columns on/off, change
# thresholds), and apply it to a data frame. Per-gene-set overrides are
# merged on top of the general registry so each set can have its own
# rules where needed.
# -----------------------------------------------------------------------------

# Default registry — every column in the Guardant Infinity report that
# is sensibly filterable. enabled = FALSE by default for columns that
# would over-filter in typical analyses; thresholds set to permissive
# defaults so turning them on doesn't remove everything.
.ctdna_filter_registry_defaults <- function() list(

  # --- Identity / context (informational; off by default) -------------------
  Patient_ID = list(enabled = FALSE, op = "%in%", value = character(0),
                     desc = "Restrict to specific patient IDs"),
  Visit_name = list(enabled = FALSE, op = "%in%", value = character(0),
                     desc = "Restrict to specific visit names (e.g. C1D1)"),
  Cancertype = list(enabled = FALSE, op = "%in%", value = character(0),
                     desc = "Restrict to specific indications"),
  Sample_status = list(enabled = TRUE, op = "%in%",
                        value = c("Pass","PASS","Passed"),
                        desc = "QC sample status pass-only"),

  # --- Variant identity ----------------------------------------------------
  Variant_type = list(enabled = TRUE, op = "%in%",
                       value = c("SNV","Indel","CNV","Fusion","LGR"),
                       desc = "Allowed variant types"),
  Gene = list(enabled = FALSE, op = "%in%", value = character(0),
              desc = "Restrict to specific genes"),
  Chromosome = list(enabled = FALSE, op = "%in%", value = character(0),
                    desc = "Restrict to specific chromosomes"),

  # --- Functional / consequence -------------------------------------------
  Functional_impact = list(enabled = TRUE, op = "%in%",
                            value = c("High","Moderate"),
                            desc = "Predicted functional impact category"),
  Molecular_consequence = list(enabled = FALSE, op = "%in%",
                                value = c("missense_variant","stop_gained",
                                          "frameshift_variant",
                                          "splice_donor_variant",
                                          "splice_acceptor_variant"),
                                desc = "SO term molecular consequence"),
  Splice_effect = list(enabled = FALSE, op = "%in%", value = character(0),
                        desc = "Splice effect category"),

  # --- Somatic / germline / clinical interpretation ------------------------
  Somatic_status = list(enabled = TRUE, op = "%in%",
                         value = c("Somatic","Likely somatic"),
                         desc = "Keep somatic / likely-somatic calls"),
  ClinVar = list(enabled = FALSE, op = "%in%",
                  value = c("Pathogenic","Likely pathogenic"),
                  desc = "ClinVar clinical significance"),
  Mutant_allele_status = list(enabled = FALSE, op = "%in%",
                               value = c("Homozygous","Heterozygous"),
                               desc = "Zygosity / allele status"),
  Alleletype = list(enabled = FALSE, op = "%in%",
                     value = c("Somatic"),
                     desc = "Allele type"),

  # --- Numeric thresholds -------------------------------------------------
  VAF_percentage = list(enabled = FALSE, op = ">=", value = 0.5,
                         desc = "Minimum variant allele frequency (%)"),
  Genomic_max_VAF_percentage = list(enabled = FALSE, op = ">=", value = 0.5,
                                     desc = "Minimum max-VAF across genomic calls (%)"),
  Mol_count = list(enabled = FALSE, op = ">=", value = 50,
                    desc = "Minimum supporting molecule count"),
  Copy_number = list(enabled = FALSE, op = ">=", value = 4,
                     desc = "Min copy number for amplifications (CNV-only filter)"),

  # --- TMB / MSI / HRD -----------------------------------------------------
  TMB_score = list(enabled = FALSE, op = ">=", value = 10,
                    desc = "Minimum TMB score (mut/Mb)"),
  TMB_category = list(enabled = FALSE, op = "%in%",
                       value = c("Intermediate","High"),
                       desc = "TMB category"),
  MSI_High = list(enabled = FALSE, op = "==", value = "Yes",
                   desc = "Require MSI-High calls only"),
  HRD_score = list(enabled = FALSE, op = ">=", value = 42,
                    desc = "Minimum HRD score"),

  # --- ctDNA detection ----------------------------------------------------
  ctDNA_detection_status = list(enabled = FALSE, op = "%in%",
                                 value = c("Detected"),
                                 desc = "Sample-level ctDNA detection"),
  Methylation_tumor_fraction_percentage = list(enabled = FALSE,
                                                op = ">=", value = 0.001,
                                                desc = "Minimum methyl TF (%)"),

  # --- cfDNA QC ----------------------------------------------------------
  cfDNA_ng = list(enabled = FALSE, op = ">=", value = 5,
                   desc = "Minimum cfDNA input (ng)"),
  Plasma_ml_input = list(enabled = FALSE, op = ">=", value = 4,
                          desc = "Minimum plasma volume input (mL)"),

  # --- Annotation databases (rarity filters) -----------------------------
  # These would typically be max-allowed thresholds (rare variants only)
  COSMIC = list(enabled = FALSE, op = "has_value", value = TRUE,
                 desc = "Keep rows with any COSMIC ID (annotated). FALSE = novel only."),
  dbSNP = list(enabled = FALSE, op = "has_value", value = FALSE,
                desc = "FALSE keeps rows missing dbSNP (likely-somatic novel calls). TRUE keeps annotated.")
)


# Print one entry compactly for display
.ctdna_filter_entry_str <- function(name, e) {
  status <- if (isTRUE(e$enabled)) "ON " else "off"
  val <- if (is.character(e$value) || is.factor(e$value)) {
    if (length(e$value) == 0) "<empty - SET TO USE>" else
      paste(shQuote(e$value), collapse = ", ")
  } else if (is.numeric(e$value)) {
    format(e$value, trim = TRUE)
  } else if (is.logical(e$value)) {
    as.character(e$value)
  } else {
    paste(format(e$value), collapse = ", ")
  }
  desc <- if (is.null(e$desc)) "" else paste0("  - ", e$desc)
  sprintf("  [%s]  %-40s  %s %s%s", status, name, e$op, val, desc)
}

#' Get / set / reset the alteration filter registry
#'
#' A column-by-column filter registry that names every filterable
#' Guardant Health Infinity column and pairs it with an
#' \code{enabled} flag, an operator, and a threshold / allowlist.
#' Apply the registry to a data frame with
#' \code{\link{ctdna_apply_filter}} (or pass via \code{filter_set} to
#' \code{\link{ctdna_plot_oncoprint}}).
#'
#' Each entry has the form
#' \preformatted{list(enabled = TRUE/FALSE,
#'      op      = "\%in\%" / ">=" / "<=" / "==",
#'      value   = <allowlist or numeric threshold>,
#'      desc    = "<one-line description>")}
#'
#' @section Modes:
#' \itemize{
#'   \item No arguments: print the current registry.
#'   \item Single column name: return that one entry.
#'   \item Named arguments: update specific entries; pass either a
#'     full list, or an abbreviated list (e.g.
#'     \code{VAF_percentage = list(enabled = TRUE, value = 1.0)})
#'     - missing fields keep their current value.
#'   \item \code{.reset = TRUE}: restore the default registry.
#'   \item \code{load = list(...)}: bulk-load a snapshot.
#' }
#'
#' @param ... Column names (to get) or \code{name = list(...)} pairs
#'   (to set).
#' @param .reset If TRUE, restore the default registry.
#' @param load Optional snapshot list to load.
#' @return Invisibly the current registry (a named list), or the
#'   requested subset.
#' @examples
#' # Print the full registry
#' ctdna_filter_opts()
#'
#' # Get one entry
#' ctdna_filter_opts("VAF_percentage")
#'
#' # Turn on VAF filtering at 1.0%; restrict to High impact
#' ctdna_filter_opts(
#'   VAF_percentage    = list(enabled = TRUE, value = 1.0),
#'   Functional_impact = list(value = "High"))
#'
#' # Save & restore a snapshot
#' cfg <- ctdna_filter_opts()
#' ctdna_filter_opts(.reset = TRUE)
#' ctdna_filter_opts(load = cfg)
#' @export
ctdna_filter_opts <- function(..., .reset = FALSE, load = NULL) {

  # Initialise on first call
  if (is.null(.env[["filter_registry"]])) {
    .env[["filter_registry"]] <- .ctdna_filter_registry_defaults()
  }

  if (isTRUE(.reset)) {
    .env[["filter_registry"]] <- .ctdna_filter_registry_defaults()
    message("ctdna_filter_opts: registry reset to defaults.")
    return(invisible(.env[["filter_registry"]]))
  }
  if (!is.null(load)) {
    if (!is.list(load) || is.null(names(load)))
      stop("`load` must be a named list as returned by ctdna_filter_opts().")
    .env[["filter_registry"]] <- load
    message("ctdna_filter_opts: registry loaded (", length(load),
             " entries).")
    return(invisible(.env[["filter_registry"]]))
  }

  args <- list(...)
  reg <- .env[["filter_registry"]]

  # No args: print full registry
  if (length(args) == 0) {
    on_n  <- sum(vapply(reg, function(e) isTRUE(e$enabled), logical(1)))
    cat(sprintf("ctdna_filter_opts registry  (%d entries, %d enabled)\n",
                 length(reg), on_n))
    cat(strrep("=", 78), "\n", sep = "")
    for (nm in names(reg))
      cat(.ctdna_filter_entry_str(nm, reg[[nm]]), "\n", sep = "")
    cat(strrep("=", 78), "\n", sep = "")
    cat("Edit:   ctdna_filter_opts(<name> = list(enabled = TRUE, value = ...))\n")
    cat("Reset:  ctdna_filter_opts(.reset = TRUE)\n")
    return(invisible(reg))
  }

  # Positional getter: ctdna_filter_opts("VAF_percentage")
  if (length(names(args)) == 0 || all(names(args) == "")) {
    keys <- unlist(args)
    if (length(keys) == 1) return(reg[[keys]])
    return(reg[keys])
  }

  # Setter: each named arg becomes/replaces an entry
  for (nm in names(args)) {
    if (nm == "") next
    new_entry <- args[[nm]]
    if (!is.list(new_entry))
      stop(sprintf("Value for '%s' must be a list with enabled / op / value / desc fields.",
                    nm))
    cur <- if (nm %in% names(reg)) reg[[nm]] else
      list(enabled = TRUE, op = "%in%", value = character(0),
           desc = "user-added column")
    # Merge field by field — partial update OK
    for (k in c("enabled","op","value","desc")) {
      if (k %in% names(new_entry)) cur[[k]] <- new_entry[[k]]
    }
    reg[[nm]] <- cur
  }
  .env[["filter_registry"]] <- reg
  invisible(reg)
}


# Apply ONE filter entry to a data frame; return logical vector of keep-rows.
# Supported operators:
#   %in%       value is a character vector (allowlist)
#   >= / <=    value is a numeric threshold
#   ==         value is a single value to match
#   has_value  value is TRUE/FALSE: TRUE keeps rows where the column is
#              non-NA and non-empty; FALSE keeps rows where it IS missing.
#              Useful e.g. for dbSNP / COSMIC to keep only annotated
#              (has_value = TRUE) or only novel (has_value = FALSE) variants.
.ctdna_apply_entry <- function(df, col, entry, na_keep = TRUE) {
  if (!isTRUE(entry$enabled)) return(rep(TRUE, nrow(df)))
  if (!col %in% names(df))    return(rep(TRUE, nrow(df)))
  x <- df[[col]]

  op  <- entry$op  %||% "%in%"
  val <- entry$value

  keep <- switch(op,
    `%in%` = {
      if (length(val) == 0) rep(TRUE, length(x))
      else as.character(x) %in% as.character(val)
    },
    `>=`   = suppressWarnings(as.numeric(x) >= as.numeric(val)),
    `<=`   = suppressWarnings(as.numeric(x) <= as.numeric(val)),
    `==`   = as.character(x) == as.character(val),
    has_value = {
      # TRUE -> keep rows with any value; FALSE -> keep rows that are missing
      has <- !(is.na(x) | as.character(x) %in% c("", "NA", "."))
      if (isTRUE(val)) has else !has
    },
    rep(TRUE, length(x))
  )
  # has_value is NOT subject to na_keep: NAs are exactly what it's about.
  if (na_keep && op != "has_value") keep[is.na(keep)] <- TRUE
  keep
}


#' Apply the alteration filter registry to a data frame
#'
#' Walks the registry returned by \code{\link{ctdna_filter_opts}} and
#' applies every enabled entry. Rows where the column is NA are kept by
#' default (so a Copy_number threshold doesn't drop SNV rows that have
#' no copy-number value).
#'
#' Use \code{overrides} to pass a per-call override of one or more
#' entries (without modifying the global registry). This is also the
#' mechanism behind per-gene-set overrides in \code{ctdna_plot_oncoprint}.
#'
#' @param df Alteration data frame (vendor or canonical schema).
#' @param overrides Optional named list. Each element \code{name = list(...)}
#'   replaces or augments the corresponding registry entry for this call only.
#' @param na_keep If TRUE (default), rows where the filter column is NA
#'   are kept.
#' @param verbose If TRUE, print one line per filter applied.
#' @return The filtered data frame.
#' @examples
#' sim <- ctdna_make_mock_study(n_patients = 10, seed = 1)
#'
#' # Use the global registry as-is
#' nrow(ctdna_apply_filter(sim$infinity_report))
#'
#' # Per-call override: stricter VAF for this analysis only
#' ctdna_apply_filter(sim$infinity_report,
#'   overrides = list(VAF_percentage = list(enabled = TRUE, value = 5.0)))
#' @export
ctdna_apply_filter <- function(df, overrides = NULL, na_keep = TRUE,
                                verbose = FALSE) {
  if (is.null(.env[["filter_registry"]]))
    .env[["filter_registry"]] <- .ctdna_filter_registry_defaults()
  reg <- .env[["filter_registry"]]

  # Merge overrides on top of registry for this call
  if (!is.null(overrides)) {
    if (!is.list(overrides) || (length(overrides) > 0 && is.null(names(overrides))))
      stop("`overrides` must be a named list.")
    for (nm in names(overrides)) {
      cur <- if (nm %in% names(reg)) reg[[nm]] else
        list(enabled = TRUE, op = "%in%", value = character(0),
             desc = "override-added")
      new_entry <- overrides[[nm]]
      if (!is.list(new_entry))
        stop(sprintf("Override '%s' must be a list.", nm))
      for (k in c("enabled","op","value","desc"))
        if (k %in% names(new_entry)) cur[[k]] <- new_entry[[k]]
      reg[[nm]] <- cur
    }
  }

  n0 <- nrow(df)
  keep <- rep(TRUE, n0)
  applied <- character(0)
  for (nm in names(reg)) {
    e <- reg[[nm]]
    if (!isTRUE(e$enabled)) next
    if (!nm %in% names(df)) next
    new_keep <- .ctdna_apply_entry(df, nm, e, na_keep = na_keep)
    keep <- keep & new_keep
    applied <- c(applied, nm)
    if (verbose) {
      n_drop <- sum(!new_keep, na.rm = TRUE)
      message(sprintf("  filter '%s' (%s) dropped %d rows",
                       nm, e$op, n_drop))
    }
  }
  out <- df[keep, , drop = FALSE]
  if (verbose)
    message(sprintf("ctdna_apply_filter: %d -> %d rows (%d filters applied)",
                     n0, nrow(out), length(applied)))
  out
}


# ---- Three-level filter system: schemes -------------------------------------
#
# Concept
# -------
# Filtering has three levels:
#
# 1. DEFAULT GENERAL  -- shipped with the package. Always preserved as a
#    hard reset target so any modification can be undone.
#
# 2. MODIFIED GENERAL -- the user edits the general filter via
#    ctdna_filter_opts(). This becomes the active general filter and is
#    applied uniformly to all genes by every function.
#
# 3. NAMED SPECIFIC SCHEMES -- created via ctdna_filter_scheme_create().
#    A scheme stores only gene-set-keyed OVERRIDES on top of the general
#    filter. Two modes:
#      - dynamic (default): overrides resolve against the CURRENT general
#        filter every time the scheme is used. If the general filter
#        later changes, the scheme automatically picks up the change for
#        gene sets it does not override.
#      - frozen: the scheme snapshots the general filter at freeze time
#        and locks it in. Future edits to the general filter have no
#        effect on it. Use this when you need exact reproducibility.
#
# Genes not covered by any gene set in a specific scheme fall back to
# the (resolved) general filter for that scheme.
#
# Use site
# --------
# Every function that touches alterations takes `filter_scheme`:
#   filter_scheme = NULL          -> current general filter (level 1 or 2)
#   filter_scheme = "myScheme"    -> resolve the named specific scheme
# -----------------------------------------------------------------------------

# Initialise scheme storage on first reference
.ctdna_init_schemes <- function() {
  if (is.null(.env[["filter_schemes"]]))
    .env[["filter_schemes"]] <- list()
  # Default-general is the factory registry, kept untouched as a reset target
  if (is.null(.env[["filter_general_default"]]))
    .env[["filter_general_default"]] <- .ctdna_filter_registry_defaults()
  # Active general is what ctdna_filter_opts() exposes
  if (is.null(.env[["filter_registry"]]))
    .env[["filter_registry"]] <- .ctdna_filter_registry_defaults()
  invisible(NULL)
}

# Merge a single override onto a registry entry (partial update OK)
.ctdna_merge_entry <- function(base, override) {
  for (k in c("enabled","op","value","desc"))
    if (k %in% names(override)) base[[k]] <- override[[k]]
  base
}


#' Reset the general filter back to the package default
#'
#' Restores every entry of the active general filter to its factory
#' default. Specific schemes are unaffected (dynamic schemes will
#' re-resolve against the new general state on their next use; frozen
#' schemes are independent by design).
#'
#' @return Invisibly, the restored general registry.
#' @examples
#' ctdna_filter_opts(VAF_percentage = list(enabled = TRUE, value = 5))
#' ctdna_filter_reset_general()
#' ctdna_filter_opts("VAF_percentage")$enabled  # FALSE again
#' @seealso \code{\link{ctdna_filter_opts}}
#' @export
ctdna_filter_reset_general <- function() {
  .ctdna_init_schemes()
  .env[["filter_registry"]] <- .env[["filter_general_default"]]
  message("ctdna_filter_reset_general: general filter restored to factory defaults.")
  invisible(.env[["filter_registry"]])
}


#' Create a named specific filter scheme
#'
#' A scheme attaches per-gene-set OVERRIDES on top of the general filter.
#' Genes not covered by any of the scheme's gene sets fall back to the
#' general filter.
#'
#' @section Modes:
#' \itemize{
#'   \item \code{frozen = FALSE} (default) -- dynamic. The scheme stores
#'     only the per-gene-set overrides. When applied, the active general
#'     filter is read at that moment. If the general filter is edited
#'     later, the scheme automatically inherits the change for gene sets
#'     it does not override.
#'   \item \code{frozen = TRUE} -- the scheme snapshots the active
#'     general filter NOW and locks it in. Future edits to the general
#'     filter have no effect on this scheme. Use for reproducibility.
#' }
#'
#' @param name Scheme name (character, non-empty).
#' @param gene_sets Named list of gene vectors. A gene set can contain
#'   one or many genes. Set names are used by \code{overrides}.
#' @param overrides Named list keyed by gene-set name. Each element is
#'   itself a list of column-name -> partial entry overrides, e.g.
#'   \code{list(HRR = list(ClinVar = list(enabled = TRUE,
#'   value = c("Pathogenic","Likely pathogenic"))))}.
#' @param frozen If TRUE, snapshot the general filter at create time.
#' @param overwrite If TRUE, silently replace an existing scheme of the
#'   same name. Default FALSE (errors instead).
#' @return Invisibly, the scheme object.
#' @examples
#' # Default general filter is in effect.
#' ctdna_filter_scheme_create(
#'   "schemeCAD",
#'   gene_sets = list(
#'     HRR     = c("BRCA1","BRCA2","ATM","PALB2"),
#'     TP53    = "TP53",
#'     RTK_RAS = c("KRAS","EGFR","BRAF","MET")),
#'   overrides = list(
#'     HRR     = list(ClinVar = list(enabled = TRUE,
#'                                    value = c("Pathogenic","Likely pathogenic"))),
#'     TP53    = list(Mutant_allele_status = list(enabled = TRUE,
#'                                                  value = "Homozygous")),
#'     RTK_RAS = list(VAF_percentage = list(enabled = TRUE, value = 5))))
#' @seealso \code{\link{ctdna_filter_scheme_list}},
#'   \code{\link{ctdna_filter_scheme_freeze}}
#' @export
ctdna_filter_scheme_create <- function(name, gene_sets, overrides = list(),
                                        frozen = FALSE, overwrite = FALSE) {
  .ctdna_init_schemes()
  if (!is.character(name) || length(name) != 1 || !nzchar(name))
    stop("`name` must be a single non-empty string.")
  if (!is.list(gene_sets) || is.null(names(gene_sets)) ||
      any(names(gene_sets) == ""))
    stop("`gene_sets` must be a NAMED list of gene-symbol vectors.")
  if (!is.list(overrides))
    stop("`overrides` must be a NAMED list (possibly empty), keyed by gene-set name.")
  if (length(overrides) > 0) {
    bad <- setdiff(names(overrides), names(gene_sets))
    if (length(bad) > 0)
      stop(sprintf("overrides reference unknown gene set(s): %s",
                    paste(bad, collapse = ", ")))
    for (s in names(overrides)) {
      if (!is.list(overrides[[s]]))
        stop(sprintf("overrides$%s must be a list of column overrides.", s))
      bad_cols <- setdiff(names(overrides[[s]]),
                           names(.env[["filter_general_default"]]))
      if (length(bad_cols) > 0)
        warning(sprintf("scheme '%s': override on '%s' references unknown column(s): %s",
                         name, s, paste(bad_cols, collapse = ", ")))
    }
  }
  if (name %in% names(.env[["filter_schemes"]]) && !overwrite)
    stop(sprintf("Scheme '%s' already exists. Use overwrite = TRUE to replace.",
                  name))

  scheme <- list(
    name      = name,
    gene_sets = gene_sets,
    overrides = overrides,
    frozen    = isTRUE(frozen),
    general_snapshot = if (isTRUE(frozen)) .env[["filter_registry"]] else NULL,
    created_at = Sys.time()
  )
  .env[["filter_schemes"]][[name]] <- scheme
  message(sprintf("Scheme '%s' created (%s, %d gene sets, %d with overrides).",
                   name, if (frozen) "frozen" else "dynamic",
                   length(gene_sets), length(overrides)))
  invisible(scheme)
}


#' List, get, delete, freeze, save, or load specific filter schemes
#'
#' \itemize{
#'   \item \code{ctdna_filter_scheme_list()} -- returns a data frame with
#'     one row per scheme (name, mode, n_sets, n_overrides, created_at).
#'   \item \code{ctdna_filter_scheme_get(name)} -- returns the scheme list.
#'   \item \code{ctdna_filter_scheme_delete(name)} -- removes the scheme.
#'   \item \code{ctdna_filter_scheme_freeze(name)} -- converts a dynamic
#'     scheme to frozen by snapshotting the CURRENT general filter.
#'   \item \code{ctdna_filter_scheme_save(file)} -- saves all schemes
#'     (and the general default) to an RDS file.
#'   \item \code{ctdna_filter_scheme_load(file)} -- restores from an RDS
#'     file written by \code{ctdna_filter_scheme_save}.
#' }
#' @param name Scheme name.
#' @param file RDS file path.
#' @return List or data frame depending on the function.
#' @examples
#' ctdna_filter_scheme_create("demo",
#'   gene_sets = list(TP53 = "TP53"))
#' ctdna_filter_scheme_list()
#' ctdna_filter_scheme_freeze("demo")
#' ctdna_filter_scheme_delete("demo")
#' @name ctdna_filter_scheme
NULL

#' @rdname ctdna_filter_scheme
#' @export
ctdna_filter_scheme_list <- function() {
  .ctdna_init_schemes()
  s <- .env[["filter_schemes"]]
  if (length(s) == 0)
    return(data.frame(name = character(0), mode = character(0),
                       n_sets = integer(0), n_overrides = integer(0),
                       created_at = as.POSIXct(character(0))))
  do.call(rbind, lapply(s, function(x) data.frame(
    name        = x$name,
    mode        = if (isTRUE(x$frozen)) "frozen" else "dynamic",
    n_sets      = length(x$gene_sets),
    n_overrides = length(x$overrides),
    created_at  = x$created_at,
    stringsAsFactors = FALSE
  )))
}

#' @rdname ctdna_filter_scheme
#' @export
ctdna_filter_scheme_get <- function(name) {
  .ctdna_init_schemes()
  if (!name %in% names(.env[["filter_schemes"]]))
    stop(sprintf("No filter scheme named '%s'. See ctdna_filter_scheme_list().",
                  name))
  .env[["filter_schemes"]][[name]]
}

#' @rdname ctdna_filter_scheme
#' @export
ctdna_filter_scheme_delete <- function(name) {
  .ctdna_init_schemes()
  if (!name %in% names(.env[["filter_schemes"]])) {
    message(sprintf("Scheme '%s' does not exist; nothing to delete.", name))
    return(invisible(NULL))
  }
  .env[["filter_schemes"]][[name]] <- NULL
  message(sprintf("Scheme '%s' deleted.", name))
  invisible(NULL)
}

#' @rdname ctdna_filter_scheme
#' @export
ctdna_filter_scheme_freeze <- function(name) {
  .ctdna_init_schemes()
  if (!name %in% names(.env[["filter_schemes"]]))
    stop(sprintf("No filter scheme named '%s'.", name))
  s <- .env[["filter_schemes"]][[name]]
  s$frozen <- TRUE
  s$general_snapshot <- .env[["filter_registry"]]
  .env[["filter_schemes"]][[name]] <- s
  message(sprintf("Scheme '%s' frozen against current general filter.", name))
  invisible(s)
}

#' @rdname ctdna_filter_scheme
#' @export
ctdna_filter_scheme_save <- function(file) {
  .ctdna_init_schemes()
  payload <- list(
    schemes         = .env[["filter_schemes"]],
    general_active  = .env[["filter_registry"]],
    general_default = .env[["filter_general_default"]]
  )
  saveRDS(payload, file = file)
  message(sprintf("Saved %d scheme(s) + general filter to '%s'.",
                   length(payload$schemes), file))
  invisible(file)
}

#' @rdname ctdna_filter_scheme
#' @export
ctdna_filter_scheme_load <- function(file) {
  .ctdna_init_schemes()
  payload <- readRDS(file)
  if (!is.list(payload) || !"schemes" %in% names(payload))
    stop("File does not look like a ctdna_filter_scheme_save() payload.")
  .env[["filter_schemes"]]         <- payload$schemes  %||% list()
  if (!is.null(payload$general_active))
    .env[["filter_registry"]]        <- payload$general_active
  if (!is.null(payload$general_default))
    .env[["filter_general_default"]] <- payload$general_default
  message(sprintf("Loaded %d scheme(s) from '%s'.",
                   length(.env[["filter_schemes"]]), file))
  invisible(.env[["filter_schemes"]])
}


# Resolve a scheme (or NULL = general) against the active general filter
# into a per-gene-set table of effective filter entries.
# Returns a list with: $general (resolved registry), $gene_sets (named
# list of gene-vectors), $resolved (named list keyed by gene-set name,
# each a full registry merged from general + that set's overrides).
.ctdna_resolve_scheme <- function(scheme_name = NULL) {
  .ctdna_init_schemes()
  active_general <- .env[["filter_registry"]]
  if (is.null(scheme_name) || identical(scheme_name, "general")) {
    # No specific scheme: gene-agnostic, one set "all"
    return(list(general  = active_general,
                gene_sets = NULL,
                resolved  = NULL,
                scheme    = NULL))
  }
  if (!scheme_name %in% names(.env[["filter_schemes"]]))
    stop(sprintf("No filter scheme named '%s'. See ctdna_filter_scheme_list().",
                  scheme_name))
  s <- .env[["filter_schemes"]][[scheme_name]]
  # Frozen schemes use the snapshot, dynamic schemes use the active general
  general <- if (isTRUE(s$frozen)) s$general_snapshot else active_general
  # Build resolved per-set registries
  resolved <- lapply(names(s$gene_sets), function(set_nm) {
    reg <- general
    ovr <- s$overrides[[set_nm]]
    if (is.list(ovr)) {
      for (nm in names(ovr)) {
        cur <- if (nm %in% names(reg)) reg[[nm]] else
          list(enabled = TRUE, op = "%in%", value = character(0),
               desc = "override-added")
        reg[[nm]] <- .ctdna_merge_entry(cur, ovr[[nm]])
      }
    }
    reg
  })
  names(resolved) <- names(s$gene_sets)
  list(general  = general,
       gene_sets = s$gene_sets,
       resolved  = resolved,
       scheme    = s)
}


#' Apply general or specific filter scheme to an alteration data frame
#'
#' Routes a data frame through the three-level filter system.
#'
#' \itemize{
#'   \item \code{filter_scheme = NULL} -- apply the current general
#'     filter to every row (gene-agnostic).
#'   \item \code{filter_scheme = "name"} -- apply the named specific
#'     scheme: each gene set is filtered with general + that set's
#'     overrides merged; genes not in any of the scheme's gene sets
#'     fall back to the general filter.
#' }
#'
#' @param df Alteration data frame (vendor or canonical schema).
#' @param filter_scheme NULL (general) or the name of a specific scheme.
#' @param gene_col Column name holding gene symbols. Auto-detected.
#' @param verbose If TRUE, print one line per filter pass.
#' @return Filtered data frame, with attribute \code{"ctdna_filter_used"}
#'   recording what was applied (for downstream reproducibility).
#' @examples
#' sim <- ctdna_make_mock_study(n_patients = 10, seed = 1)
#' ctdna_filter_scheme_create("strict_HRR",
#'   gene_sets = list(HRR = c("BRCA1","BRCA2","ATM","PALB2")),
#'   overrides = list(HRR = list(ClinVar = list(enabled = TRUE,
#'                                                value = "Pathogenic"))))
#' out <- ctdna_filter_apply_scheme(sim$infinity_report,
#'                                    filter_scheme = "strict_HRR")
#' attr(out, "ctdna_filter_used")$scheme
#' @export
ctdna_filter_apply_scheme <- function(df, filter_scheme = NULL,
                                       gene_col = NULL, verbose = FALSE) {
  res <- .ctdna_resolve_scheme(filter_scheme)

  # Path A: no specific scheme - one general filter applied to all rows.
  # We DON'T need a gene column for this path.
  if (is.null(res$resolved)) {
    out <- ctdna_apply_filter(df, overrides = NULL,
                                na_keep = TRUE, verbose = verbose)
    attr(out, "ctdna_filter_used") <- list(scheme = "general",
                                            general = res$general)
    return(out)
  }

  # Path B: specific scheme - need a gene column to assign rows to sets
  if (is.null(gene_col))
    gene_col <- .alt_col(df, c("Gene", .o("gene"), "gene"))
  if (is.null(gene_col))
    stop("filter_scheme = '", filter_scheme,
         "' requires a gene column in `df` to assign rows to gene sets.")
  # Path B: specific scheme. Walk gene sets, applying the resolved
  # registry for each. Genes not in any set fall back to general.
  all_set_genes <- unique(unlist(res$gene_sets, use.names = FALSE))
  in_any_set <- as.character(df[[gene_col]]) %in% all_set_genes

  # Save and temporarily replace the active general registry so
  # ctdna_apply_filter() uses the right entries for each pass. We
  # restore it on exit.
  saved <- .env[["filter_registry"]]
  on.exit(.env[["filter_registry"]] <- saved, add = TRUE)

  pieces <- list()
  # Each gene set
  for (set_nm in names(res$gene_sets)) {
    set_genes <- res$gene_sets[[set_nm]]
    keep_rows <- as.character(df[[gene_col]]) %in% set_genes
    if (!any(keep_rows)) next
    .env[["filter_registry"]] <- res$resolved[[set_nm]]
    if (verbose) message(sprintf("  scheme set '%s' (%d rows in)",
                                  set_nm, sum(keep_rows)))
    pieces[[set_nm]] <- ctdna_apply_filter(df[keep_rows, , drop = FALSE],
                                            verbose = verbose)
  }
  # Genes not in any set get the (resolved-scheme) general filter
  if (any(!in_any_set)) {
    .env[["filter_registry"]] <- res$general
    if (verbose) message(sprintf("  scheme set '<other genes>' (%d rows in)",
                                  sum(!in_any_set)))
    pieces[["__other__"]] <- ctdna_apply_filter(df[!in_any_set, , drop = FALSE],
                                                  verbose = verbose)
  }

  out <- do.call(rbind, pieces)
  rownames(out) <- NULL
  attr(out, "ctdna_filter_used") <- list(
    scheme    = filter_scheme,
    mode      = if (isTRUE(res$scheme$frozen)) "frozen" else "dynamic",
    general   = res$general,
    overrides = res$scheme$overrides,
    gene_sets = res$gene_sets
  )
  out
}


# ---- Oncoprint --------------------------------------------------------------
#
# Preferred implementation uses ComplexHeatmap::oncoPrint() for real
# publication-quality output. Falls back to a clean ggplot composition
# when ComplexHeatmap is not installed.
#
# Styling conventions:
#   - Gene-set membership shown as left_annotation columns (one column
#     per gene_set), so a gene can belong to multiple sets.
#   - Alteration palette: SNV green, Indel blue, CNV-amp red, etc.
#   - alter_fun: CNV fills the full cell; SNV/Indel a thin centred bar.
#   - Background: grey #CCCCCC with 0.5mm margin.
#   - RECIST palette: CR/PR=blue, SD=green, PD=red, NE/NA=purple.
#   - pct_side = "left", row_names_side = "right".
#   - Patients ordered: Responders -> SD-like -> NE/NA-last.
#   - Genes ordered by alteration frequency.
# -----------------------------------------------------------------------------

# Alteration-type fill palette (template)
.oncoprint_fill_values <- c(
  # Canonical buckets
  SNV     = "#008000",  snv     = "#008000",
  Indel   = "#0000FF",  indel   = "#0000FF",
  CNV     = "#FF0000",  cnv     = "#FF0000",
  # CNV subtypes
  cnv_amp                 = "#FF0000",
  cnv_loss                = "#ADD8E6",
  focal_amplification     = "#FF0000",
  aneuploid_amplification = "#800000",
  loh_deletion            = "#ADD8E6",
  homozygous_deletion     = "#3B0F8C",
  # Fusion + LGR (kept distinct from the green/blue/red trio)
  Fusion  = "#FF7F0E",  fusion  = "#FF7F0E",
  LGR     = "#9467BD",  lgr     = "#9467BD",
  # Common SO terms map to the canonical buckets
  missense_variant        = "#008000",   # SNV-coloured
  stop_gained             = "#0000FF",   # truncating -> Indel-coloured
  frameshift_variant      = "#0000FF",
  splice_donor_variant    = "#0000FF",
  splice_acceptor_variant = "#0000FF"
)

# Per-annotation discrete palette for top-annotation tracks.
# RECIST/BOR uses the template palette (CR/PR blue, SD green, PD red,
# NE/NA purple); collapsed-scheme labels and raw values both supported.
# Unknown values get a grey fallback so CH cannot error.
.oncoprint_anno_palette <- function(ann_name, vals) {
  uvals <- unique(as.character(vals[!is.na(vals)]))
  if (length(uvals) == 0) return(setNames(character(0), character(0)))

  is_recist <- toupper(ann_name) %in% c("RECIST", "RECIST_GROUP", "BOR") ||
               identical(ann_name, .o("recist"))
  if (is_recist) {
    # Template RECIST/BOR palette
    recist_pal <- c(
      # Collapsed labels
      "CR/PR"        = "#0000FF",
      "uCR/PR"       = "#5F00FF",
      "SD"           = "#008000",
      "SD/PD/NE/NA"  = "#7F7F7F",
      "PD/NE/NA"     = "#FF0000",
      "NE/NA"        = "#984EA3",
      "R"            = "#0000FF",
      "NR"           = "#FF0000",
      # Raw RECIST values
      "CR"  = "#0000FF",
      "PR"  = "#0000FF",
      "uCR" = "#5F00FF",
      "uPR" = "#5F00FF",
      "PD"  = "#FF0000",
      "NE"  = "#984EA3",
      "NA"  = "#984EA3"
    )
    out <- character(length(uvals))
    names(out) <- uvals
    for (v in uvals) {
      out[v] <- if (v %in% names(recist_pal)) recist_pal[[v]] else "#9E9E9E"
    }
    return(out)
  }
  # Generic discrete palette for non-RECIST annotations
  pal <- grDevices::hcl.colors(max(length(uvals), 3), palette = "Set2")
  setNames(pal[seq_along(uvals)], uvals)
}

# Distinct colour for each gene_set column in the left annotation.
# Matches the template's Set1-like palette.
.oncoprint_geneset_palette <- function(set_names) {
  base_pal <- c("#377EB8", "#4DAF4A", "#77EDDD", "#E41A1C",
                "#984EA3", "#FF7F00", "#A65628", "#F781BF",
                "#999999", "#1F78B4")
  n <- length(set_names)
  out <- if (n <= length(base_pal)) base_pal[seq_len(n)]
         else grDevices::colorRampPalette(base_pal)(n)
  setNames(out, set_names)
}

# Patient ordering: when a RECIST-like annotation is present, group
# patients by response priority (Responders first, SD-like middle,
# NE/NA last); within each group, sort by mutation burden descending.
# Otherwise, fall back to burden-only ordering.
.oncoprint_patient_order <- function(pat_order, plot_df, patient_col,
                                      patient_data = NULL,
                                      response_col = NULL) {
  burden <- table(plot_df[[patient_col]])
  if (is.null(patient_data) || is.null(response_col) ||
      !response_col %in% names(patient_data)) {
    return(c(names(sort(burden, decreasing = TRUE)),
             setdiff(pat_order, names(burden))))
  }
  pid_col <- intersect(c(patient_col, "Patient_ID", "subject_id"),
                        names(patient_data))[1]
  if (is.na(pid_col)) {
    return(c(names(sort(burden, decreasing = TRUE)),
             setdiff(pat_order, names(burden))))
  }
  pd <- patient_data[match(pat_order, patient_data[[pid_col]]),
                      , drop = FALSE]
  vals <- as.character(pd[[response_col]])
  resp_group <- vapply(vals, function(v) {
    if (is.na(v) || v %in% c("NA","NE","NE/NA")) 3L
    else if (v %in% c("CR","PR","uCR","uPR","CR/PR","uCR/PR","R")) 1L
    else 2L
  }, integer(1))
  ord <- order(resp_group, -as.numeric(burden[pat_order]), pat_order,
                na.last = TRUE)
  pat_order[ord]
}


# === Engine 1: ComplexHeatmap ================================================
.oncoprint_complexheatmap <- function(plot_df, pat_order, all_genes,
                                       patient_col, gene_col, variant_col,
                                       gene_set_df = NULL,
                                       patient_data = NULL,
                                       top_annotations = NULL,
                                       show_freq_bar   = TRUE,
                                       sort_genes      = "global",
                                       title    = "Oncoprint",
                                       legend_position = "bottom") {

  plot_df[[gene_col]]    <- as.character(plot_df[[gene_col]])
  plot_df[[patient_col]] <- as.character(plot_df[[patient_col]])
  plot_df[[variant_col]] <- as.character(plot_df[[variant_col]])

  # Re-order patients using response groups when RECIST is annotated
  recist_in_anno <- intersect(c("RECIST", "Recist", "recist", "BOR", .o("recist")),
                               top_annotations)
  resp_col_for_order <- if (length(recist_in_anno) > 0) recist_in_anno[1] else NULL
  pat_order <- .oncoprint_patient_order(pat_order, plot_df, patient_col,
                                          patient_data, resp_col_for_order)

  # Build the wide matrix expected by oncoPrint
  mat <- matrix("", nrow = length(all_genes), ncol = length(pat_order),
                dimnames = list(all_genes, pat_order))
  key <- paste(plot_df[[gene_col]], plot_df[[patient_col]], sep = "\u0001")
  for (k in unique(key)) {
    parts <- strsplit(k, "\u0001", fixed = TRUE)[[1]]
    g <- parts[1]; p <- parts[2]
    if (g %in% all_genes && p %in% pat_order) {
      vs <- unique(plot_df[[variant_col]][key == k])
      mat[g, p] <- paste(vs, collapse = ";")
    }
  }

  # Drop empty rows; re-order by overall frequency only when caller
  # asked for "global" sort. In "within_set" and "none" modes, the
  # ordering decided by the caller (already encoded in all_genes) is
  # respected so the row-split bands stay consistent.
  freq <- rowSums(mat != "")
  keep <- freq > 0
  if (any(keep)) {
    mat <- mat[keep, , drop = FALSE]
    freq <- freq[keep]
    if (identical(sort_genes, "global")) {
      mat <- mat[order(-freq), , drop = FALSE]
    } else {
      # Preserve incoming all_genes order, but limit to rows present
      mat <- mat[intersect(all_genes, rownames(mat)), , drop = FALSE]
    }
    all_genes <- rownames(mat)
  }

  variants_present <- unique(unlist(strsplit(mat[mat != ""], ";", fixed = TRUE)))
  if (length(variants_present) == 0) variants_present <- "SNV"

  col_list <- vapply(variants_present, function(v) {
    if (v %in% names(.oncoprint_fill_values)) .oncoprint_fill_values[[v]]
    else "#666666"
  }, character(1))

  # Template alter_fun: grey background, CNV fills the cell, SNV/Indel
  # as a thin centred bar (h * 0.33). All with a small 0.5mm margin.
  alter_fun <- list(
    background = function(x, y, w, h)
      grid::grid.rect(x, y, w - grid::unit(0.5, "mm"),
                       h - grid::unit(0.5, "mm"),
                       gp = grid::gpar(fill = "#CCCCCC", col = NA))
  )
  # Variants that look like SNV/Indel get a thin centred bar
  thin_variants <- c("SNV", "snv", "Indel", "indel",
                     "missense_variant", "stop_gained",
                     "frameshift_variant",
                     "splice_donor_variant", "splice_acceptor_variant")
  for (v in variants_present) {
    local({
      vv <- v
      if (vv %in% thin_variants) {
        alter_fun[[vv]] <<- function(x, y, w, h)
          grid::grid.rect(x, y, w - grid::unit(0.5, "mm"), h * 0.33,
                           gp = grid::gpar(fill = col_list[[vv]], col = NA))
      } else {
        alter_fun[[vv]] <<- function(x, y, w, h)
          grid::grid.rect(x, y, w - grid::unit(0.5, "mm"),
                           h - grid::unit(0.5, "mm"),
                           gp = grid::gpar(fill = col_list[[vv]], col = NA))
      }
    })
  }

  # ---------------------------------------------------------------------------
  # Left annotation: one COLUMN per gene_set, NA where the gene is not
  # in that set. This is the "global" sort style: a gene like TP53 can
  # light up in both "TSG" and "Driver" columns simultaneously.
  # In "within_set" mode we skip this because row_split already shows
  # set membership visually and showing both would be redundant.
  # ---------------------------------------------------------------------------
  left_anno <- NULL
  row_split <- NULL

  if (!is.null(gene_set_df) &&
      length(unique(gene_set_df$gene_set)) >= 1) {
    set_names <- as.character(unique(gene_set_df$gene_set))

    if (identical(sort_genes, "within_set")) {
      # Row-split mode: build a factor saying which set each row belongs to
      first_hit <- gene_set_df[match(all_genes, gene_set_df[[gene_col]]), ]
      row_split <- factor(first_hit$gene_set, levels = set_names)
    } else {
      # Global / none: build the multi-membership left annotation
      short_label <- function(s) {
        lookup <- c("TSG Genes" = "TSG", "Indication Driver Genes" = "Driver",
                    "ADC Related Genes" = "ADC", "HRR Genes" = "HRR",
                    "RTK_RAS" = "RTK", "PI3K" = "PI3K", "TP53" = "TP53")
        if (s %in% names(lookup)) lookup[[s]] else
          substr(gsub("_", " ", s), 1, 8)
      }
      geneset_pal <- .oncoprint_geneset_palette(set_names)
      ann_df <- data.frame(row.names = all_genes, check.names = FALSE,
                            stringsAsFactors = FALSE)
      col_list_left <- list()
      for (s in set_names) {
        genes_in_s <- gene_set_df[[gene_col]][gene_set_df$gene_set == s]
        ann_df[[s]] <- ifelse(all_genes %in% genes_in_s, s, NA)
        col_list_left[[s]] <- setNames(geneset_pal[[s]], s)
      }
      left_anno <- ComplexHeatmap::rowAnnotation(
        df             = ann_df,
        col            = col_list_left,
        na_col         = "transparent",
        show_legend    = rep(TRUE, length(set_names)),
        annotation_label = vapply(set_names, short_label, character(1)),
        annotation_name_side = "bottom",
        annotation_name_rot  = 45,
        annotation_name_gp   = grid::gpar(fontsize = 8),
        simple_anno_size     = grid::unit(3, "mm"))
    }
  }

  # ---------------------------------------------------------------------------
  # Top annotation: user-requested tracks (RECIST/BOR + Dose + ...).
  # Template uses annotation_name_side = "left", small font.
  # Build args in ONE pass and patch any missing levels with grey so CH
  # cannot error on unmapped levels.
  # ---------------------------------------------------------------------------
  top_anno <- NULL
  if (!is.null(top_annotations) && !is.null(patient_data) &&
      length(top_annotations) > 0) {
    pid_col <- intersect(c(patient_col, "Patient_ID", "subject_id"),
                          names(patient_data))[1]
    if (!is.na(pid_col)) {
      pd <- patient_data[match(pat_order, patient_data[[pid_col]]),
                          , drop = FALSE]
      ann_args <- list()
      ann_cols <- list()
      for (ann in top_annotations) {
        if (!ann %in% names(pd)) {
          warning("annotation '", ann, "' not in patient_data; skipped.")
          next
        }
        vals <- as.character(pd[[ann]])
        ann_args[[ann]] <- vals
        ann_cols[[ann]] <- .oncoprint_anno_palette(ann, vals)
      }
      # Defensive: any missing values get grey
      for (nm in names(ann_cols)) {
        uvals <- unique(ann_args[[nm]])
        uvals <- uvals[!is.na(uvals)]
        missing <- setdiff(uvals, names(ann_cols[[nm]]))
        if (length(missing) > 0) {
          ann_cols[[nm]] <- c(ann_cols[[nm]],
                               setNames(rep("#9E9E9E", length(missing)),
                                        missing))
        }
      }
      if (length(ann_args) > 0) {
        top_anno <- do.call(
          ComplexHeatmap::HeatmapAnnotation,
          c(ann_args,
            list(col = ann_cols,
                 annotation_name_side    = "left",
                 annotation_name_gp      = grid::gpar(fontsize = 8),
                 simple_anno_size_adjust = TRUE,
                 simple_anno_size        = grid::unit(4, "mm"),
                 gap                     = grid::unit(0.5, "mm")))
        )
      }
    }
  }

  # Right annotation: per-gene frequency barplot. We hide the
  # annotation name to avoid collision with top-annotation row labels
  # in the top-right corner; the axis labels under the bar already
  # convey the meaning.
  right_anno <- if (isTRUE(show_freq_bar)) {
    ComplexHeatmap::rowAnnotation(
      row_barplot = ComplexHeatmap::anno_oncoprint_barplot(
        axis_param = list(side = "bottom", labels_rot = 0,
                           gp = grid::gpar(fontsize = 7))),
      show_annotation_name = FALSE,
      width = grid::unit(2.0, "cm"))
  } else NULL

  # Width: 4 mm per column (template), but capped so the heatmap doesn't
  # explode on cohorts of 200+ patients.
  col_width <- grid::unit(min(4, max(2, 200 / max(ncol(mat), 1))), "mm")
  ht_width <- col_width * ncol(mat)

  # When sets are split visually, widen the gap so the separation is
  # obvious; otherwise keep the tight default.
  row_gap_unit <- if (!is.null(row_split))
    grid::unit(3, "mm") else grid::unit(0.5, "mm")

  ht <- ComplexHeatmap::oncoPrint(
    mat,
    alter_fun  = alter_fun,
    col        = col_list,
    column_title    = title,
    column_title_gp = grid::gpar(fontsize = 12, fontface = "bold"),
    row_names_side  = "right",        # template
    pct_side        = "left",         # template
    row_names_gp    = grid::gpar(fontsize = 9),
    column_names_gp = grid::gpar(fontsize = 6),
    pct_gp          = grid::gpar(fontsize = 8),
    left_annotation  = left_anno,
    right_annotation = right_anno,
    top_annotation   = top_anno,
    row_order    = seq_len(nrow(mat)),    # already sorted by caller
    column_order = seq_len(ncol(mat)),    # already grouped by response
    row_split    = row_split,             # NULL unless sort_genes='within_set'
    column_gap   = grid::unit(0.5, "mm"),
    row_gap      = row_gap_unit,
    width        = ht_width,
    heatmap_legend_param = list(
      title    = "Alteration",
      at       = variants_present,
      labels   = variants_present,
      title_gp = grid::gpar(fontsize = 9, fontface = "bold"),
      labels_gp = grid::gpar(fontsize = 8)),
    show_pct  = TRUE,
    show_heatmap_legend = TRUE)

  structure(list(heatmap = ht, engine = "ComplexHeatmap",
                  legend_side = legend_position),
            class = c("ctdna_oncoprint", "list"))
}


# === Engine 2: ggplot fallback ===============================================
# Uses the same alteration palette as the ComplexHeatmap engine for
# visual consistency across environments.
.oncoprint_ggplot_fallback <- function(plot_df, pat_order, all_genes,
                                        patient_col, gene_col, variant_col,
                                        gene_set_df = NULL,
                                        patient_data = NULL,
                                        top_annotations = NULL,
                                        show_freq_bar = TRUE,
                                        sort_genes = "global",
                                        title    = "Oncoprint",
                                        subtitle = NULL,
                                        caption  = NULL,
                                        legend_position = "bottom") {

  # Patient ordering: same response-group logic as the CH engine
  recist_in_anno <- intersect(c("RECIST","Recist","recist","BOR",.o("recist")),
                               top_annotations)
  resp_col_for_order <- if (length(recist_in_anno) > 0) recist_in_anno[1] else NULL
  pat_order <- .oncoprint_patient_order(pat_order, plot_df, patient_col,
                                          patient_data, resp_col_for_order)

  grid <- expand.grid(patient = pat_order, gene = all_genes,
                      stringsAsFactors = FALSE)
  names(grid) <- c(patient_col, gene_col)
  merged <- merge(grid,
                  plot_df[, c(patient_col, gene_col, variant_col),
                          drop = FALSE],
                  by = c(patient_col, gene_col), all.x = TRUE)
  merged[[patient_col]] <- factor(merged[[patient_col]], levels = pat_order)
  merged[[gene_col]]    <- factor(merged[[gene_col]],
                                    levels = rev(all_genes))

  # Only facet rows by gene_set in within_set mode (visually separates
  # the bands). In global/none mode we plot a single column of rows.
  use_row_facet <- identical(sort_genes, "within_set") &&
                    !is.null(gene_set_df) &&
                    length(unique(gene_set_df$gene_set)) > 1
  if (use_row_facet) {
    merged <- merge(merged, gene_set_df, by = gene_col, all.x = TRUE)
    merged$gene_set <- factor(merged$gene_set,
                              levels = unique(gene_set_df$gene_set))
  }

  variants_present <- unique(plot_df[[variant_col]])

  main <- ggplot2::ggplot(merged,
                          ggplot2::aes(x = .data[[patient_col]],
                                       y = .data[[gene_col]],
                                       fill = .data[[variant_col]])) +
    ggplot2::geom_tile(color = "white", linewidth = 0.3, na.rm = FALSE) +
    ggplot2::scale_fill_manual(values = .oncoprint_fill_values,
                               na.value = "#CCCCCC",
                               name     = "Alteration",
                               breaks   = variants_present,
                               drop     = TRUE) +
    ggplot2::scale_x_discrete(expand = c(0, 0)) +
    ggplot2::scale_y_discrete(expand = c(0, 0)) +
    ctdna_theme() +
    ggplot2::theme(
      axis.text.x = ggplot2::element_text(angle = 90, vjust = 0.5,
                                            hjust = 1, size = 7),
      panel.grid  = ggplot2::element_blank(),
      legend.position = legend_position,
      legend.key.size = grid::unit(0.4, "cm")) +
    ggplot2::labs(x = NULL, y = NULL,
                   title = title, subtitle = subtitle,
                   caption = if (is.null(caption))
                     "Install ComplexHeatmap for publication-quality oncoprint"
                   else caption)
  if (use_row_facet) {
    main <- main +
      ggplot2::facet_grid(rows = ggplot2::vars(.data$gene_set),
                            scales = "free_y", space = "free_y",
                            switch = "y") +
      ggplot2::theme(strip.text.y.left = ggplot2::element_text(angle = 0),
                      strip.placement   = "outside",
                      panel.spacing.y   = grid::unit(2, "mm"))
  }
  structure(list(plot = main, engine = "ggplot2"),
             class = c("ctdna_oncoprint", "list"))
}

# === User-facing function ====================================================

#' Oncoprint of genomic alterations (ComplexHeatmap-backed)
#'
#' Tile plot of patients (columns) x genes (rows) coloured by alteration
#' type. When ComplexHeatmap is installed, calls
#' \code{ComplexHeatmap::oncoPrint()} for publication-quality output
#' with right-margin per-gene barplot, top per-patient burden bar,
#' stacked annotation tracks, gene-set row splits, and a clean merged
#' legend. Falls back to a ggplot tile plot otherwise.
#'
#' @section Install ComplexHeatmap (one-time):
#' \preformatted{
#'   install.packages("BiocManager")
#'   BiocManager::install("ComplexHeatmap")
#' }
#'
#' @section Gene-set API:
#' \code{gene_sets} should be a NAMED list of gene-symbol vectors.
#' \code{NULL} = all genes under one heading. Multi-entry list = one
#' coloured column per set in the left annotation (the same gene can
#' appear in multiple sets) when \code{sort_genes = "global"}, or a
#' separate horizontal band per set when \code{sort_genes = "within_set"}.
#'
#' @section Filtering by indication:
#' Use \code{cancer_type} to restrict the cohort to one or more
#' indications. The package looks up patients in \code{patient_data}
#' whose value in \code{cancer_type_col} matches, then keeps only their
#' alterations in \code{df}. Useful for per-indication oncoprints in
#' multi-indication studies.
#'
#' @section Gene sorting:
#' \code{sort_genes} controls row ordering:
#' \itemize{
#'   \item \code{"global"} (default) - sort all genes by overall alteration
#'     frequency, regardless of set membership. Best when gene sets
#'     overlap or when you want a single ranked list.
#'   \item \code{"within_set"} - sort genes by frequency WITHIN each
#'     set, with a horizontal gap separating sets. Best when sets are
#'     disjoint pathways you want to compare side by side.
#'   \item \code{"none"} - keep gene order as given in \code{gene_sets}.
#' }
#' For backwards compatibility \code{TRUE} maps to \code{"global"} and
#' \code{FALSE} to \code{"none"}.
#'
#' @section Filtering by quality:
#' \code{filter = NULL} uses \code{df} as-is. \code{filter = list(...)}
#' forwards args to \code{\link{ctdna_filter_alterations}} before plotting.
#'
#' @section Engine:
#' \code{engine} selects which backend renders the oncoprint:
#' \itemize{
#'   \item \code{"auto"} (default) - use \code{ComplexHeatmap::oncoPrint()}
#'     if the Bioconductor package is installed, otherwise fall back to
#'     a ggplot tile plot. This is the recommended setting for almost
#'     all uses.
#'   \item \code{"complexheatmap"} - force the ComplexHeatmap engine;
#'     errors with install instructions if the package is missing.
#'     Pick this when you need the publication-quality output (top
#'     burden bar, per-gene frequency bar, stacked annotation tracks,
#'     merged legend) and want a clear failure if the dependency is
#'     missing rather than a silent downgrade.
#'   \item \code{"ggplot"} - force the simpler ggplot tile plot even
#'     if ComplexHeatmap is installed. Useful when you want a plain
#'     ggplot object you can compose with \pkg{patchwork} or theme
#'     further.
#' }
#'
#' @section Filtering (registry-driven):
#' Filtering is now done through a column-by-column registry; see
#' \code{\link{ctdna_filter_opts}} for the full set of filterable
#' Guardant Infinity columns and \code{\link{ctdna_apply_filter}} for
#' how it applies.
#'
#' To enable the registry, set \code{use_registry = TRUE}; it uses the
#' current registry as the "general" filter and applies it to each gene
#' set. To override the general rules for one or more specific sets,
#' pass \code{gene_set_filters}, a NAMED list keyed by gene-set name:
#' \preformatted{
#'   gene_set_filters = list(
#'     RTK_RAS = list(VAF_percentage = list(enabled = TRUE, value = 5.0)),
#'     HRR     = list(ClinVar = list(enabled = TRUE,
#'                                    value = c("Pathogenic",
#'                                              "Likely pathogenic"))))
#' }
#' For each set, the override is merged on top of the general registry:
#' keys you mention replace the general entry for that set only, keys
#' you don't mention fall through. Setting \code{gene_set_filters}
#' implies \code{use_registry = TRUE}.
#'
#' @section Legacy filter:
#' The older \code{filter = list(...)} argument still works and is
#' applied BEFORE the registry pass. Use it for one-off, pipeline-style
#' filtering. Use the registry for analyses you'll repeat.
#'
#' @param df Alteration data frame (vendor or canonical schema).
#' @param gene_sets Named list of gene vectors.
#' @param patient_data Optional per-patient data frame (required if you
#'   use \code{top_annotations} or \code{cancer_type}).
#' @param top_annotations Column names from \code{patient_data} to
#'   display as stacked tracks above the oncoprint.
#' @param cancer_type Optional character vector of indication values
#'   (e.g. \code{"NSCLC"} or \code{c("NSCLC","HNSCC")}). When set,
#'   restricts the cohort to patients with that value in
#'   \code{cancer_type_col} of \code{patient_data}.
#' @param cancer_type_col Column name in \code{patient_data} that holds
#'   the indication. Default \code{"Cancertype"}.
#' @param scheme RECIST collapse for annotation tracks: \code{"raw"}
#'   (default) / \code{"two"} / \code{"three"} / \code{"four"}.
#' @param show_freq_bar Show right-side per-gene frequency barplot.
#' @param filter Optional list of args to ctdna_filter_alterations()
#'   (legacy single-shot filter). Applied BEFORE the registry pass.
#' @param use_registry If TRUE (or implied by setting \code{gene_set_filters}),
#'   apply the column-by-column filter registry (\code{\link{ctdna_filter_opts}})
#'   per gene set.
#' @param gene_set_filters Optional NAMED list of per-gene-set override
#'   lists. See "Filtering" section above.
#' @param patient_col,gene_col,variant_col Column overrides.
#' @param sort_genes \code{"global"} / \code{"within_set"} / \code{"none"}.
#'   See "Gene sorting" section. \code{TRUE}/\code{FALSE} also accepted.
#' @param sort_patients If TRUE (default) reorder patients by response
#'   group and mutation burden; if FALSE keep the input order.
#' @param title,subtitle,caption Display labels.
#' @param legend_position Where the legend sits.
#' @param engine \code{"auto"} / \code{"complexheatmap"} / \code{"ggplot"}.
#'   See "Engine" section.
#' @return A \code{ctdna_oncoprint} object. Print it to draw.
#' @examples
#' sim <- ctdna_make_mock_study(n_patients = 30, seed = 1)
#'
#' # Whole cohort, single ranked list of genes
#' ctdna_plot_oncoprint(sim$infinity_report,
#'                       filter = list(verbose = FALSE))
#'
#' # NSCLC-only cohort
#' ctdna_plot_oncoprint(sim$infinity_report,
#'                       patient_data = sim$clinical,
#'                       cancer_type  = "NSCLC",
#'                       filter = list(verbose = FALSE),
#'                       title = "Oncoprint - NSCLC only")
#'
#' # Multiple gene-sets, separated horizontal bands, genes sorted within set
#' ctdna_plot_oncoprint(sim$infinity_report,
#'                       gene_sets = list(
#'                         RTK_RAS = c("KRAS","EGFR","BRAF","MET"),
#'                         TP53    = "TP53"),
#'                       patient_data = sim$clinical,
#'                       top_annotations = c("RECIST","Dose"),
#'                       sort_genes = "within_set",
#'                       filter = list(verbose = FALSE))
#' @export
ctdna_plot_oncoprint <- function(df,
                                  gene_sets       = NULL,
                                  patient_data    = NULL,
                                  top_annotations = NULL,
                                  cancer_type     = NULL,
                                  cancer_type_col = "Cancertype",
                                  scheme          = c("raw","two","three","four"),
                                  show_freq_bar   = TRUE,
                                  filter          = NULL,
                                  filter_scheme   = NULL,
                                  patient_col     = NULL,
                                  gene_col        = NULL,
                                  variant_col     = NULL,
                                  sort_genes      = c("global","within_set","none"),
                                  sort_patients   = TRUE,
                                  title           = "Oncoprint",
                                  subtitle        = NULL,
                                  caption         = NULL,
                                  legend_position = "bottom",
                                  engine          = c("auto","complexheatmap","ggplot")) {

  engine <- match.arg(engine)
  scheme <- match.arg(scheme)
  # Normalise sort_genes: accept TRUE/FALSE/"global"/"within_set"/"none"
  if (is.logical(sort_genes)) {
    sort_genes <- if (isTRUE(sort_genes)) "global" else "none"
  } else {
    sort_genes <- match.arg(sort_genes, c("global","within_set","none"))
  }

  # Collapse RECIST annotation values per the requested scheme, if any
  if (scheme != "raw" && !is.null(patient_data) &&
      !is.null(top_annotations)) {
    recist_cols <- intersect(c(.o("recist"), "RECIST", "Recist"),
                              top_annotations)
    for (rc in recist_cols) {
      if (rc %in% names(patient_data))
        patient_data[[rc]] <- ctdna_stratify_recist(patient_data[[rc]], scheme)
    }
  }

  if (!is.null(filter)) {
    if (!is.list(filter))
      stop("`filter` must be NULL or a named list of args to ",
           "ctdna_filter_alterations().")
    df <- do.call(ctdna_filter_alterations, c(list(df = df), filter))
  }

  if (is.null(patient_col))
    patient_col <- .alt_col(df, c("Patient_ID", .o("subject"), "subject_id"))
  if (is.null(gene_col))
    gene_col    <- .alt_col(df, c("Gene", .o("gene"), "gene"))
  if (is.null(variant_col))
    variant_col <- .alt_col(df, c("Variant_type", .o("alteration"),
                                   "alteration_type"))
  if (is.null(patient_col) || is.null(gene_col) || is.null(variant_col))
    stop("Could not auto-detect required columns. patient=", patient_col,
         " gene=", gene_col, " variant=", variant_col)
  df <- df[!is.na(df[[gene_col]]) & df[[gene_col]] != "", , drop = FALSE]

  # Apply the three-level filter system (NULL = general, name = specific scheme)
  df <- ctdna_filter_apply_scheme(df, filter_scheme = filter_scheme,
                                    gene_col = gene_col)

  # Filter to a specific indication / cancer type ------------------------------
  if (!is.null(cancer_type)) {
    if (is.null(patient_data))
      stop("`cancer_type` requires `patient_data` so we can look up ",
            "which patients belong to that indication.")
    if (!cancer_type_col %in% names(patient_data))
      stop(sprintf("Column '%s' not found in patient_data. Set `cancer_type_col` to the right column.",
                    cancer_type_col))
    keep_patients <- as.character(
      patient_data[[which(names(patient_data) == cancer_type_col)]]) %in%
      as.character(cancer_type)
    pid_col <- intersect(c(patient_col, "Patient_ID", "subject_id"),
                          names(patient_data))[1]
    if (is.na(pid_col))
      stop("Could not find a patient-ID column in patient_data to join on.")
    keep_ids <- as.character(patient_data[[pid_col]][keep_patients])
    if (length(keep_ids) == 0)
      stop(sprintf("No patients in patient_data have %s in c(%s).",
                    cancer_type_col,
                    paste(shQuote(cancer_type), collapse = ", ")))
    df <- df[as.character(df[[patient_col]]) %in% keep_ids, , drop = FALSE]
    patient_data <- patient_data[keep_patients, , drop = FALSE]
    if (nrow(df) == 0)
      stop(sprintf("No alterations left after filtering to cancer_type = c(%s).",
                    paste(shQuote(cancer_type), collapse = ", ")))
    if (identical(title, "Oncoprint"))
      title <- sprintf("Oncoprint - %s",
                        paste(unique(cancer_type), collapse = " / "))
  }

  if (is.null(gene_sets))
    gene_sets <- list("All genes" = unique(df[[gene_col]]))
  if (!is.list(gene_sets) || is.null(names(gene_sets)) ||
      any(names(gene_sets) == ""))
    stop("`gene_sets` must be a NAMED list of gene-symbol vectors. ",
         "Example: list(RTK_RAS = c('KRAS','EGFR'))")
  gset_df <- do.call(rbind, lapply(names(gene_sets), function(nm) {
    gv <- unique(as.character(gene_sets[[nm]]))
    if (length(gv) == 0) return(NULL)
    data.frame(setNames(list(gv), gene_col), gene_set = nm,
                stringsAsFactors = FALSE)
  }))
  if (is.null(gset_df) || nrow(gset_df) == 0) stop("`gene_sets` is empty.")
  gset_df$gene_set <- factor(gset_df$gene_set, levels = names(gene_sets))
  genes_use <- gset_df[[gene_col]]

  # df is already filtered by ctdna_filter_apply_scheme() at the top of
  # the function, so we only need to restrict to genes in any gene set.
  plot_df <- df[df[[gene_col]] %in% genes_use, , drop = FALSE]
  if (nrow(plot_df) == 0)
    stop("No alteration rows remain - nothing to plot.")
  prio <- c(stop_gained = 1, frameshift_variant = 1,
            splice_donor_variant = 1, splice_acceptor_variant = 1,
            SNV = 3, Indel = 3, missense_variant = 3,
            CNV = 4, cnv_amp = 4, cnv_loss = 5,
            Fusion = 6, fusion = 6, LGR = 7, lgr = 7)
  plot_df$.prio <- prio[plot_df[[variant_col]]]
  plot_df$.prio[is.na(plot_df$.prio)] <- 99
  plot_df <- plot_df[order(plot_df[[patient_col]], plot_df[[gene_col]],
                            plot_df$.prio), ]
  plot_df <- plot_df[!duplicated(plot_df[, c(patient_col, gene_col)]), ]

  all_patients <- unique(df[[patient_col]])
  if (sort_patients) {
    burden <- table(plot_df[[patient_col]])
    pat_order <- c(names(sort(burden, decreasing = TRUE)),
                   setdiff(all_patients, names(burden)))
  } else pat_order <- all_patients

  # Gene ordering ----------------------------------------------------------
  # sort_genes = "global"     -> sort by overall freq (set membership ignored)
  # sort_genes = "within_set" -> sort by freq within each set; engines split rows
  # sort_genes = "none"       -> keep order as given in gene_sets
  gf <- table(plot_df[[gene_col]])
  gset_df$.freq <- as.numeric(gf[gset_df[[gene_col]]])
  gset_df$.freq[is.na(gset_df$.freq)] <- 0

  if (sort_genes == "global") {
    # When sorting globally, a gene may appear in multiple sets.
    # Collapse to one row per gene, taking the max frequency.
    by_gene <- aggregate(.freq ~ get(gene_col), data = gset_df, FUN = max)
    names(by_gene)[1] <- gene_col
    by_gene <- by_gene[order(-by_gene$.freq), ]
    all_genes <- as.character(by_gene[[gene_col]])
    # gset_df still useful for the left_annotation membership columns
  } else if (sort_genes == "within_set") {
    gset_df <- gset_df[order(gset_df$gene_set, -gset_df$.freq), ]
    # In within_set mode, a gene appearing in multiple sets stays a
    # separate row in each set (that's the point of the row-split view).
    all_genes <- as.character(gset_df[[gene_col]])
  } else {
    # "none": keep as-given
    all_genes <- as.character(unique(gset_df[[gene_col]]))
  }
  # Pass the gene_set_df to engines whenever the user provided named
  # sets — even a single one — so left_annotation columns show
  # membership. Only skip when there is exactly one set called
  # "All genes" (the placeholder created when gene_sets = NULL).
  is_default_placeholder <-
    length(unique(gset_df$gene_set)) == 1 &&
    identical(as.character(unique(gset_df$gene_set)), "All genes")
  gset_for_engine <- if (is_default_placeholder) NULL else gset_df

  if (engine == "complexheatmap" ||
      (engine == "auto" && requireNamespace("ComplexHeatmap",
                                              quietly = TRUE))) {
    .oncoprint_complexheatmap(
      plot_df, pat_order, all_genes,
      patient_col, gene_col, variant_col,
      gene_set_df     = gset_for_engine,
      patient_data    = patient_data,
      top_annotations = top_annotations,
      show_freq_bar   = show_freq_bar,
      sort_genes      = sort_genes,
      title           = title,
      legend_position = legend_position)
  } else {
    if (engine == "complexheatmap")
      stop("engine = 'complexheatmap' requires the ComplexHeatmap ",
           "package. Install with:\n",
           "  install.packages('BiocManager')\n",
           "  BiocManager::install('ComplexHeatmap')")
    .oncoprint_ggplot_fallback(
      plot_df, pat_order, all_genes,
      patient_col, gene_col, variant_col,
      gene_set_df     = gset_for_engine,
      patient_data    = patient_data,
      top_annotations = top_annotations,
      show_freq_bar   = show_freq_bar,
      sort_genes      = sort_genes,
      title           = title, subtitle = subtitle, caption = caption,
      legend_position = legend_position)
  }
}

#' Print method for ctdna_oncoprint
#' @param x a ctdna_oncoprint object.
#' @param ... unused.
#' @export
print.ctdna_oncoprint <- function(x, ...) {
  if (identical(x$engine, "ComplexHeatmap")) {
    side <- if (is.null(x$legend_side)) "bottom" else x$legend_side
    ComplexHeatmap::draw(x$heatmap,
                          heatmap_legend_side    = side,
                          annotation_legend_side = side,
                          merge_legend           = TRUE,
                          padding = grid::unit(c(8, 8, 8, 8), "mm"))
  } else {
    print(x$plot)
  }
  invisible(x)
}

# ---- Publication-ready tables -----------------------------------------------

#' Publication-quality table as a ggplot
#'
#' Renders a data frame, matrix, or table as a styled, publication-ready
#' table panel using ggplot2. The result is a real ggplot, so you can:
#' \itemize{
#'   \item save it with \code{ggplot2::ggsave()} at any DPI
#'   \item combine it with plots via \code{patchwork}
#'   \item include it directly in an R Markdown report
#' }
#'
#' Style features:
#' \itemize{
#'   \item Title (bold) / subtitle (grey) / caption (small grey, left-aligned)
#'   \item Bold header row with light grey fill and a black underline rule
#'   \item Alternating row stripes for readability
#'   \item Top and bottom horizontal rules in black
#'   \item Optional first-column header (row labels) bolded
#'   \item Optional diagonal-cell tint for contingency / concordance tables
#'   \item Auto-formatted numeric cells
#' }
#'
#' @param x A data frame, matrix, or \code{table}.
#' @param title,subtitle,caption Display labels (NULL to omit).
#' @param row_names Optional character vector of row labels. Default
#'   \code{NULL} uses \code{rownames(x)} if meaningful; set \code{FALSE}
#'   to suppress the row-label column.
#' @param highlight_diag If TRUE and the data portion is square, the
#'   diagonal cells get a light blue tint (useful for contingency
#'   tables to emphasise agreement).
#' @param number_format \code{sprintf} format string for numeric cells
#'   (default \code{"\%g"}). Set to \code{NULL} to keep values as-is.
#' @param font_family Font family (default \code{""} = the device default).
#' @param base_size Base font size for cell text.
#' @return A ggplot object.
#' @examples
#' tab <- as.data.frame(matrix(c(12, 3, 1, 9), 2, 2,
#'                              dimnames = list(MR = c("Response","NonResponse"),
#'                                              RECIST = c("CR/PR","SD/PD/NE"))))
#' ctdna_table(tab,
#'             title    = "MR x RECIST contingency",
#'             subtitle = "n = 25; Cohen's kappa = 0.62",
#'             caption  = "MR computed at C5D1; cutoff = 50% TF drop",
#'             highlight_diag = TRUE)
#' @export
ctdna_table <- function(x,
                         title          = NULL,
                         subtitle       = NULL,
                         caption        = NULL,
                         row_names      = NULL,
                         highlight_diag = FALSE,
                         number_format  = "%g",
                         font_family    = "",
                         base_size      = 11) {

  # --- Coerce input
  if (inherits(x, "table"))  x <- as.data.frame.matrix(x)
  if (is.matrix(x))          x <- as.data.frame(x, stringsAsFactors = FALSE)
  if (!is.data.frame(x))
    stop("`x` must be a data frame, matrix, or table.")

  # --- Row-name column handling
  has_rn <- TRUE
  if (isFALSE(row_names)) {
    has_rn <- FALSE
  } else if (is.null(row_names)) {
    if (is.null(rownames(x)) ||
        all(rownames(x) == as.character(seq_len(nrow(x)))))
      has_rn <- FALSE
    else
      rn <- rownames(x)
  } else {
    rn <- as.character(row_names)
  }
  if (has_rn) {
    new_x <- data.frame(rn_col = rn, check.names = FALSE,
                         stringsAsFactors = FALSE)
    names(new_x) <- " "                                     # one-space header
    for (cn in names(x)) new_x[[cn]] <- x[[cn]]
    x <- new_x
  }

  # --- Format numeric cells
  fmt_cell <- function(v) {
    if (is.numeric(v) && !is.null(number_format)) {
      vapply(v, function(z) if (is.na(z)) "" else sprintf(number_format, z),
             character(1))
    } else as.character(v)
  }
  fmt_x <- as.data.frame(lapply(x, fmt_cell), stringsAsFactors = FALSE,
                          check.names = FALSE)
  names(fmt_x) <- names(x)

  nrows <- nrow(fmt_x); ncols <- ncol(fmt_x)

  # --- Data layers (cells: row 1..nrows; header: row 0)
  cells <- data.frame(
    row    = rep(seq_len(nrows), ncols),
    col    = rep(seq_len(ncols), each = nrows),
    text   = unlist(fmt_x, use.names = FALSE),
    stripe = rep(ifelse(seq_len(nrows) %% 2 == 0, "even", "odd"), ncols),
    is_rowname_col = rep(if (has_rn) c(TRUE, rep(FALSE, ncols - 1))
                          else rep(FALSE, ncols),
                          each = nrows),
    stringsAsFactors = FALSE)

  header <- data.frame(row = 0, col = seq_len(ncols),
                        text = names(fmt_x),
                        stringsAsFactors = FALSE)

  # --- Diagonal highlight (for square data portion)
  diag_offset <- if (has_rn) 1 else 0
  n_data_rows <- nrows
  n_data_cols <- ncols - diag_offset
  diag_df <- if (isTRUE(highlight_diag) &&
                   n_data_rows == n_data_cols && n_data_rows > 0) {
    data.frame(row = seq_len(n_data_rows),
                col = seq_len(n_data_rows) + diag_offset)
  } else NULL

  # --- Build plot
  p <- ggplot2::ggplot() +
    # Cell backgrounds (alternating stripes)
    ggplot2::geom_tile(data = cells,
                        ggplot2::aes(x = .data$col, y = -.data$row,
                                     fill = .data$stripe),
                        color = "white", linewidth = 0.4,
                        show.legend = FALSE) +
    ggplot2::scale_fill_manual(values = c(odd = "white", even = "grey97"))

  if (!is.null(diag_df)) {
    p <- p + ggplot2::geom_tile(data = diag_df,
                                  ggplot2::aes(x = .data$col, y = -.data$row),
                                  fill = "#D6EAF8", color = "white",
                                  linewidth = 0.4, inherit.aes = FALSE)
  }

  # Header background
  p <- p + ggplot2::geom_tile(data = header,
                                ggplot2::aes(x = .data$col, y = -.data$row),
                                fill = "grey90", color = "white",
                                linewidth = 0.4, inherit.aes = FALSE)

  # --- Top rule, header underline, bottom rule
  rule_top    <- data.frame(x = 0.5, xend = ncols + 0.5,
                              y = 0.5, yend = 0.5)
  rule_under  <- data.frame(x = 0.5, xend = ncols + 0.5,
                              y = -0.5, yend = -0.5)
  rule_bottom <- data.frame(x = 0.5, xend = ncols + 0.5,
                              y = -nrows - 0.5, yend = -nrows - 0.5)
  rules <- rbind(rule_top, rule_bottom)
  p <- p +
    ggplot2::geom_segment(data = rules,
                            ggplot2::aes(x = .data$x, xend = .data$xend,
                                          y = .data$y, yend = .data$yend),
                            color = "black", linewidth = 0.7,
                            inherit.aes = FALSE) +
    ggplot2::geom_segment(data = rule_under,
                            ggplot2::aes(x = .data$x, xend = .data$xend,
                                          y = .data$y, yend = .data$yend),
                            color = "grey50", linewidth = 0.5,
                            inherit.aes = FALSE)

  # --- Cell text
  body_size   <- base_size / 2.85
  header_size <- base_size / 2.7

  # Row-name column text is bold
  if (has_rn) {
    rn_cells <- cells[cells$is_rowname_col, , drop = FALSE]
    body_cells <- cells[!cells$is_rowname_col, , drop = FALSE]
    p <- p +
      ggplot2::geom_text(data = rn_cells,
                          ggplot2::aes(x = .data$col, y = -.data$row,
                                       label = .data$text),
                          size = body_size, fontface = "bold",
                          family = font_family, color = "grey15",
                          inherit.aes = FALSE) +
      ggplot2::geom_text(data = body_cells,
                          ggplot2::aes(x = .data$col, y = -.data$row,
                                       label = .data$text),
                          size = body_size, family = font_family,
                          color = "grey15", inherit.aes = FALSE)
  } else {
    p <- p +
      ggplot2::geom_text(data = cells,
                          ggplot2::aes(x = .data$col, y = -.data$row,
                                       label = .data$text),
                          size = body_size, family = font_family,
                          color = "grey15", inherit.aes = FALSE)
  }

  p <- p +
    ggplot2::geom_text(data = header,
                        ggplot2::aes(x = .data$col, y = -.data$row,
                                     label = .data$text),
                        size = header_size, fontface = "bold",
                        family = font_family, color = "grey5",
                        inherit.aes = FALSE)

  # --- Theme: clean / table-like
  p +
    ggplot2::coord_cartesian(clip = "off") +
    ggplot2::scale_x_continuous(expand = ggplot2::expansion(add = c(0.5, 0.5))) +
    ggplot2::scale_y_continuous(expand = ggplot2::expansion(add = c(1.0, 1.0))) +
    ggplot2::labs(title = title, subtitle = subtitle, caption = caption) +
    ggplot2::theme_void(base_size = base_size, base_family = font_family) +
    ggplot2::theme(
      plot.title    = ggplot2::element_text(face = "bold", hjust = 0,
                                             size = base_size + 1,
                                             margin = ggplot2::margin(b = 4)),
      plot.subtitle = ggplot2::element_text(color = "grey40", hjust = 0,
                                             size = base_size - 1,
                                             margin = ggplot2::margin(b = 8)),
      plot.caption  = ggplot2::element_text(color = "grey40", hjust = 0,
                                             size = base_size - 2,
                                             margin = ggplot2::margin(t = 8)),
      plot.margin   = ggplot2::margin(10, 10, 10, 10)
    )
}


# ---- Multi-modal assembly ---------------------------------------------------

#' Build a validated multi-modal list from separate data frames
#'
#' Takes one data frame per modality and assembles the standard list
#' consumed by [ctdna_merge_modalities()] and the `plot_ctdna_vs_*()` family.
#' Validates required columns based on the current `ctdna_opts()`
#' configuration.
#'
#' Required columns per modality (using the current config):
#'
#' - **ctdna**: subject, time, RECIST, tf
#' - **genomic_74** / **genomic_500**: subject, gene, mutation_status (+ optional panel, alteration_type, vaf)
#' - **expression**: subject, gene, expression
#' - **mutations** (legacy/generic): subject, gene, mutation_status (+ optional panel)
#' - **tmb**: subject, tmb (+ optional panel)
#' - **ihc**: subject, marker, ihc_score
#'
#' Modalities passed as `NULL` are omitted.
#'
#' @param ctdna Longitudinal ctDNA data frame.
#' @param genomic_74 74-gene panel data frame (e.g. GH Infinity).
#' @param genomic_500 500-gene panel data frame (e.g. GH Infinity).
#' @param expression Long-format gene expression data frame.
#' @param mutations Generic / legacy mutation calls (used when neither
#'   `genomic_74` nor `genomic_500` is supplied, or for non-Infinity data).
#' @param tmb Per-subject (per-panel) TMB data.
#' @param ihc Long-format IHC scores.
#' @param strict If `TRUE`, missing required columns raise an error;
#'   otherwise a warning is issued.
#' @return Named list with one element per supplied modality.
#' @export
ctdna_assemble_modalities <- function(ctdna = NULL,
                                genomic_74 = NULL,
                                genomic_500 = NULL,
                                expression = NULL,
                                mutations = NULL,
                                tmb = NULL,
                                ihc = NULL,
                                strict = TRUE) {
  required <- list(
    ctdna       = c(.o("subject"), .o("time"), .o("recist"), .o("tf")),
    genomic_74  = c(.o("subject"), .o("gene"), .o("mutation")),
    genomic_500 = c(.o("subject"), .o("gene"), .o("mutation")),
    expression  = c(.o("subject"), .o("gene"), .o("expression")),
    mutations   = c(.o("subject"), .o("gene"), .o("mutation")),
    tmb         = c(.o("subject"), .o("tmb")),
    ihc         = c(.o("subject"), .o("marker"), .o("ihc_score"))
  )
  inputs <- list(ctdna = ctdna,
                 genomic_74 = genomic_74, genomic_500 = genomic_500,
                 expression = expression, mutations = mutations,
                 tmb = tmb, ihc = ihc)
  inputs <- inputs[!vapply(inputs, is.null, logical(1))]
  if (length(inputs) == 0) stop("Pass at least one modality.")

  # Canonicalize expression unit to ctdna_opts("expression_unit") — default
  # log2(TPM + 1). If the input already carries an attr 'units' = 'tpm', it
  # gets converted in-place. If 'units' is missing, we auto-detect TPM vs
  # log2(TPM+1) by value range and warn (so the user is never confused).
  if ("expression" %in% names(inputs)) {
    inputs$expression <- .canonicalize_expression(inputs$expression)
  }

  for (m in names(inputs)) {
    df <- inputs[[m]]
    if (!is.data.frame(df))
      stop(sprintf("'%s' must be a data frame.", m))
    miss <- setdiff(required[[m]], names(df))
    if (length(miss)) {
      msg <- sprintf("'%s' is missing required column(s): %s.\n  Either rename in your data or set with ctdna_opts(...).",
                     m, paste(miss, collapse = ", "))
      if (strict) stop(msg) else warning(msg)
    }
  }
  inputs
}


# ---- Expression-unit canonicalization ---------------------------------------
# Canonical unit: ctdna_opts("expression_unit") — default "log2_tpm_plus_one".
# Two flows are supported:
#   1) The data frame carries attr(df, "units") = "tpm" or "log2_tpm_plus_one".
#      We honour the tag (convert if needed; tag the output).
#   2) No `units` attribute. We auto-detect from the value range:
#        - max value > 30  → almost certainly TPM (log2(TPM+1) rarely exceeds ~25)
#        - else            → assume already log2(TPM+1)
#      A message is printed so the user is never silently confused.

.detect_expression_unit <- function(values) {
  v <- suppressWarnings(as.numeric(values))
  v <- v[is.finite(v)]
  if (length(v) == 0) return("log2_tpm_plus_one")
  if (max(v, na.rm = TRUE) > 30) "tpm" else "log2_tpm_plus_one"
}

.canonicalize_expression <- function(df) {
  target <- .o("expression_unit")
  expr_col <- .o("expression")
  if (!expr_col %in% names(df)) return(df)
  src <- attr(df, "units")
  if (is.null(src)) {
    src <- .detect_expression_unit(df[[expr_col]])
    message(sprintf("expression: no 'units' attribute; auto-detected as '%s' (max value used as heuristic). Set attr(df, 'units') explicitly to avoid this message.", src))
  }
  if (identical(src, target)) {
    attr(df, "units") <- target
    return(df)
  }
  if (src == "tpm" && target == "log2_tpm_plus_one") {
    df[[expr_col]] <- log2(pmax(as.numeric(df[[expr_col]]), 0) + 1)
    message("expression: converted TPM -> log2(TPM + 1)")
  } else if (src == "log2_tpm_plus_one" && target == "tpm") {
    df[[expr_col]] <- 2 ^ as.numeric(df[[expr_col]]) - 1
    message("expression: converted log2(TPM + 1) -> TPM")
  } else {
    warning(sprintf("expression: don't know how to convert '%s' to '%s'; leaving values unchanged.", src, target))
  }
  attr(df, "units") <- target
  df
}

#' Canonicalize gene expression values to the package unit
#'
#' Converts a long-format expression frame between \code{TPM} and
#' \code{log2(TPM + 1)} so every plotting / statistical function sees
#' the same unit. The target unit is taken from
#' \code{ctdna_opts("expression_unit")} (default
#' \code{"log2_tpm_plus_one"}).
#'
#' The function honours \code{attr(df, "units")} when set (recommended);
#' otherwise it auto-detects from the value range (max > 30 → assumed
#' TPM) and emits a message so the assumption is visible.
#'
#' @param df Long-format expression frame (\code{subject}, \code{gene},
#'   \code{expression} per current \code{ctdna_opts()}).
#' @return The same frame with values in the canonical unit and
#'   \code{attr(.,"units")} set accordingly.
#' @examples
#' # Build a tiny TPM frame and convert it
#' df <- data.frame(subject_id = "S001", gene = c("A","B","C"),
#'                  expression = c(0, 5.4, 412))
#' attr(df, "units") <- "tpm"
#' ctdna_to_log2tpm(df)
#' @export
ctdna_to_log2tpm <- function(df) {
  .canonicalize_expression(df)
}

# ============================================================================
# ctdnaTM — ctdna_make_mock_study()
# ============================================================================
# Comprehensive study simulator. Produces realistic mock data for every
# data type a ctDNA translational-medicine analysis touches, using the
# RAW VENDOR COLUMN NAMES as delivered by Guardant Health Infinity (plus
# IHC, tissue WES/WGS alteration calls, and RNA-seq count + TPM matrices).
#
# The 8 outputs are:
#   $infinity_report      — File 1: per-sample per-alteration master report
#   $tf_change            — File 2: paired TF change, MR_panel = "TF.methyl"
#   $panel_74_response    — File 3: paired 74-gene response report
#   $panel_500_response   — File 4: paired 500-gene response report
#   $methylation_response — File 5: paired methylation panel response
#                                    (MR_panel = "legacy.methyl")
#   $ihc                  — per-patient IHC marker scores
#   $wes                  — tissue WES/WGS alteration calls
#   $rnaseq               — list($counts, $tpm, $sample_metadata)
#
# Conventions:
#   - All patients share the same Study_ID
#   - Each (Patient_ID, Visit_name) has a unique GHSampleID
#   - Visit A is always C1D1 (baseline); Visit B is each later visit
#   - Cancertype is fixed per patient (the indication)
#   - Methylation TF stored in PERCENTAGE units (matches vendor column name)
#   - Dates: real Date objects with realistic offsets per visit cycle
# ============================================================================


# ---- Internal helpers --------------------------------------------------------

# Gene panels (representative subsets — real Infinity panels are larger)
.gh_genes_74 <- c("TP53","KRAS","EGFR","BRAF","PIK3CA","ERBB2","MET","RET",
                  "ROS1","ALK","NRAS","PTEN","CDKN2A","FGFR1","FGFR3",
                  "IDH1","IDH2","KIT","CCND1","CDK4")
.gh_genes_500_only <- c("BRCA1","BRCA2","ATM","CHEK2","RB1","NF1","APC",
                        "MSH2","MLH1","STK11","PALB2","BARD1","BAP1","BLM",
                        "MYC","CTNNB1","SMAD4","ARID1A","SETD2","KMT2D")
.gh_fusion_partners <- list(ALK = "EML4", ROS1 = "CD74", RET = "KIF5B",
                            NTRK1 = "TPM3", FGFR3 = "TACC3", BRAF = "AGK")

# Build a single alteration's variant-specific fields (NA for fields that
# don't apply to that variant_type). Returns a named list of 21 fields.
.gh_build_variant <- function(variant_type, sample_tf_pct) {
  g <- sample(.gh_genes_74, 1)
  row <- list(
    Variant_type          = variant_type,
    Indel_type            = NA_character_,
    Gene                  = g,
    Chromosome            = paste0("chr", sample(1:22, 1)),
    Position              = sample(1e6:2e8, 1),
    Exon                  = NA_integer_,
    Mut_aa                = NA_character_,
    Mut_nt                = NA_character_,
    Mut_cdna              = NA_character_,
    Transcript            = NA_character_,
    VAF_percentage        = NA_real_,
    Splice_effect         = NA_character_,
    Somatic_status        = NA_character_,
    Molecular_consequence = NA_character_,
    Fusion_chrom_b        = NA_character_,
    Fusion_gene_b         = NA_character_,
    Fusion_position_a     = NA_real_,
    Fusion_position_b     = NA_real_,
    Direction_a           = NA_character_,
    Direction_b           = NA_character_,
    Downstream_gene       = NA_character_,
    Copy_number           = NA_real_,
    CNV_type              = NA_character_,
    COSMIC                = NA_character_,
    dbSNP                 = NA_character_,
    ClinVar               = NA_character_,
    ClinVarID             = NA_character_,
    Functional_impact     = NA_character_,
    Mutant_allele_status  = NA_character_,
    Mol_count             = NA_integer_,
    Alleletype            = NA_character_
  )

  aa <- c("A","R","N","D","C","E","Q","G","H","I","L","K","M","F",
          "P","S","T","W","Y","V")
  nt <- c("A","C","G","T")

  if (variant_type %in% c("SNV", "Indel")) {
    row$Exon       <- sample(1:25, 1)
    row$Transcript <- sprintf("NM_%06d.%d", sample(1000:9999, 1),
                              sample(1:5, 1))
    if (variant_type == "SNV") {
      row$Mut_aa <- sprintf("p.%s%d%s", sample(aa, 1),
                            sample(50:600, 1), sample(aa, 1))
      row$Mut_nt <- sprintf("c.%d%s>%s", sample(100:1800, 1),
                            sample(nt, 1), sample(nt, 1))
      row$Molecular_consequence <- sample(
        c("missense_variant","stop_gained","synonymous_variant",
          "splice_donor_variant","splice_acceptor_variant"),
        1, prob = c(0.55, 0.15, 0.10, 0.10, 0.10))
      row$Splice_effect <- if (grepl("splice", row$Molecular_consequence))
        sample(c("Donor lost","Acceptor lost","Cryptic donor"), 1) else NA
    } else {
      row$Indel_type <- sample(c("Insertion", "Deletion"), 1)
      row$Mut_aa <- sprintf("p.%s%dfs", sample(aa, 1), sample(50:600, 1))
      row$Mut_nt <- sprintf("c.%ddel%s", sample(100:1800, 1), sample(nt, 1))
      row$Molecular_consequence <- "frameshift_variant"
    }
    row$Mut_cdna   <- row$Mut_nt
    # VAF roughly tracks sample TF, with skewed distribution
    base_vaf <- stats::rbeta(1, 2, 50) * 100
    row$VAF_percentage <- round(min(base_vaf + sample_tf_pct / 4, 50), 3)
    row$Somatic_status <- sample(c("Somatic","Likely somatic"),
                                  1, prob = c(0.9, 0.1))
    row$COSMIC    <- if (stats::runif(1) < 0.7)
      sprintf("COSM%d", sample(1e4:9.99e5, 1)) else NA
    row$dbSNP     <- if (stats::runif(1) < 0.4)
      sprintf("rs%d", sample(1e5:9e8, 1)) else NA
    row$ClinVar   <- sample(c(NA, "Pathogenic", "Likely pathogenic",
                              "Uncertain significance","Benign"),
                            1, prob = c(0.45, 0.20, 0.15, 0.15, 0.05))
    row$ClinVarID <- if (!is.na(row$ClinVar))
      sprintf("VCV%07d", sample(1e5:1e7, 1)) else NA
    row$Functional_impact <- sample(c("High","Moderate","Low"),
                                     1, prob = c(0.4, 0.4, 0.2))
    row$Mutant_allele_status <- sample(c("Heterozygous","Homozygous"),
                                        1, prob = c(0.85, 0.15))
    row$Mol_count   <- sample(20:5000, 1)
    row$Alleletype  <- "Somatic"
  } else if (variant_type == "CNV") {
    row$CNV_type    <- sample(c("amplification","loss"),
                              1, prob = c(0.6, 0.4))
    row$Copy_number <- if (row$CNV_type == "amplification")
      sample(4:25, 1) else sample(0:1, 1)
    row$Functional_impact <- ifelse(row$CNV_type == "amplification",
                                     "High", "Moderate")
    row$Somatic_status <- "Somatic"
    row$Alleletype  <- "Somatic"
  } else if (variant_type == "Fusion") {
    partner <- if (g %in% names(.gh_fusion_partners))
      .gh_fusion_partners[[g]] else sample(.gh_genes_74, 1)
    row$Fusion_gene_b     <- partner
    row$Fusion_chrom_b    <- paste0("chr", sample(1:22, 1))
    row$Fusion_position_a <- sample(1e6:2e8, 1)
    row$Fusion_position_b <- sample(1e6:2e8, 1)
    row$Direction_a       <- sample(c("+","-"), 1)
    row$Direction_b       <- sample(c("+","-"), 1)
    row$Downstream_gene   <- partner
    row$Functional_impact <- "High"
    row$Somatic_status    <- "Somatic"
  } else if (variant_type == "LGR") {
    row$Functional_impact <- "Moderate"
    row$Somatic_status    <- "Somatic"
  }
  row
}


# ---- Main API ---------------------------------------------------------------

#' Simulate a complete ctDNA translational-medicine study
#'
#' Produces realistic mock data for every data type a ctDNA analysis
#' touches, using the **raw vendor column names** as delivered by
#' Guardant Health Infinity, plus IHC, tissue WES/WGS alteration calls,
#' and RNA-seq (count + TPM matrices with sample metadata).
#'
#' The eight outputs are:
#' \itemize{
#'   \item \strong{infinity_report} — per-sample per-alteration master report
#'   \item \strong{tf_change} — paired Visit_A vs Visit_B TF change (MR_panel = "TF.methyl")
#'   \item \strong{panel_74_response} — paired 74-gene MR response
#'   \item \strong{panel_500_response} — paired 500-gene MR response
#'   \item \strong{methylation_response} — paired methylation MR response (MR_panel = "legacy.methyl")
#'   \item \strong{ihc} — per-patient IHC marker scores
#'   \item \strong{wes} — tissue WES/WGS alteration calls
#'   \item \strong{rnaseq} — list of \code{counts}, \code{tpm}, and \code{sample_metadata}
#' }
#'
#' Patients, visits, sample IDs, dates and cancer types are consistent
#' across all eight outputs (a single patient appears in all of them,
#' joinable by \code{Patient_ID}).
#'
#' @param n_patients Number of patients (default 30).
#' @param visits Visit labels in chronological order. The first must be
#'   the baseline (e.g., \code{"C1D1"}).
#' @param cancer_types Indications to sample from.
#' @param n_rnaseq_genes Number of genes in the RNA-seq matrices.
#' @param study_id Study identifier used as the prefix throughout.
#' @param seed Random seed for reproducibility.
#' @return Named list of eight outputs as described above.
#' @export
ctdna_make_mock_study <- function(n_patients   = 30,
                            visits       = c("C1D1","C2D1","C3D1","C5D1","EOT"),
                            cancer_types = c("NSCLC","CRC","BRCA","mCRPC","GBM"),
                            doses        = c("Low","Mid","High"),
                            n_rnaseq_genes = 2000,
                            study_id     = "STUDY01",
                            seed         = 42) {
  set.seed(seed)

  # ============================================================
  # Patient master table (internal — has biology fields with .)
  # ============================================================
  rec_levels <- c("CR","PR","uCR","SD","PD","NE")
  pts <- data.frame(
    Patient_ID = sprintf("PT%03d", seq_len(n_patients)),
    Cancertype = sample(cancer_types, n_patients, replace = TRUE),
    Dose       = sample(doses, n_patients, replace = TRUE),
    RECIST     = sample(rec_levels, n_patients, replace = TRUE,
                        prob = c(0.10, 0.20, 0.10, 0.30, 0.25, 0.05)),
    stringsAsFactors = FALSE
  )
  best_eff <- c(CR=-100, PR=-50, uCR=-25, SD=-10, PD=25, NE=0)
  pts$best_pct_change <- best_eff[pts$RECIST] +
    stats::rnorm(n_patients, 0, 10)
  # MR derived from RECIST (CR/PR/uCR → Response; SD/PD/NE → NonResponse)
  pts$MR <- ifelse(pts$RECIST %in% c("CR","PR","uCR"),
                   "Response", "NonResponse")

  # Internal biology fields (prefixed . for clarity)
  rec_drop <- c(CR=1.5, PR=1.0, uCR=0.7, SD=0.3, PD=-0.5, NE=0)
  pts$.drop_per_cycle <- rec_drop[pts$RECIST]
  pts$.tf_base_pct    <- 10 ^ stats::runif(n_patients, -2, 0.5)  # 0.01-3 %
  pts$.tmb_base       <- pmax(stats::rgamma(n_patients, 2, 0.5), 0.1)
  pts$.msi_high       <- sample(c("Yes","No"), n_patients,
                                replace = TRUE, prob = c(0.05, 0.95))
  pts$.hrd            <- ifelse(stats::runif(n_patients) < 0.15,
                                round(stats::runif(n_patients, 30, 80), 1),
                                NA_real_)
  pts$.baseline_date  <- as.Date("2024-01-01") +
    sample(0:365, n_patients, replace = TRUE)

  # ============================================================
  # Sample master table (one row per Patient × Visit)
  # ============================================================
  visit_days <- c(C1D1=0, C2D1=21, C3D1=42, C5D1=84, EOT=168)
  sample_rows <- list()
  sidx <- 1
  for (i in seq_len(nrow(pts))) {
    pat <- pts[i, ]
    for (v in visits) {
      vidx <- which(visits == v) - 1
      day_off <- as.integer(visit_days[[v]] + sample(-2:2, 1))
      bloodcoll <- pat$.baseline_date + day_off

      if (vidx == 0) {
        tf <- pat$.tf_base_pct
      } else {
        log10_red <- pat$.drop_per_cycle * vidx + stats::rnorm(1, 0, 0.3)
        tf <- max(pat$.tf_base_pct * 10 ^ (-log10_red), 0.001)
      }
      # Biological cap: methylation TF rarely exceeds 50-80% even in
      # advanced disease. Clip to a realistic ceiling.
      tf <- min(tf, 80)
      qc <- sample(c("PASS","PASS","PASS","PASS","FAIL"), 1)
      sample_rows[[sidx]] <- data.frame(
        sample_seq          = sidx,
        Study_ID            = study_id,
        Patient_ID          = pat$Patient_ID,
        Visit_name          = v,
        Cancertype          = pat$Cancertype,
        Sample_status       = qc,
        Sample_comment      = if (qc == "PASS") NA_character_
                              else "Sample below input requirements",
        Customer_SampleID   = sprintf("%s_%s_%s", study_id, pat$Patient_ID, v),
        GHSampleID          = sprintf("GHS%07d", 5000000 + sidx),
        GHRequestID         = sprintf("GHR%05d", 10000 + sidx),
        Bloodcoll_date      = bloodcoll,
        Received_date       = bloodcoll + sample(1:3, 1),
        Reported_date       = bloodcoll + sample(7:14, 1),
        TF_pct              = tf,
        TMB                 = max(pat$.tmb_base + stats::rnorm(1, 0, 0.5), 0.1),
        MSI_High            = pat$.msi_high,
        HRD_score           = pat$.hrd,
        cfDNA_ng            = round(stats::rgamma(1, 2, 0.5) * 20, 1),
        Plasma_ml_input     = sample(c(4, 6, 8, 10), 1),
        Plasma_ml_remaining = round(stats::runif(1, 0, 5), 1),
        stringsAsFactors    = FALSE
      )
      sidx <- sidx + 1
    }
  }
  samples <- do.call(rbind, sample_rows)
  samples$ctDNA_detection_status <- ifelse(
    samples$TF_pct < 0.1, "Not Detected",
    ifelse(samples$TF_pct < 1, "Below LOQ", "Detected"))
  samples$TMB_category <- ifelse(
    samples$TMB < 6, "Low",
    ifelse(samples$TMB >= 10, "High", "Intermediate"))

  # ============================================================
  # File 1: InfinityReport (per-sample, per-alteration rows)
  # ============================================================
  inf_rows <- list()
  ridx <- 1
  for (si in seq_len(nrow(samples))) {
    sr <- samples[si, ]

    common_id <- list(
      Study_ID          = sr$Study_ID,
      Customer_SampleID = sr$Customer_SampleID,
      GHRequestID       = sr$GHRequestID,
      GHSampleID        = sr$GHSampleID,
      Patient_ID        = sr$Patient_ID,
      Visit_name        = sr$Visit_name
    )
    common_bio <- list(
      Genomic_max_VAF_percentage            = NA_real_,
      HRD_score                             = sr$HRD_score,
      ctDNA_detection_status                = sr$ctDNA_detection_status,
      Methylation_tumor_fraction_percentage = sr$TF_pct,
      TMB_score                             = round(sr$TMB, 2),
      TMB_category                          = sr$TMB_category,
      MSI_High                              = sr$MSI_High,
      cfDNA_ng                              = sr$cfDNA_ng,
      Plasma_ml_input                       = sr$Plasma_ml_input,
      Plasma_ml_remaining                   = sr$Plasma_ml_remaining,
      Received_date                         = sr$Received_date,
      Bloodcoll_date                        = sr$Bloodcoll_date,
      Reported_date                         = sr$Reported_date,
      Cancertype                            = sr$Cancertype,
      Practice_name                         = "Sample Oncology Practice",
      Physician_name                        = "Dr. Sample"
    )
    na_variant <- .gh_build_variant("SNV", 0)  # template
    na_variant[] <- lapply(na_variant, function(x) x[NA])

    if (sr$Sample_status != "PASS") {
      inf_rows[[ridx]] <- as.data.frame(c(
        common_id,
        list(Genomic_somatic_alteration_detected = NA_character_,
             Sample_status  = sr$Sample_status,
             Sample_comment = sr$Sample_comment),
        na_variant,
        lapply(common_bio, function(x) if (length(x)) x else NA)
      ), stringsAsFactors = FALSE)
      ridx <- ridx + 1
      next
    }

    expected_n <- 1 + (sr$TF_pct > 0.5) * 2 + (sr$TF_pct > 5) * 3
    n_alt <- stats::rpois(1, expected_n)

    if (n_alt == 0) {
      inf_rows[[ridx]] <- as.data.frame(c(
        common_id,
        list(Genomic_somatic_alteration_detected = "No",
             Sample_status  = sr$Sample_status,
             Sample_comment = NA_character_),
        na_variant,
        common_bio
      ), stringsAsFactors = FALSE)
      ridx <- ridx + 1
      next
    }

    alt_types <- sample(c("SNV","Indel","CNV","Fusion","LGR"),
                        n_alt, replace = TRUE,
                        prob = c(0.60, 0.10, 0.15, 0.10, 0.05))
    for (alt_t in alt_types) {
      variant <- .gh_build_variant(alt_t, sr$TF_pct)
      inf_rows[[ridx]] <- as.data.frame(c(
        common_id,
        list(Genomic_somatic_alteration_detected = "Yes",
             Sample_status  = sr$Sample_status,
             Sample_comment = NA_character_),
        variant,
        common_bio
      ), stringsAsFactors = FALSE)
      ridx <- ridx + 1
    }
  }
  infinity_report <- do.call(rbind, inf_rows)
  rownames(infinity_report) <- NULL

  # Fill in Genomic_max_VAF_percentage per sample
  for (gh in unique(infinity_report$GHSampleID)) {
    rows <- which(infinity_report$GHSampleID == gh)
    vafs <- infinity_report$VAF_percentage[rows]
    if (any(!is.na(vafs)))
      infinity_report$Genomic_max_VAF_percentage[rows] <-
        max(vafs, na.rm = TRUE)
  }

  # Enforce exact column order from spec
  inf_col_order <- c(
    "Study_ID","Customer_SampleID","GHRequestID","GHSampleID","Patient_ID",
    "Visit_name","Genomic_somatic_alteration_detected","Sample_status",
    "Sample_comment","Variant_type","Indel_type","Gene","Chromosome","Position",
    "Exon","Mut_aa","Mut_nt","Mut_cdna","Transcript","VAF_percentage",
    "Splice_effect","Somatic_status","Molecular_consequence","Fusion_chrom_b",
    "Fusion_gene_b","Fusion_position_a","Fusion_position_b","Direction_a",
    "Direction_b","Downstream_gene","Copy_number","CNV_type","COSMIC","dbSNP",
    "ClinVar","ClinVarID","Functional_impact","Mutant_allele_status",
    "Mol_count","Genomic_max_VAF_percentage","Alleletype","HRD_score",
    "ctDNA_detection_status","Methylation_tumor_fraction_percentage",
    "TMB_score","TMB_category","MSI_High","cfDNA_ng","Plasma_ml_input",
    "Plasma_ml_remaining","Received_date","Bloodcoll_date","Reported_date",
    "Cancertype","Practice_name","Physician_name")
  infinity_report <- infinity_report[, inf_col_order]

  # ============================================================
  # Build paired metadata (Visit A = C1D1, Visit B = each later visit)
  # ============================================================
  pair_list <- list()
  pidx <- 1
  for (i in seq_len(nrow(pts))) {
    pid <- pts$Patient_ID[i]
    a <- samples[samples$Patient_ID == pid & samples$Visit_name == "C1D1", ]
    if (nrow(a) == 0 || a$Sample_status != "PASS") next
    for (v in setdiff(visits, "C1D1")) {
      b <- samples[samples$Patient_ID == pid & samples$Visit_name == v, ]
      if (nrow(b) == 0 || b$Sample_status != "PASS") next
      pair_list[[pidx]] <- data.frame(
        Study_ID            = study_id,
        Patient_ID          = pid,
        Visit_name_A        = "C1D1",
        Customer_SampleID_A = a$Customer_SampleID,
        GHSampleID_A        = a$GHSampleID,
        GHRequestID_A       = a$GHRequestID,
        Cancertype_A        = a$Cancertype,
        Sample_status_A     = a$Sample_status,
        Sample_comment_A    = a$Sample_comment,
        Bloodcoll_date_A    = a$Bloodcoll_date,
        Visit_name_B        = v,
        Customer_SampleID_B = b$Customer_SampleID,
        GHSampleID_B        = b$GHSampleID,
        GHRequestID_B       = b$GHRequestID,
        Cancertype_B        = b$Cancertype,
        Sample_status_B     = b$Sample_status,
        Sample_comment_B    = b$Sample_comment,
        Bloodcoll_date_B    = b$Bloodcoll_date,
        .tf_a               = a$TF_pct,
        .tf_b               = b$TF_pct,
        .vaf_a              = NA_real_,
        .vaf_b              = NA_real_,
        stringsAsFactors    = FALSE
      )
      pidx <- pidx + 1
    }
  }
  paired <- do.call(rbind, pair_list)

  # Per-pair derived stats (shared)
  paired$days_between <- as.integer(paired$Bloodcoll_date_B -
                                     paired$Bloodcoll_date_A)
  paired$Ctdna_pct_change <- (paired$.tf_b - paired$.tf_a) /
    pmax(paired$.tf_a, 0.001) * 100
  paired$Ctdna_lvl_change <- ifelse(paired$.tf_b < paired$.tf_a * 0.5,
                                     "Decrease",
                                     ifelse(paired$.tf_b > paired$.tf_a * 2,
                                            "Increase","No change"))
  paired$MR_QC_status <- sample(c("PASS","PASS","PASS","FAIL"),
                                 nrow(paired), replace = TRUE)
  paired$MR_quantifiable <- sample(c("Yes","No"), nrow(paired),
                                    replace = TRUE, prob = c(0.85, 0.15))
  # Per-panel mean/max VAF based on TF
  paired$.mean_vaf_a <- pmax(paired$.tf_a / 3 +
                              stats::rnorm(nrow(paired), 0, 0.5), 0.01)
  paired$.mean_vaf_b <- pmax(paired$.tf_b / 3 +
                              stats::rnorm(nrow(paired), 0, 0.5), 0.01)
  paired$.max_vaf_a  <- paired$.mean_vaf_a * stats::runif(nrow(paired), 1.3, 2.0)
  paired$.max_vaf_b  <- paired$.mean_vaf_b * stats::runif(nrow(paired), 1.3, 2.0)
  paired$.mr_variant_count <- pmax(round(paired$.tf_a / 2), 0L)

  # ============================================================
  # File 2: tf_change (MR_panel = "TF.methyl")
  # ============================================================
  tf_change <- data.frame(
    Study_ID            = paired$Study_ID,
    Patient_ID          = paired$Patient_ID,
    Visit_name_A        = paired$Visit_name_A,
    Customer_SampleID_A = paired$Customer_SampleID_A,
    GHSampleID_A        = paired$GHSampleID_A,
    GHRequestID_A       = paired$GHRequestID_A,
    Cancertype_A        = paired$Cancertype_A,
    Sample_status_A     = paired$Sample_status_A,
    Sample_comment_A    = paired$Sample_comment_A,
    Bloodcoll_date_A    = paired$Bloodcoll_date_A,
    Visit_name_B        = paired$Visit_name_B,
    Customer_SampleID_B = paired$Customer_SampleID_B,
    GHSampleID_B        = paired$GHSampleID_B,
    GHRequestID_B       = paired$GHRequestID_B,
    Cancertype_B        = paired$Cancertype_B,
    Sample_status_B     = paired$Sample_status_B,
    Sample_comment_B    = paired$Sample_comment_B,
    Bloodcoll_date_B    = paired$Bloodcoll_date_B,
    Days_between        = paired$days_between,
    MR_panel            = "TF.methyl",
    MR_QC_status        = paired$MR_QC_status,
    MR_quantifiable     = paired$MR_quantifiable,
    MR_score_percentage = round(paired$.tf_b, 4),
    Ctdna_percentage_change = round(paired$Ctdna_pct_change, 2),
    Ctdna_level_change      = paired$Ctdna_lvl_change,
    Methylation_tumor_fraction_percentage_A = round(paired$.tf_a, 4),
    Methylation_tumor_fraction_percentage_B = round(paired$.tf_b, 4),
    stringsAsFactors    = FALSE
  )

  # ============================================================
  # File 3 & 4: panel_74_response / panel_500_response
  #   (Shared schema with MR_variant_count + mean/max VAF columns;
  #   500-gene generally has more variants → slightly different stats.)
  # ============================================================
  build_panel_response <- function(panel_label, vaf_scale) {
    data.frame(
      Study_ID            = paired$Study_ID,
      Patient_ID          = paired$Patient_ID,
      Visit_name_A        = paired$Visit_name_A,
      Customer_SampleID_A = paired$Customer_SampleID_A,
      GHSampleID_A        = paired$GHSampleID_A,
      GHRequestID_A       = paired$GHRequestID_A,
      Cancertype_A        = paired$Cancertype_A,
      Sample_status_A     = paired$Sample_status_A,
      Sample_comment_A    = paired$Sample_comment_A,
      Visit_name_B        = paired$Visit_name_B,
      Customer_SampleID_B = paired$Customer_SampleID_B,
      GHSampleID_B        = paired$GHSampleID_B,
      GHRequestID_B       = paired$GHRequestID_B,
      Cancertype_B        = paired$Cancertype_B,
      Sample_status_B     = paired$Sample_status_B,
      Sample_comment_B    = paired$Sample_comment_B,
      Days_between_samples = paired$days_between,
      MR_panel            = panel_label,
      MR_variant_count    = if (panel_label == "74genes")
                              paired$.mr_variant_count
                            else paired$.mr_variant_count + sample(0:3,
                              nrow(paired), replace = TRUE),
      MR_QC_status        = paired$MR_QC_status,
      Mean_VAF_percentage_A = round(paired$.mean_vaf_a * vaf_scale, 4),
      Mean_VAF_percentage_B = round(paired$.mean_vaf_b * vaf_scale, 4),
      Max_VAF_percentage_A  = round(paired$.max_vaf_a  * vaf_scale, 4),
      Max_VAF_percentage_B  = round(paired$.max_vaf_b  * vaf_scale, 4),
      MR_quantifiable     = paired$MR_quantifiable,
      MR_score_percentage = round(paired$.mean_vaf_b * vaf_scale, 4),
      Ctdna_percentage_change = round(paired$Ctdna_pct_change, 2),
      Ctdna_level_change      = paired$Ctdna_lvl_change,
      stringsAsFactors    = FALSE
    )
  }
  panel_74_response  <- build_panel_response("74genes",  1.0)
  panel_500_response <- build_panel_response("500genes", 1.05)

  # ============================================================
  # File 5: methylation_response (MR_panel = "legacy.methyl")
  # ============================================================
  methylation_response <- data.frame(
    Study_ID            = paired$Study_ID,
    Patient_ID          = paired$Patient_ID,
    Visit_name_A        = paired$Visit_name_A,
    Customer_SampleID_A = paired$Customer_SampleID_A,
    GHSampleID_A        = paired$GHSampleID_A,
    GHRequestID_A       = paired$GHRequestID_A,
    Cancertype_A        = paired$Cancertype_A,
    Sample_status_A     = paired$Sample_status_A,
    Sample_comment_A    = paired$Sample_comment_A,
    Visit_name_B        = paired$Visit_name_B,
    Customer_SampleID_B = paired$Customer_SampleID_B,
    GHSampleID_B        = paired$GHSampleID_B,
    GHRequestID_B       = paired$GHRequestID_B,
    Cancertype_B        = paired$Cancertype_B,
    Sample_status_B     = paired$Sample_status_B,
    Sample_comment_B    = paired$Sample_comment_B,
    Days_between_samples = paired$days_between,
    MR_panel            = "legacy.methyl",
    MR_QC_status        = paired$MR_QC_status,
    MR_quantifiable     = paired$MR_quantifiable,
    MR_score_percentage = round(paired$.tf_b * stats::runif(nrow(paired),
                                                            0.9, 1.1), 4),
    Ctdna_percentage_change = round(paired$Ctdna_pct_change *
                                     stats::runif(nrow(paired), 0.8, 1.2), 2),
    Ctdna_level_change      = paired$Ctdna_lvl_change,
    stringsAsFactors    = FALSE
  )

  # ============================================================
  # IHC (per patient × marker, single baseline tissue sample)
  # ============================================================
  ihc_rows <- list()
  iidx <- 1
  for (i in seq_len(nrow(pts))) {
    pat <- pts[i, ]
    rec_effect <- rec_drop[[pat$RECIST]]
    tissue_id  <- sprintf("%s_%s_TISSUE", study_id, pat$Patient_ID)
    collected  <- pat$.baseline_date - sample(7:30, 1)
    for (mk in c("PDL1","CD8","KI67")) {
      raw <- if (mk == "KI67") 40 + stats::rnorm(1, 0, 15)
             else 20 * rec_effect + stats::rnorm(1, 30, 15)
      score <- min(max(round(raw, 1), 0), 100)
      ihc_rows[[iidx]] <- data.frame(
        Study_ID         = study_id,
        Patient_ID       = pat$Patient_ID,
        Tissue_sample_ID = tissue_id,
        Cancertype       = pat$Cancertype,
        Visit_name       = "Baseline_tissue",
        Marker           = mk,
        Method           = ifelse(mk == "PDL1", "TPS",
                                  ifelse(mk == "CD8",
                                         "cells_per_mm2", "percent_positive")),
        Score            = score,
        Score_unit       = ifelse(mk == "CD8", "cells/mm2", "percent"),
        Collection_date  = collected,
        Reported_date    = collected + sample(7:21, 1),
        stringsAsFactors = FALSE
      )
      iidx <- iidx + 1
    }
  }
  ihc <- do.call(rbind, ihc_rows)
  rownames(ihc) <- NULL

  # ============================================================
  # WES/WGS — tissue-based alteration calls
  # ============================================================
  wes_rows <- list()
  widx <- 1
  for (i in seq_len(nrow(pts))) {
    pat <- pts[i, ]
    tissue_id <- sprintf("%s_%s_TISSUE", study_id, pat$Patient_ID)
    collected <- pat$.baseline_date - sample(7:30, 1)
    n_var <- stats::rpois(1, lambda = 6) + 1
    var_types <- sample(c("SNV","Indel","CNV","SV"),
                        n_var, replace = TRUE,
                        prob = c(0.65, 0.15, 0.15, 0.05))
    for (vt in var_types) {
      g <- sample(c(.gh_genes_74, .gh_genes_500_only), 1)
      tum_vaf <- if (vt %in% c("SNV","Indel"))
        round(stats::rbeta(1, 5, 10) * 100, 2) else NA_real_
      total_d <- if (vt %in% c("SNV","Indel"))
        sample(100:500, 1) else NA_integer_
      alt_d <- if (!is.na(tum_vaf))
        round(tum_vaf * total_d / 100) else NA_integer_
      wes_rows[[widx]] <- data.frame(
        Study_ID         = study_id,
        Patient_ID       = pat$Patient_ID,
        Tissue_sample_ID = tissue_id,
        Tissue_type      = "FFPE biopsy",
        Sequencing_panel = sample(c("WES","WGS"), 1, prob = c(0.85, 0.15)),
        Cancertype       = pat$Cancertype,
        Collection_date  = collected,
        Gene             = g,
        Chromosome       = paste0("chr", sample(1:22, 1)),
        Position         = sample(1e6:2e8, 1),
        Variant_type     = vt,
        Mut_aa           = if (vt == "SNV")
          sprintf("p.%s%d%s",
                  sample(c("A","R","D","E","K","L","N","P","Q","S","T","V"), 1),
                  sample(50:600, 1),
                  sample(c("A","R","D","E","K","L","N","P","Q","S","T","V"), 1))
          else if (vt == "Indel") sprintf("p.%s%dfs", "L", sample(50:600, 1))
          else NA_character_,
        Mut_nt           = if (vt %in% c("SNV","Indel"))
                              sprintf("c.%dA>G", sample(100:1800, 1))
                            else NA_character_,
        Transcript       = sprintf("NM_%06d.%d", sample(1000:9999, 1),
                                    sample(1:5, 1)),
        Tumor_VAF        = tum_vaf,
        Normal_VAF       = if (!is.na(tum_vaf))
                             round(stats::rbeta(1, 1, 100) * 100, 3)
                           else NA_real_,
        Total_depth      = total_d,
        Alt_depth        = alt_d,
        Copy_number      = if (vt == "CNV")
                             sample(c(0, 1, 4, 6, 8, 12), 1) else NA_real_,
        Functional_impact = sample(c("High","Moderate","Low"), 1,
                                    prob = c(0.4, 0.4, 0.2)),
        Somatic_status   = sample(c("Somatic","Germline","LOH"), 1,
                                   prob = c(0.85, 0.10, 0.05)),
        COSMIC           = if (stats::runif(1) < 0.5)
                              sprintf("COSM%d", sample(1e4:9.99e5, 1))
                            else NA_character_,
        ClinVar          = sample(c(NA, "Pathogenic","Likely pathogenic",
                                     "Uncertain significance"),
                                   1, prob = c(0.55, 0.20, 0.10, 0.15)),
        # Population frequency annotations (used by ctdna_filter_alterations())
        gnomAD_AF        = if (stats::runif(1) < 0.7) 0
                            else 10 ^ stats::runif(1, -5, -1),
        KG_AF            = if (stats::runif(1) < 0.7) 0
                            else 10 ^ stats::runif(1, -5, -1),
        dbSNP            = if (stats::runif(1) < 0.4)
                              sprintf("rs%d", sample(1e5:9e8, 1))
                            else NA_character_,
        Mutant_allele_status = sample(c("Heterozygous","Homozygous"),
                                       1, prob = c(0.85, 0.15)),
        Molecular_consequence = if (vt == "SNV") sample(
          c("missense_variant","stop_gained","synonymous_variant",
            "splice_donor_variant","splice_acceptor_variant"),
          1, prob = c(0.55, 0.15, 0.10, 0.10, 0.10))
          else if (vt == "Indel") "frameshift_variant"
          else NA_character_,
        stringsAsFactors = FALSE
      )
      widx <- widx + 1
    }
  }
  wes <- do.call(rbind, wes_rows)
  rownames(wes) <- NULL

  # ============================================================
  # RNA-seq — count matrix + TPM + sample metadata
  # ============================================================
  # Sample metadata: one tissue RNA-seq sample per patient (baseline)
  rna_meta <- data.frame(
    Sample_ID        = sprintf("%s_%s_RNA", study_id, pts$Patient_ID),
    Patient_ID       = pts$Patient_ID,
    Cancertype       = pts$Cancertype,
    Visit_name       = "Baseline_tissue",
    Tissue_type      = "FFPE biopsy",
    Library_type     = "polyA",
    Sequencing_date  = pts$.baseline_date - sample(7:30, n_patients,
                                                    replace = TRUE),
    Reads_M          = round(stats::runif(n_patients, 25, 60), 1),
    RIN_score        = round(stats::runif(n_patients, 5.5, 9.0), 1),
    stringsAsFactors = FALSE
  )

  # Gene set: real-looking symbols + numbered placeholders for the rest
  real_genes <- c(.gh_genes_74, .gh_genes_500_only,
                  "CD8A","PDL1","PDCD1","IFNG","MKI67","TGFB1","FOXP3",
                  "CD274","CTLA4","LAG3","TIGIT","HAVCR2","GZMB","PRF1",
                  "CXCL9","CXCL10","CXCL11","IDO1","CD68","CD163","FCGR3A",
                  "VIM","CDH1","CDH2","SNAI1","TWIST1","ZEB1","ESR1","PGR",
                  "AR","FOLH1","KLK3","TMPRSS2","ERG")
  n_extra <- n_rnaseq_genes - length(unique(real_genes))
  if (n_extra > 0) {
    gene_set <- c(unique(real_genes), sprintf("GENE_%05d", seq_len(n_extra)))
  } else {
    gene_set <- unique(real_genes)[seq_len(n_rnaseq_genes)]
  }

  # Per-gene baseline expression (log-scale)
  gene_mu <- stats::rnorm(length(gene_set), mean = 3, sd = 1.5)
  names(gene_mu) <- gene_set

  # Patient × gene effects driven by RECIST for immune genes
  immune_genes <- intersect(c("CD8A","PDL1","PDCD1","IFNG","GZMB","CXCL9",
                              "CXCL10","CTLA4","LAG3","TIGIT","HAVCR2"),
                            gene_set)
  prolif_genes <- intersect(c("MKI67","CDK4","CCND1"), gene_set)
  rec_score    <- rec_drop[pts$RECIST]   # higher = responder

  counts <- matrix(0L,
                    nrow = length(gene_set),
                    ncol = nrow(rna_meta),
                    dimnames = list(gene_set, rna_meta$Sample_ID))
  for (s in seq_len(ncol(counts))) {
    base <- gene_mu + stats::rnorm(length(gene_set), 0, 0.5)
    if (length(immune_genes))
      base[immune_genes] <- base[immune_genes] + 0.7 * rec_score[s]
    if (length(prolif_genes))
      base[prolif_genes] <- base[prolif_genes] - 0.5 * rec_score[s]
    mu_lin <- exp(base) * rna_meta$Reads_M[s] / 30
    counts[, s] <- stats::rnbinom(length(gene_set), mu = mu_lin, size = 5)
  }

  # TPM: scale counts by gene length proxy, then normalize per sample to 1e6
  gene_len_kb <- pmax(stats::rgamma(length(gene_set), 2, 1), 0.3)
  rpk <- counts / gene_len_kb
  per_sample_scaling <- colSums(rpk) / 1e6
  tpm <- sweep(rpk, 2, per_sample_scaling, "/")
  tpm <- round(tpm, 3)

  rnaseq <- list(
    counts          = counts,
    tpm             = tpm,
    sample_metadata = rna_meta
  )

  # ============================================================
  # Clinical / efficacy frame (per patient, joined into ctDNA
  # downstream via ctdna_prepare()). RECIST, dose, best_pct_change
  # and MR live here because real studies deliver them in a
  # separate clinical CRF file — not on the vendor reports.
  # ============================================================
  clinical <- data.frame(
    Study_ID        = study_id,
    Patient_ID      = pts$Patient_ID,
    Cancertype      = pts$Cancertype,
    Dose            = pts$Dose,
    RECIST          = pts$RECIST,
    best_pct_change = round(pts$best_pct_change, 2),
    MR              = pts$MR,
    stringsAsFactors = FALSE
  )

  # ============================================================
  # Assemble final output
  # ============================================================
  out <- list(
    infinity_report      = infinity_report,
    tf_change            = tf_change,
    panel_74_response    = panel_74_response,
    panel_500_response   = panel_500_response,
    methylation_response = methylation_response,
    clinical             = clinical,
    ihc                  = ihc,
    wes                  = wes,
    rnaseq               = rnaseq
  )
  attr(out, "platform")    <- "guardant_health_infinity"
  attr(out, "study_id")    <- study_id
  attr(out, "n_patients")  <- n_patients
  out
}


# ---- Pipeline ---------------------------------------------------------------

#' Run the full ctdnaTM plotting pipeline
#'
#' Generates every standard deliverable (D1-D8 + cross-modality + oncoprint
#' + alteration grid) with a consistent visual style. Common arguments are
#' shared across all plots; plot-specific options can be passed via the
#' \code{...} mechanism through plot-specific override lists.
#'
#' Returns a named list of the individual plot objects; pass
#' \code{compose = TRUE} to also get a patchwork composite figure ready
#' for export.
#'
#' @param ctdna_df Canonical longitudinal ctDNA data frame (\code{$ctdna}
#'   from \code{ctdna_prepare()} or \code{ctdna_assemble_modalities()}).
#' @param expr_df,tmb_df,ihc_df Optional companion modalities for the
#'   cross-modality plots.
#' @param g74_df,g500_df Optional panel data frames for oncoprint /
#'   alteration grid.
#' @param sim Optional list output of \code{ctdna_make_mock_study()} -
#'   provides \code{$infinity_report} + \code{$clinical} for oncoprint
#'   and alteration grid. If \code{NULL}, those plots are skipped.
#' @param stat_position,legend_position Shared display options applied
#'   to every plot.
#' @param scheme Default RECIST stratification scheme ("two", "three",
#'   "four"); overridable per plot via \code{plot_overrides}.
#' @param plot_overrides Named list of per-plot override lists, keyed by
#'   the plot function name without the \code{ctdna_} prefix.
#'   Example: \code{list(plot_baseline = list(vars = c("methylTF","maxAF")))}.
#' @param compose If TRUE, also return a patchwork composite of all
#'   generated plots in a clean grid layout.
#' @param verbose Print progress messages.
#' @return A named list of ggplot objects; if \code{compose = TRUE} also
#'   includes a \code{$composite} element with the patchwork layout.
#' @examples
#' sim <- ctdna_make_mock_study(n_patients = 40, seed = 1)
#' prepped <- ctdna_prepare(
#'   infinity_report    = sim$infinity_report,
#'   tf_change          = sim$tf_change,
#'   panel_74_response  = sim$panel_74_response,
#'   panel_500_response = sim$panel_500_response,
#'   clinical           = sim$clinical,
#'   verbose = FALSE)
#' mm <- ctdna_make_example_multimodal(n_subjects = 40, seed = 1)
#'
#' out <- ctdna_run_pipeline(
#'   ctdna_df = prepped$ctdna,
#'   expr_df  = mm$expression,
#'   tmb_df   = mm$tmb,
#'   ihc_df   = mm$ihc,
#'   g74_df   = mm$genomic_74,
#'   sim      = sim,
#'   stat_position   = "subtitle",
#'   legend_position = "bottom")
#'
#' out$baseline
#' out$mr_recist
#' @export
ctdna_run_pipeline <- function(ctdna_df,
                                expr_df  = NULL,
                                tmb_df   = NULL,
                                ihc_df   = NULL,
                                g74_df   = NULL,
                                g500_df  = NULL,
                                sim      = NULL,
                                stat_position   = .o("stat_position"),
                                legend_position = .o("legend_position"),
                                scheme   = c("two","three","four"),
                                plot_overrides = list(),
                                compose  = FALSE,
                                verbose  = TRUE) {
  scheme <- match.arg(scheme)
  msg <- function(...) if (verbose) message("[pipeline] ", ...)

  shared <- list(stat_position = stat_position,
                  legend_position = legend_position)

  # Helper: call a plot fn with shared args + per-plot overrides
  # Strips kwargs that the target function doesn't accept.
  do_plot <- function(fn_name, args = list()) {
    over <- plot_overrides[[fn_name]]
    if (is.null(over)) over <- list()
    all_args <- modifyList(modifyList(shared, args), over)
    fn <- get(paste0("ctdna_", fn_name))
    fn_formals <- names(formals(fn))
    # Drop unused
    drop <- setdiff(names(all_args), fn_formals)
    if (length(drop)) all_args[drop] <- NULL
    tryCatch(do.call(fn, all_args),
              error = function(e) {
                msg("'", fn_name, "' failed: ", conditionMessage(e))
                NULL
              })
  }

  out <- list()

  msg("D1 baseline by RECIST")
  out$baseline <- do_plot("plot_baseline",
    list(df = ctdna_df, group = .o("recist"),
         vars = .o("tf"), title = "D1 - Baseline by RECIST"))

  msg("D2 baseline by dose x RECIST")
  out$baseline_dose_recist <- do_plot("plot_baseline_dose_recist",
    list(df = ctdna_df, scheme = scheme,
         title = "D2 - Baseline by dose x RECIST"))

  msg("D3 best reduction")
  out$reduction <- do_plot("plot_reduction",
    list(df = ctdna_df, scheme = scheme,
         title = "D3 - Best ctDNA reduction"))

  msg("D4 MR x RECIST")
  mr <- do_plot("plot_mr_recist",
    list(df = ctdna_df,
         title = "D4 - MR / RECIST concordance"))
  if (!is.null(mr)) {
    out$mr_recist       <- mr$plot
    out$mr_recist_table <- mr$table_plot
  }

  msg("D5 longitudinal by dose")
  out$longitudinal <- do_plot("plot_longitudinal",
    list(df = ctdna_df, title = "D5 - Longitudinal by dose"))

  msg("D6 longitudinal by dose x RECIST")
  out$longitudinal_recist <- do_plot("plot_longitudinal_recist",
    list(df = ctdna_df, scheme = scheme,
         title = "D6 - Longitudinal by dose x RECIST"))

  msg("D7 reduction vs % tumor change")
  out$reduction_vs_tumor <- do_plot("plot_reduction_vs_tumor",
    list(df = ctdna_df, scheme = scheme,
         title = "D7 - Reduction vs tumor change"))

  msg("D8 mut vs methyl")
  out$mut_methyl <- do_plot("plot_mut_methyl",
    list(df = ctdna_df, title = "D8 - maxAF vs methylTF"))

  # Cross-modality
  if (!is.null(tmb_df)) {
    msg("Cross-modal: ctDNA vs TMB")
    out$vs_tmb <- do_plot("plot_vs_tmb",
      list(ctdna_df = ctdna_df, tmb_df = tmb_df,
           title = "ctDNA vs TMB"))
  }
  if (!is.null(ihc_df)) {
    msg("Cross-modal: ctDNA vs IHC")
    out$vs_ihc <- do_plot("plot_vs_ihc",
      list(ctdna_df = ctdna_df, ihc_df = ihc_df, marker = "PDL1",
           title = "ctDNA vs PDL1 IHC"))
  }
  if (!is.null(expr_df)) {
    msg("Cross-modal: ctDNA vs expression")
    out$vs_expression <- do_plot("plot_vs_expression",
      list(ctdna_df = ctdna_df, expr_df = expr_df, gene = "PDL1",
           title = "ctDNA vs PDL1 expression"))
  }
  if (!is.null(g74_df)) {
    msg("Cross-modal: ctDNA vs mutation")
    out$vs_mutation <- do_plot("plot_vs_mutation",
      list(ctdna_df = ctdna_df, mut_df = g74_df, gene = "TP53",
           panel = "74genes", title = "ctDNA vs TP53 mutation"))
  }

  # Oncoprint / alteration grid (need genomic source)
  onco_src <- if (!is.null(sim)) sim$infinity_report else g74_df
  pat_src  <- if (!is.null(sim)) sim$clinical else NULL
  if (!is.null(onco_src)) {
    msg("Oncoprint")
    o <- do_plot("plot_oncoprint",
      list(df = onco_src,
           patient_data    = pat_src,
           top_annotations = if (!is.null(pat_src))
             intersect(c("RECIST","Dose"), names(pat_src)) else NULL,
           filter = list(verbose = FALSE),
           title  = "Genomic landscape"))
    if (!is.null(o)) out$oncoprint <- o   # ctdna_oncoprint object
  }
  if (!is.null(onco_src) && !is.null(pat_src)) {
    msg("Alteration grid")
    ag <- do_plot("plot_alteration_grid",
      list(df = onco_src, patient_data = pat_src,
           gene_sets = list(
             TP53  = "TP53",
             RTK   = c("EGFR","ERBB2","MET","ALK","ROS1"),
             RAS   = c("KRAS","NRAS","BRAF"),
             PI3K  = c("PIK3CA","PTEN")),
           response_col   = "RECIST",
           indication_col = "Cancertype",
           filter = list(functional_impact = c("High","Moderate"),
                          verbose = FALSE)))
    if (!is.null(ag)) out$alteration_grid <- ag$plot
  }

  if (compose) {
    msg("Composing layout")
    keep <- out[!vapply(out, is.null, logical(1))]
    n <- length(keep)
    ncol <- if (n <= 4) 2 else 3
    out$composite <- patchwork::wrap_plots(keep, ncol = ncol) +
      patchwork::plot_annotation(
        title    = "ctdnaTM pipeline output",
        subtitle = sprintf("%d plots generated", n),
        caption  = NULL)
  }

  invisible(out)
}


# ---- Help / function catalog ------------------------------------------------

# The catalog itself is a constant. Each entry is a list with:
#   category   - one of the section names below
#   summary    - one-line description, shown in compact mode
#   args       - character vector of key argument names (or NULL = all)
.ctdna_function_catalog <- function() list(

  # --- Configuration ----------------------------------------------------------
  ctdna_opts = list(
    category = "Configuration",
    summary  = "Get / set / reset all package configuration (column names, plot defaults, statistical defaults).",
    args     = c("...", "load", ".reset")
  ),
  ctdna_platforms = list(
    category = "Configuration",
    summary  = "Lists supported vendor / technology combinations that ctdna_prepare() handles."
  ),

  # --- Mock data --------------------------------------------------------------
  ctdna_make_mock_study = list(
    category = "Mock data",
    summary  = "Simulate a complete Guardant Health Infinity vendor bundle (5 files + clinical + IHC + WES + RNA-seq) with realistic biology."
  ),
  ctdna_make_example_multimodal = list(
    category = "Mock data",
    summary  = "Faster canonical-shape multi-modal frames (ctdna, genomic, expression, TMB, IHC)."
  ),

  # --- Vendor -> canonical -----------------------------------------------------
  ctdna_prepare = list(
    category = "Vendor -> canonical",
    summary  = "Transform raw vendor files (Infinity report, TF change, panel response, clinical) into canonical long-format frames."
  ),
  ctdna_assemble_modalities = list(
    category = "Vendor -> canonical",
    summary  = "Validate required columns and assemble a multi-modal database. Auto-converts expression to log2(TPM+1)."
  ),
  ctdna_to_log2tpm = list(
    category = "Vendor -> canonical",
    summary  = "Convert expression values from TPM to log2(TPM+1). Auto-detects when units attribute is missing."
  ),

  # --- Helpers ----------------------------------------------------------------
  ctdna_floor_tf = list(
    category = "Helpers",
    summary  = "Replace zeros (and values below the LOQ) with a display floor so they render on log plots."
  ),
  ctdna_stratify_recist = list(
    category = "Helpers",
    summary  = "Collapse RECIST values into clinically-useful strata. scheme = 'two' / 'three' / 'four'."
  ),
  ctdna_ratio = list(
    category = "Helpers",
    summary  = "Add per-subject baseline_tf and per-visit ratio = TF_visit / TF_baseline."
  ),
  ctdna_summary = list(
    category = "Helpers",
    summary  = "Collapse a longitudinal frame to one row per subject (baseline, best ratio, last TF, metadata)."
  ),
  ctdna_compute_mr = list(
    category = "Helpers",
    summary  = "Per-subject Molecular Response / Non-Response classifier. at = 'best' or named visit; threshold = ratio cutoff (default 0.5)."
  ),
  ctdna_metric_at = list(
    category = "Helpers",
    summary  = "Flexible per-subject ctDNA summary: metric = ratio / tf / pct_change at best / last / a named visit."
  ),
  ctdna_merge_modalities = list(
    category = "Helpers",
    summary  = "Per-subject merge of ctDNA summary with another modality (TMB, IHC, expression)."
  ),
  ctdna_filter_alterations = list(
    category = "Filtering",
    summary  = "Legacy one-shot alteration filter (single-call API)."
  ),
  ctdna_filter_opts = list(
    category = "Filtering",
    summary  = "Get / set / reset the per-column alteration filter registry. Level 1 default + level 2 modified general."
  ),
  ctdna_apply_filter = list(
    category = "Filtering",
    summary  = "Apply the active filter registry (with optional per-call overrides) to an alteration data frame."
  ),
  ctdna_filter_reset_general = list(
    category = "Filtering",
    summary  = "Restore the general filter to factory defaults (level 1)."
  ),
  ctdna_filter_scheme_create = list(
    category = "Filtering",
    summary  = "Create a named specific scheme (level 3) with per-gene-set overrides. dynamic by default, frozen via frozen=TRUE."
  ),
  ctdna_filter_scheme_list = list(
    category = "Filtering",
    summary  = "List all defined specific schemes as a data frame."
  ),
  ctdna_filter_scheme_get = list(
    category = "Filtering",
    summary  = "Retrieve a specific scheme by name."
  ),
  ctdna_filter_scheme_delete = list(
    category = "Filtering",
    summary  = "Delete a specific scheme by name."
  ),
  ctdna_filter_scheme_freeze = list(
    category = "Filtering",
    summary  = "Convert a dynamic scheme to frozen by snapshotting the current general filter."
  ),
  ctdna_filter_scheme_save = list(
    category = "Filtering",
    summary  = "Save all specific schemes + general filter to an RDS file."
  ),
  ctdna_filter_scheme_load = list(
    category = "Filtering",
    summary  = "Load schemes + general filter from an RDS file written by ctdna_filter_scheme_save."
  ),
  ctdna_filter_apply_scheme = list(
    category = "Filtering",
    summary  = "Route a data frame through the three-level filter system. filter_scheme=NULL uses general; a name uses that specific scheme."
  ),

  # --- Statistics -------------------------------------------------------------
  ctdna_pval_label = list(
    category = "Statistics",
    summary  = "Vectorized p-value formatting: 'p=0.012', 'p<0.001', etc."
  ),
  ctdna_run_group_test = list(
    category = "Statistics",
    summary  = "Auto / Wilcoxon / Kruskal-Wallis / t-test / ANOVA depending on the number of groups."
  ),
  ctdna_overall_group_test = list(
    category = "Statistics",
    summary  = "Single overall group test (Kruskal-Wallis or one-way ANOVA)."
  ),
  ctdna_pairwise_ranksum = list(
    category = "Statistics",
    summary  = "All pairwise Wilcoxon / t-tests with multiplicity reporting."
  ),
  ctdna_cor_test = list(
    category = "Statistics",
    summary  = "Spearman / Pearson / Kendall correlation with rho + p-value + n."
  ),
  ctdna_paired_test = list(
    category = "Statistics",
    summary  = "Paired Wilcoxon / paired t-test (baseline vs on-treatment)."
  ),
  ctdna_cohen_kappa = list(
    category = "Statistics",
    summary  = "Cohen's kappa for a 2x2 contingency table (chance-adjusted agreement)."
  ),
  ctdna_concordance_test = list(
    category = "Statistics",
    summary  = "Agreement % + Cohen's kappa + (2x2 only) McNemar p, in one call."
  ),

  # --- Theme & scales ---------------------------------------------------------
  ctdna_theme = list(
    category = "Theme & scales",
    summary  = "Package ggplot2 theme: clean white panels, grey borders, bold titles, italic subtitles."
  ),
  ctdna_colors = list(
    category = "Theme & scales",
    summary  = "Named character vector with RECIST colours (both collapsed labels and raw values)."
  ),
  ctdna_dose_palette = list(
    category = "Theme & scales",
    summary  = "Dose-level colour palette (distinct from the RECIST palette so they never visually collide)."
  ),
  ctdna_scale_recist = list(
    category = "Theme & scales",
    summary  = "ggplot2 colour scale for RECIST (boxes, points, lines)."
  ),
  ctdna_scale_recist_fill = list(
    category = "Theme & scales",
    summary  = "ggplot2 fill scale for RECIST (box fills, ribbon fills) using the same hues at alpha = 0.3."
  ),
  ctdna_scale_dose = list(
    category = "Theme & scales",
    summary  = "ggplot2 colour scale for dose (used when dose is the only stratifier)."
  ),
  ctdna_scale_dose_fill = list(
    category = "Theme & scales",
    summary  = "ggplot2 fill scale for dose."
  ),
  ctdna_scale_dose_shape = list(
    category = "Theme & scales",
    summary  = "ggplot2 shape scale for dose (used when RECIST is on colour and dose needs another aesthetic)."
  ),

  # --- 8 deliverable plots ----------------------------------------------------
  ctdna_plot_baseline = list(
    category = "Deliverable plots (D1-D8)",
    summary  = "D1: Boxplot of baseline value(s) grouped by any clinical factor. scheme + recist_shape supported."
  ),
  ctdna_plot_baseline_dose_recist = list(
    category = "Deliverable plots (D1-D8)",
    summary  = "D2: Baseline methylTF dodged by dose x RECIST. Pairwise within each dose, scheme-aware."
  ),
  ctdna_plot_reduction = list(
    category = "Deliverable plots (D1-D8)",
    summary  = "D3: Per-patient ctDNA reduction. metric in {ratio, tf, pct_change}; at in {best, last, named visit}; mr_threshold drawn."
  ),
  ctdna_plot_mr_recist = list(
    category = "Deliverable plots (D1-D8)",
    summary  = "D4: MR <-> RECIST 2x2 concordance heatmap with agreement / kappa / McNemar. Returns plot + table_plot + numbers."
  ),
  ctdna_plot_longitudinal = list(
    category = "Deliverable plots (D1-D8)",
    summary  = "D5: Per-subject spaghetti trajectory + thick median per dose. Optional recist_color via scheme."
  ),
  ctdna_plot_longitudinal_recist = list(
    category = "Deliverable plots (D1-D8)",
    summary  = "D6: Longitudinal trajectory faceted by dose x RECIST stratum, scheme-aware."
  ),
  ctdna_plot_reduction_vs_tumor = list(
    category = "Deliverable plots (D1-D8)",
    summary  = "D7: Scatter of ctDNA best-ratio vs % tumor change. RECIST = colour, dose = shape."
  ),
  ctdna_plot_mut_methyl = list(
    category = "Deliverable plots (D1-D8)",
    summary  = "D8: Per-baseline maxAF vs methylTF concordance, with discordance threshold. Optional recist_shape."
  ),

  # --- Cross-modality ---------------------------------------------------------
  ctdna_plot_vs_expression = list(
    category = "Cross-modality",
    summary  = "ctDNA metric vs expression of one gene. Optional recist_color via scheme."
  ),
  ctdna_plot_vs_ihc = list(
    category = "Cross-modality",
    summary  = "ctDNA metric vs IHC score of one marker. Optional recist_color via scheme."
  ),
  ctdna_plot_vs_mutation = list(
    category = "Cross-modality",
    summary  = "Boxplot of ctDNA metric by mutation status of one gene. Optional recist_facet via scheme."
  ),
  ctdna_plot_vs_tmb = list(
    category = "Cross-modality",
    summary  = "ctDNA metric vs TMB. Optional recist_color via scheme."
  ),
  ctdna_mutation_concordance = list(
    category = "Cross-modality",
    summary  = "Per-(subject x gene) call agreement between two panels (74-gene vs 500-gene, plasma vs tissue)."
  ),

  # --- Genomic landscape ------------------------------------------------------
  ctdna_plot_oncoprint = list(
    category = "Genomic landscape",
    summary  = "Oncoprint via ComplexHeatmap when installed (top burden bar, right freq bar, annotation tracks, gene-set splits). scheme collapses RECIST annotations."
  ),
  ctdna_plot_alteration_grid = list(
    category = "Genomic landscape",
    summary  = "Stacked-bar grid: indication x gene-set, x = response category, fill = alt vs wt, Fisher p per panel. scheme collapses x-axis."
  ),

  # --- Tables -----------------------------------------------------------------
  ctdna_table = list(
    category = "Tables",
    summary  = "Publication-ready ggplot table from any data frame / matrix / table. Title, subtitle, caption, alternating row stripes, optional diagonal tint."
  ),

  # --- Pipeline ---------------------------------------------------------------
  ctdna_run_pipeline = list(
    category = "Pipeline",
    summary  = "Run every standard deliverable (D1-D8 + cross-modality + oncoprint + alteration grid) in one call with consistent display options."
  )
)


#' Print a categorized listing of every function in ctdnaTM
#'
#' Prints the catalog of all 48 exported functions in this package,
#' grouped by purpose, with their key arguments and a one-line
#' description of what each one does. Useful when you can't remember
#' which function does what.
#'
#' @param category Optional. Restrict to one category. One of:
#'   `"Configuration"`, `"Mock data"`, `"Vendor -> canonical"`,
#'   `"Helpers"`, `"Statistics"`, `"Theme & scales"`,
#'   `"Deliverable plots (D1-D8)"`, `"Cross-modality"`,
#'   `"Genomic landscape"`, `"Tables"`, `"Pipeline"`.
#'   Partial matching supported (`"plot"`, `"stat"`, `"deliv"`, ...).
#' @param search Optional. A regex; only functions whose name OR
#'   summary matches are shown.
#' @param show_args If TRUE (default) print key argument names under
#'   each function.
#' @param width Maximum line width for the printed summary (default 78).
#' @return Invisibly returns a data frame (`name`, `category`, `summary`,
#'   `args`) of the matching rows, suitable for further programmatic use.
#' @examples
#' ctdna_help()                           # everything, grouped
#' ctdna_help("plot")                     # all plot functions
#' ctdna_help("stat")                     # the statistics group
#' ctdna_help(search = "RECIST")          # name or summary contains "RECIST"
#' ctdna_help(show_args = FALSE)          # compact mode: one line per fn
#'
#' # Programmatic use: get the catalog as a data frame
#' df <- ctdna_help()
#' subset(df, category == "Helpers")
#' @export
ctdna_help <- function(category = NULL,
                        search = NULL,
                        show_args = TRUE,
                        width = 78) {

  cat_tbl <- .ctdna_function_catalog()
  # Augment each entry with argument names from formals()
  rows <- lapply(names(cat_tbl), function(nm) {
    entry <- cat_tbl[[nm]]
    fn <- tryCatch(get(nm, envir = asNamespace("ctdnaTM")),
                    error = function(e) NULL)
    actual_args <- if (!is.null(fn) && is.function(fn))
      names(formals(fn)) else character(0)
    args_use <- if (is.null(entry$args)) actual_args else entry$args
    data.frame(name     = nm,
                category = entry$category,
                summary  = entry$summary,
                args     = paste(actual_args, collapse = ", "),
                stringsAsFactors = FALSE)
  })
  df <- do.call(rbind, rows)

  # Filter by category
  if (!is.null(category)) {
    cats <- unique(df$category)
    hit <- grep(category, cats, ignore.case = TRUE, value = TRUE)
    if (length(hit) == 0)
      stop("No category matches '", category, "'. Available: ",
           paste(cats, collapse = "; "))
    df <- df[df$category %in% hit, , drop = FALSE]
  }

  # Filter by search
  if (!is.null(search)) {
    keep <- grepl(search, df$name, ignore.case = TRUE) |
            grepl(search, df$summary, ignore.case = TRUE)
    df <- df[keep, , drop = FALSE]
    if (nrow(df) == 0) {
      message("No matches for '", search, "'.")
      return(invisible(df))
    }
  }

  # Render
  v <- utils::packageVersion("ctdnaTM")
  cat(sprintf("ctdnaTM v%s\n", v))
  cat(strrep("=", min(width, 78)), "\n", sep = "")

  for (cat_name in unique(df$category)) {
    sub <- df[df$category == cat_name, , drop = FALSE]
    cat(sprintf("\n[%s]  (%d functions)\n",
                cat_name, nrow(sub)))
    cat(strrep("-", min(width, 78)), "\n", sep = "")
    for (i in seq_len(nrow(sub))) {
      cat(sprintf("  %s()\n", sub$name[i]))
      # Wrap summary
      summary_lines <- strwrap(sub$summary[i], width = width - 6,
                                exdent = 0)
      for (line in summary_lines)
        cat(sprintf("      %s\n", line))
      if (show_args && nzchar(sub$args[i])) {
        arg_text <- paste0("args: ", sub$args[i])
        arg_lines <- strwrap(arg_text, width = width - 6, exdent = 12)
        for (line in arg_lines)
          cat(sprintf("      %s\n",
                       gsub("\u00a0", " ", line, fixed = TRUE)))
      }
    }
  }
  cat("\n", strrep("=", min(width, 78)), "\n", sep = "")
  cat(sprintf("Total: %d functions shown",
              nrow(df)))
  if (!is.null(category) || !is.null(search))
    cat(sprintf("  (filtered from %d total)",
                 length(.ctdna_function_catalog())))
  cat("\nFor full docs: ?function_name. Vignette: vignette('ctdnaTM').\n")

  invisible(df)
}
