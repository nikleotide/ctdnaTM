# ============================================================================
# ctdnaTM — platform preparation
# ============================================================================
# ctdna_prepare() is the entry point that takes RAW vendor data (the
# multiple files delivered per ctDNA platform) and produces the
# CANONICAL analysis-ready data structures (column names per
# ctdna_opts()) that the rest of the package consumes.
#
# For Guardant Health Infinity, raw inputs are:
#   - infinity_report      : per-sample per-alteration master report
#   - tf_change            : paired Visit_A vs Visit_B TF change (TF.methyl)
#   - panel_74_response    : paired 74-gene MR response
#   - panel_500_response   : paired 500-gene MR response
#   - methylation_response : paired methylation MR response (legacy.methyl)
#   - clinical             : per-patient efficacy / dose / RECIST / MR
#
# Canonical outputs (column names follow ctdna_opts()):
#   $ctdna       : long-format longitudinal TF
#                  (subject, time, dose, RECIST, methylTF, maxAF,
#                   best_pct_change, MR)
#   $genomic_74  : baseline per-(subject × gene) calls
#                  (subject, gene, panel, alteration_type,
#                   mutation_status, vaf)
#   $genomic_500 : same shape, larger gene set
#
# Each platform registers a handler in `.platforms`. To add a new
# platform, append a list entry with $name and $prepare.
# ============================================================================


# ---- 74- and 500-gene panels ------------------------------------------------
# `.gh_genes_74` and `.gh_genes_500_only` are file-level constants
# defined in ctdnaTM.R (alongside ctdna_make_mock_study). Both files are
# loaded at package load so the constants are visible here.


# ---- Vendor variant_type → canonical alteration_type ------------------------
# Canonical values: {wt, snv, cnv_amp, cnv_loss, lgr, fusion}.
.gh_alt_type <- function(variant_type, copy_number) {
  out <- character(length(variant_type))
  out[variant_type == "SNV"]    <- "snv"
  out[variant_type == "Indel"]  <- "snv"           # collapse indel → snv class
  out[variant_type == "Fusion"] <- "fusion"
  out[variant_type == "LGR"]    <- "lgr"
  cnv_mask <- variant_type == "CNV"
  if (any(cnv_mask)) {
    cn <- copy_number[cnv_mask]
    out[cnv_mask] <- ifelse(!is.na(cn) & cn >= 4, "cnv_amp", "cnv_loss")
  }
  out
}


# ---- Build canonical ctDNA longitudinal frame from vendor data --------------
# Unstacks the paired Visit_A vs Visit_B representation into long format,
# joins per-sample maxAF (from infinity_report) and per-patient clinical
# fields (RECIST, dose, best_pct_change, MR).
.gh_build_ctdna_long <- function(tf_change,
                                  infinity_report = NULL,
                                  clinical = NULL,
                                  qc_filter = TRUE,
                                  verbose = TRUE) {

  if (qc_filter) {
    n0 <- nrow(tf_change)
    tf_change <- tf_change[
      tf_change$MR_QC_status   %in% c("PASS","SUCCESS","Pass","pass") &
      tf_change$MR_quantifiable %in% c("Yes","TRUE","yes"), ]
    if (verbose)
      message(sprintf("  tf_change: kept %d / %d pairs after MR_QC filter",
                      nrow(tf_change), n0))
  }

  # Long-format: one row per (Patient × Visit). Both legs of the pair
  # contribute (A always baseline; B always later). Dedupe at the end.
  a_rows <- data.frame(
    subject_id      = tf_change$Patient_ID,
    time_point      = tf_change$Visit_name_A,
    methylTF        = tf_change$Methylation_tumor_fraction_percentage_A / 100,
    .date           = tf_change$Bloodcoll_date_A,
    stringsAsFactors = FALSE
  )
  b_rows <- data.frame(
    subject_id      = tf_change$Patient_ID,
    time_point      = tf_change$Visit_name_B,
    methylTF        = tf_change$Methylation_tumor_fraction_percentage_B / 100,
    .date           = tf_change$Bloodcoll_date_B,
    stringsAsFactors = FALSE
  )
  long <- rbind(a_rows, b_rows)
  long <- long[!duplicated(long[, c("subject_id","time_point")]), ]
  long <- long[order(long$subject_id, long$.date), ]

  # ---- maxAF per sample (from infinity_report) ----
  if (!is.null(infinity_report)) {
    ir <- infinity_report[infinity_report$Sample_status %in% c("PASS","SUCCESS","Pass","pass"), ]
    ir <- ir[!is.na(ir$VAF_percentage), ]
    if (nrow(ir) > 0) {
      maxaf <- stats::aggregate(VAF_percentage ~ Patient_ID + Visit_name,
                                 data = ir, FUN = max)
      names(maxaf) <- c("subject_id", "time_point", "maxAF")
      maxaf$maxAF  <- maxaf$maxAF / 100
      long <- merge(long, maxaf, by = c("subject_id","time_point"),
                     all.x = TRUE)
    } else {
      long$maxAF <- NA_real_
    }
  } else {
    long$maxAF <- NA_real_
  }

  # ---- Clinical join (RECIST, dose, best_pct_change, MR) ----
  if (!is.null(clinical)) {
    cli <- data.frame(
      subject_id       = clinical$Patient_ID,
      dose             = if ("Dose" %in% names(clinical)) clinical$Dose
                         else if ("dose" %in% names(clinical)) clinical$dose
                         else NA_character_,
      RECIST           = clinical$RECIST,
      best_pct_change  = clinical$best_pct_change,
      MR               = clinical$MR,
      stringsAsFactors = FALSE
    )
    long <- merge(long, cli, by = "subject_id", all.x = TRUE)
    long <- long[order(long$subject_id, long$.date), ]
  } else {
    long$dose            <- NA_character_
    long$RECIST          <- NA_character_
    long$best_pct_change <- NA_real_
    long$MR              <- NA_character_
  }

  # Drop internal .date helper before returning
  long$.date <- NULL
  rownames(long) <- NULL

  # Reorder to a sensible canonical column order
  col_order <- c("subject_id","time_point","dose","RECIST","methylTF",
                  "maxAF","best_pct_change","MR")
  col_order <- intersect(col_order, names(long))
  long <- long[, col_order, drop = FALSE]

  # Apply current ctdna_opts() renaming
  .apply_opts_names(long, c(
    subject_id      = "subject",
    time_point      = "time",
    dose            = "dose",
    RECIST          = "recist",
    methylTF        = "tf",
    maxAF           = "maxaf",
    best_pct_change = "best_change",
    MR              = "mr"
  ))
}


# ---- Build canonical baseline-only genomic frame ----------------------------
# One row per (subject × gene) for the panel's gene list. Detected
# alterations get mutation_status = "mut" and the appropriate
# alteration_type; non-detected get mutation_status = "wt".
.gh_build_genomic <- function(infinity_report,
                               panel_genes,
                               panel_label,
                               baseline_visit = "C1D1",
                               verbose = TRUE) {
  ir <- infinity_report[
    infinity_report$Visit_name == baseline_visit &
    infinity_report$Sample_status %in% c("PASS","SUCCESS","Pass","pass"), ]

  all_patients <- sort(unique(ir$Patient_ID))
  if (length(all_patients) == 0)
    return(data.frame(subject_id=character(), gene=character(),
                       panel=character(), alteration_type=character(),
                       mutation_status=character(), vaf=numeric(),
                       stringsAsFactors = FALSE))

  detected <- ir[!is.na(ir$Gene) & ir$Gene %in% panel_genes, ]
  if (nrow(detected) > 0) {
    det_df <- data.frame(
      subject_id       = detected$Patient_ID,
      gene             = detected$Gene,
      panel            = panel_label,
      alteration_type  = .gh_alt_type(detected$Variant_type,
                                       detected$Copy_number),
      mutation_status  = "mut",
      vaf              = detected$VAF_percentage,   # percentage units
      stringsAsFactors = FALSE
    )
    # When the same (subject, gene) has multiple variants, collapse to one
    # row keeping the highest-impact (snv > cnv_amp > fusion > others).
    impact_rank <- c(snv = 1, cnv_amp = 2, cnv_loss = 3, fusion = 4,
                      lgr = 5, wt = 6)
    det_df$.rank <- impact_rank[det_df$alteration_type]
    det_df <- det_df[order(det_df$subject_id, det_df$gene, det_df$.rank), ]
    det_df <- det_df[!duplicated(det_df[, c("subject_id","gene")]), ]
    det_df$.rank <- NULL
  } else {
    det_df <- data.frame(subject_id=character(), gene=character(),
                          panel=character(), alteration_type=character(),
                          mutation_status=character(), vaf=numeric(),
                          stringsAsFactors = FALSE)
  }

  # Enumerate wt rows for (Patient × Gene) combos that weren't detected
  grid <- expand.grid(subject_id = all_patients, gene = panel_genes,
                       stringsAsFactors = FALSE)
  det_keys <- paste(det_df$subject_id, det_df$gene)
  grid_keys <- paste(grid$subject_id, grid$gene)
  wt <- grid[!(grid_keys %in% det_keys), , drop = FALSE]
  wt$panel           <- panel_label
  wt$alteration_type <- "wt"
  wt$mutation_status <- "wt"
  wt$vaf             <- NA_real_
  wt <- wt[, names(det_df)]

  out <- rbind(det_df, wt)
  out <- out[order(out$subject_id, out$gene), ]
  rownames(out) <- NULL
  if (verbose)
    message(sprintf("  %s: %d detected + %d wt = %d rows",
                    panel_label, nrow(det_df), nrow(wt), nrow(out)))

  .apply_opts_names(out, c(
    subject_id       = "subject",
    gene             = "gene",
    panel            = "panel",
    alteration_type  = "alteration",
    mutation_status  = "mutation"
  ))
}


# ---- Guardant Health Infinity prep ------------------------------------------
.prepare_gh_infinity <- function(infinity_report      = NULL,
                                  tf_change            = NULL,
                                  panel_74_response    = NULL,
                                  panel_500_response   = NULL,
                                  methylation_response = NULL,
                                  clinical             = NULL,
                                  qc_filter            = TRUE,
                                  verbose              = TRUE) {
  out <- list()

  # ctdna longitudinal frame: prefer tf_change (TF.methyl), fall back to
  # methylation_response (legacy.methyl). Warn if only legacy is present.
  src <- tf_change
  src_name <- "tf_change (TF.methyl)"
  if (is.null(src) && !is.null(methylation_response)) {
    warning("Only legacy.methyl is present (no TF.methyl tf_change). ",
            "Guardant Health is phasing out legacy.methyl in favor of ",
            "TF.methyl; treat results accordingly.")
    # Synthesize TF_A / TF_B from MR_score_percentage (legacy.methyl format
    # doesn't carry the explicit A/B TF columns).
    # Each row already has Visit_A baseline / Visit_B later; the MR score
    # is the Visit_B TF, so reconstruct A by joining baselines.
    mr <- methylation_response
    mr$Methylation_tumor_fraction_percentage_B <- mr$MR_score_percentage
    # For A, use the baseline pair (Visit_name_A=="C1D1") MR score from
    # the same patient — pull from the first row per patient.
    base <- mr[!duplicated(mr$Patient_ID), ]
    base_lookup <- stats::setNames(base$MR_score_percentage / 1, base$Patient_ID)
    # We don't actually have separate A TF; approximate as patient's max
    # MR_score across that patient's pairs (the most baseline-like value).
    pa <- stats::aggregate(MR_score_percentage ~ Patient_ID, data = mr, FUN = max)
    base_lookup <- stats::setNames(pa$MR_score_percentage, pa$Patient_ID)
    mr$Methylation_tumor_fraction_percentage_A <-
      base_lookup[as.character(mr$Patient_ID)]
    mr$Bloodcoll_date_A <- mr$Bloodcoll_date_B <- NA
    mr$MR_QC_status     <- mr$MR_QC_status
    mr$MR_quantifiable  <- mr$MR_quantifiable
    src <- mr
    src_name <- "methylation_response (legacy.methyl)"
  }

  if (!is.null(src)) {
    if (verbose) message("  building ctdna long-format from ", src_name)
    out$ctdna <- .gh_build_ctdna_long(
      tf_change       = src,
      infinity_report = infinity_report,
      clinical        = clinical,
      qc_filter       = qc_filter,
      verbose         = verbose
    )
  }

  # genomic_74: requires infinity_report (per-variant rows). The
  # panel_74_response file gives aggregated MR stats; not used directly
  # for per-gene calls here but its presence implies the panel was run.
  if (!is.null(infinity_report)) {
    if (verbose) message("  building genomic_74 from infinity_report")
    out$genomic_74 <- .gh_build_genomic(
      infinity_report = infinity_report,
      panel_genes     = .gh_genes_74,
      panel_label     = "74genes",
      verbose         = verbose
    )
    if (!is.null(panel_500_response) ||
        (!is.null(infinity_report) && !is.null(panel_74_response))) {
      if (verbose) message("  building genomic_500 from infinity_report")
      out$genomic_500 <- .gh_build_genomic(
        infinity_report = infinity_report,
        panel_genes     = c(.gh_genes_74, .gh_genes_500_only),
        panel_label     = "500genes",
        verbose         = verbose
      )
    }
  }

  out
}


# ---- Platform registry ------------------------------------------------------
.platforms <- list(
  guardant_health_infinity = list(
    name    = "Guardant Health Infinity",
    prepare = .prepare_gh_infinity
  )
  # future platforms here, e.g.:
  # natera_signatera = list(name = "Natera Signatera", prepare = .prepare_natera_signatera),
)


# ---- Public API -------------------------------------------------------------

#' Prepare ctDNA data for downstream analysis
#'
#' Platform-specific transformation step. Takes the raw per-platform
#' files delivered by the vendor (for Guardant Health Infinity: the
#' InfinityReport plus the paired-sample response reports) and returns
#' the canonical analysis-ready data structures with column names per
#' \code{ctdna_opts()}.
#'
#' Dispatches to a platform handler based on \code{vendor} and
#' \code{technology}. Defaults to \strong{Guardant Health Infinity}.
#'
#' For GH Infinity the transformation is:
#' \itemize{
#'   \item ctdna long-format frame from \code{tf_change} (preferred) or
#'     \code{methylation_response} (legacy). Visit_A and Visit_B legs are
#'     unstacked into one row per (Patient × Visit).
#'   \item maxAF per sample is pulled from \code{infinity_report}.
#'   \item Clinical fields (RECIST, dose, best_pct_change, MR) are joined
#'     from the \code{clinical} frame.
#'   \item Genomic_74 and genomic_500 are derived from
#'     \code{infinity_report} at baseline: detected alterations →
#'     mutation_status = "mut"; remaining genes in the panel →
#'     mutation_status = "wt".
#' }
#'
#' All column names in the output follow the current \code{ctdna_opts()}
#' configuration. Units: methylTF and maxAF are FRACTIONS (0-1); vaf in
#' the genomic frames is PERCENTAGE (0-50).
#'
#' @param infinity_report Raw vendor InfinityReport data frame.
#' @param tf_change Raw vendor TF_change paired data frame (MR_panel =
#'   "TF.methyl"). Preferred over \code{methylation_response}.
#' @param panel_74_response Raw vendor 74-gene response data frame.
#' @param panel_500_response Raw vendor 500-gene response data frame.
#' @param methylation_response Raw vendor methylation response data frame
#'   (MR_panel = "legacy.methyl"). Used only if \code{tf_change} is NULL.
#' @param clinical Per-patient clinical / efficacy data frame: Patient_ID,
#'   RECIST, Dose, best_pct_change, MR. Joined into the ctdna output.
#' @param vendor Vendor identifier. Default \code{"guardant_health"}.
#' @param technology Technology identifier. Default \code{"infinity"}.
#' @param qc_filter If \code{TRUE}, drop rows that fail vendor QC.
#' @param verbose If \code{TRUE}, print informational messages.
#' @return A named list with elements \code{ctdna}, \code{genomic_74},
#'   \code{genomic_500} (each present only if the inputs allow). The
#'   \code{platform} attribute records the resolved platform key.
#' @export
ctdna_prepare <- function(infinity_report      = NULL,
                          tf_change            = NULL,
                          panel_74_response    = NULL,
                          panel_500_response   = NULL,
                          methylation_response = NULL,
                          clinical             = NULL,
                          vendor               = "guardant_health",
                          technology           = "infinity",
                          qc_filter            = TRUE,
                          verbose              = TRUE) {
  platform <- paste(vendor, technology, sep = "_")
  spec <- .platforms[[platform]]
  if (is.null(spec))
    stop(sprintf("Platform '%s' is not registered. Available: %s",
                 platform, paste(names(.platforms), collapse = ", ")))

  if (verbose)
    message("Preparing ctDNA data for platform: ", spec$name)

  res <- spec$prepare(
    infinity_report      = infinity_report,
    tf_change            = tf_change,
    panel_74_response    = panel_74_response,
    panel_500_response   = panel_500_response,
    methylation_response = methylation_response,
    clinical             = clinical,
    qc_filter            = qc_filter,
    verbose              = verbose
  )
  attr(res, "platform") <- platform
  res
}

#' List ctDNA platforms supported by `ctdna_prepare()`
#'
#' @return A data frame with `platform` (the vendor_technology key) and
#'   `name` (human-readable label) columns.
#' @export
ctdna_platforms <- function() {
  if (length(.platforms) == 0)
    return(data.frame(platform = character(), name = character(),
                      stringsAsFactors = FALSE))
  data.frame(
    platform = names(.platforms),
    name     = vapply(.platforms, `[[`, character(1), "name"),
    stringsAsFactors = FALSE
  )
}
