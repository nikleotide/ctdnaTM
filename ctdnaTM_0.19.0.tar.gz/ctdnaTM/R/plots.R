# ============================================================================
# ctdnaTM — deliverable plots (D1-D8)
# ============================================================================
# Every plot accepts:
#   stat        choice of statistical test (see each function's docs)
#   title, subtitle, caption, xlab, ylab
#   show_stats  print test results in subtitle (default TRUE)
#   show_n      annotate group sizes (default TRUE)
#   point_size, point_alpha
# Defaults match the pipeline conventions doc.

# ---- D1: Baseline characteristics -------------------------------------------

#' D1: Baseline characteristics — imbalance check across a grouping variable
#'
#' Faceted boxplots of baseline ctDNA-related variables across a stratifying
#' factor (dose, cohort, subpopulation). Runs a per-variable group-difference
#' test and annotates the p-value in each facet.
#'
#' @section Recommended statistic:
#' Use `"auto"` (default): Kruskal-Wallis when >2 groups, Wilcoxon rank-sum
#' for 2 groups. Use `"anova"`/`"t"` only if the variable is approximately
#' normal — uncommon for ctDNA metrics, which are typically log-distributed.
#'
#' @param df Baseline data (one row per subject).
#' @param group Stratifying column. Default: `ctdna_opts("dose")`.
#' @param vars Variables to plot. Default: the canonical ctDNA variables.
#' @param recist_shape Optional column to encode RECIST via point shape.
#' @param stat One of `"auto"` (default), `"kruskal"`, `"wilcox"`, `"anova"`,
#'   `"t"`, `"none"`. Recommended: `"auto"`.
#' @param show_stats,show_n Toggle stats subtitle and n labels.
#' @param title,subtitle,caption,xlab,ylab Plot labels.
#' @param point_size,point_alpha Display.
#' @return A ggplot object.
#' @export
ctdna_plot_baseline <- function(df,
                          group = .o("dose"),
                          vars = c(.o("tf"), .o("maxaf"), .o("cfdna_conc"),
                                   .o("n_somatic"), .o("tmb")),
                          recist_shape = NULL,
                          scheme = c("four","three","two"),
                          stat = c("auto","kruskal","wilcox","anova","t","none"),
                          show_stats = .o("show_stats"),
                          show_n = .o("show_n"),
                          title = "Baseline characteristics",
                          subtitle = NULL,
                          caption = sprintf("Floor=%g; log y-scale", .o("display_floor")),
                          xlab = NULL, ylab = "Value (log)",
                          point_size = .o("point_size"),
                          point_alpha = .o("point_alpha"),
    stat_position = .o("stat_position"),
    legend_position = .o("legend_position")) {
  stat <- match.arg(stat)
  scheme <- match.arg(scheme)
  vars <- intersect(vars, names(df))
  if (length(vars) == 0)
    stop("None of the requested `vars` are columns of `df`. ",
         "Got vars=(", paste(names(formals())$vars, collapse=","),
         "); df has columns: ", paste(names(df), collapse = ", "))

  # If the user is grouping by RECIST, apply the chosen scheme so that
  # boxes, colors, AND the statistical groups are all in the same strata.
  recist_col <- .o("recist")
  if (identical(group, recist_col) || identical(group, "RECIST")) {
    df[[group]] <- ctdna_stratify_recist(df[[group]], scheme)
  }

  cols <- c(group, vars, if (!is.null(recist_shape)) recist_shape)
  long <- tidyr::pivot_longer(df[, cols, drop = FALSE],
                              cols = tidyr::all_of(vars),
                              names_to = "variable", values_to = "value")
  long <- long[!is.na(long$value), ]
  long[[group]] <- factor(long[[group]])

  if (show_stats && stat != "none") {
    pv <- do.call(rbind, lapply(split(long, long$variable), function(s) {
      r <- ctdna_run_group_test(s, "value", group, method = stat)
      data.frame(variable = unique(s$variable),
                 label = sprintf("%s: %s", r$name, ctdna_pval_label(r$p)),
                 stringsAsFactors = FALSE)
    }))
  }

  long[[group]] <- factor(long[[group]])
  p <- ggplot2::ggplot(long, ggplot2::aes(.data[[group]], .data$value,
                                          color = .data[[group]],
                                          fill  = .data[[group]])) +
    ggplot2::geom_boxplot(outlier.shape = NA, alpha = 0.3,
                          linewidth = 0.7, fatten = 2.2, width = 0.6)

  if (!is.null(recist_shape) && recist_shape %in% names(long)) {
    long$.r <- ctdna_stratify_recist(long[[recist_shape]], scheme)
    p <- p + ggplot2::geom_jitter(data = long,
                                  ggplot2::aes(shape = .data$.r),
                                  width = 0.15, size = point_size,
                                  alpha = point_alpha,
                                  color = "grey20", inherit.aes = TRUE) +
      ggplot2::scale_shape_manual(values = c("CR/PR" = 16, "uCR/PR" = 17,
                                             "SD" = 15, "PD/NE/NA" = 18,
                                             "R" = 16, "NR" = 15,
                                             "SD/PD/NE/NA" = 15),
                                  na.value = 4)
  } else {
    p <- p + ggplot2::geom_jitter(width = 0.15, size = point_size,
                                  alpha = point_alpha,
                                  shape = 21, stroke = 0.3, color = "grey20")
  }

  recist_col <- .o("recist")
  group_is_recist <- identical(group, recist_col) || identical(group, "RECIST")
  scale_fn <- if (group_is_recist) ctdna_scale_recist else ctdna_scale_dose

  p <- p + ggplot2::facet_wrap(~ variable, scales = "free_y") +
    ggplot2::scale_y_log10() +
    scale_fn(aesthetics = c("color", "fill")) +
    ggplot2::labs(x = group, color = group, fill = group, shape = "RECIST") +
    ctdna_theme() +
    NULL  # legend_position handled by .finalize

  if (show_stats && stat != "none") {
    p <- p + ggplot2::geom_text(data = pv,
                                ggplot2::aes(x = -Inf, y = Inf,
                                             label = .data$label),
                                hjust = -0.05, vjust = 1.4,
                                size = 3, color = "grey20",
                                inherit.aes = FALSE)
  }
  if (show_n) {
    counts <- as.data.frame(table(long[[group]]))
    names(counts) <- c("g", "n")
    counts$label <- paste0("n=", counts$n)
    # Place n-labels just under each x-axis tick using grid::textGrob in
    # NPC coordinates, which sits outside the y-axis scale (log or linear)
    # and never overlaps data.
    p <- p +
      ggplot2::theme(
        plot.margin = ggplot2::margin(8, 8, 22, 8),
        axis.text.x = ggplot2::element_text(margin = ggplot2::margin(t = 12))
      )
    # Use a layer scale that puts text outside the panel via vjust on
    # axis labels: append the n to each x-axis label.
    new_labels <- setNames(
      paste0(as.character(counts$g), "\n(n=", counts$n, ")"),
      as.character(counts$g))
    p <- p + ggplot2::scale_x_discrete(labels = new_labels)
  }
  .finalize(p, title, subtitle, caption, xlab, ylab, legend_position = legend_position)
}


# ---- D2: Baseline methylTF by dose & RECIST ---------------------------------

#' D2: Baseline methylTF by dose and RECIST
#'
#' Boxplot of baseline methylTF grouped by dose and colored by RECIST.
#' Computes pairwise tests within each dose across RECIST strata.
#'
#' @section Recommended statistic:
#' `"wilcox"` (default): Wilcoxon rank-sum for two-group RECIST pairs.
#' Switch to `"t"` only if values are approximately normal on the log
#' scale.
#'
#' @param df Baseline data.
#' @param scheme RECIST stratification.
#' @param stat One of `"wilcox"` (default), `"t"`, `"none"`. Recommended: `"wilcox"`.
#' @param show_stats,show_n Toggles.
#' @param title,subtitle,caption,xlab,ylab Labels.
#' @param point_size,point_alpha Display.
#' @export
ctdna_plot_baseline_dose_recist <- function(df,
                                      scheme = c("two","three","four"),
                                      stat = c("wilcox","t","none"),
                                      show_stats = .o("show_stats"),
                                      show_n = .o("show_n"),
                                      title = "Baseline methylTF by dose and RECIST",
                                      subtitle = NULL,
                                      caption = sprintf("Floor=%g; log y", .o("display_floor")),
                                      xlab = NULL,
                                      ylab = "methylTF (log)",
                                      point_size = .o("point_size"),
                                      point_alpha = .o("point_alpha"),
    stat_position = .o("stat_position"),
    legend_position = .o("legend_position")) {
  .stats_label <- NULL

  scheme <- match.arg(scheme); stat <- match.arg(stat)
  df$.r <- ctdna_stratify_recist(df[[.o("recist")]], scheme)
  df$.tf <- ctdna_floor_tf(df[[.o("tf")]])
  df[[.o("dose")]] <- factor(df[[.o("dose")]])

  if (show_stats && stat != "none") {
    pw <- do.call(rbind, lapply(split(df, df[[.o("dose")]]), function(s) {
      r <- ctdna_pairwise_ranksum(s, ".tf", ".r", method = stat)
      if (is.null(r)) return(NULL)
      r$dose <- unique(s[[.o("dose")]]); r
    }))
    sub_extra <- if (!is.null(pw))
      sprintf("Pairwise (%s) within dose — %s",
              if (stat == "wilcox") "Wilcoxon" else "t-test",
              .pairwise_str(pw)) else NULL
  }

  p <- ggplot2::ggplot(df, ggplot2::aes(.data[[.o("dose")]], .data$.tf,
                                        color = .data$.r, fill = .data$.r)) +
    ggplot2::geom_boxplot(outlier.shape = NA, alpha = 0.3,
                          linewidth = 0.7, fatten = 2.2,
                          position = ggplot2::position_dodge(0.8)) +
    ggplot2::geom_point(position = ggplot2::position_jitterdodge(
      jitter.width = 0.15, dodge.width = 0.8),
      size = point_size, alpha = point_alpha,
      shape = 21, stroke = 0.3, color = "grey20") +
    ctdna_scale_recist(aesthetics = c("color", "fill")) + .log_clearance() +
    ggplot2::labs(x = .o("dose"), color = "RECIST", fill = "RECIST") +
    ctdna_theme()

  if (show_n) {
    counts <- as.data.frame(table(df[[.o("dose")]]))
    names(counts) <- c("g", "n"); counts$label <- paste0("n=", counts$n)
    new_labels <- setNames(
      paste0(as.character(counts$g), "\n(n=", counts$n, ")"),
      as.character(counts$g))
    p <- p +
      ggplot2::scale_x_discrete(labels = new_labels) +
      ggplot2::theme(
        plot.margin = ggplot2::margin(8, 8, 18, 8),
        axis.text.x = ggplot2::element_text(margin = ggplot2::margin(t = 6))
      )
  }
  if (show_stats && exists("sub_extra") && !is.null(sub_extra) )
    .stats_label <- sub_extra
    # Route stats label per stat_position option
  if (!is.null(.stats_label)) {
    .routed <- .route_stats(.stats_label, stat_position, subtitle, caption)
    subtitle <- .routed$subtitle; caption <- .routed$caption
  
    on_plot_label <- .routed$on_plot
  } else on_plot_label <- NULL
  # (on_plot_label annotated below after .finalize)
  .annotate_stat(.finalize(p, title, subtitle, caption, xlab, ylab, legend_position = legend_position), on_plot_label)
}


# ---- D3: Reduction distribution ---------------------------------------------

#' D3: ctDNA reduction distribution across dose and RECIST
#'
#' Boxplot of on-treatment / baseline methylTF ratio, faceted by dose and
#' colored by RECIST. LOQ exclusion applied.
#'
#' @section Recommended statistic:
#' `"wilcox"` (default): Wilcoxon rank-sum within each dose. Reduction
#' ratios are heavily skewed even on log scale, so non-parametric is
#' the right call.
#'
#' @inheritParams ctdna_plot_baseline_dose_recist
#' @export
ctdna_plot_reduction <- function(df,
                           scheme = c("two","three","four"),
                           at     = "best",
                           metric = c("ratio","tf","pct_change"),
                           mr_threshold = 0.5,
                           stat = c("wilcox","t","none"),
                           show_stats = .o("show_stats"),
                           show_n = .o("show_n"),
                           title = "ctDNA reduction by dose and RECIST",
                           subtitle = NULL,
                           caption = NULL,
                           xlab = NULL,
                           ylab = NULL,
                           point_size = .o("point_size"),
                           point_alpha = .o("point_alpha"),
    stat_position = .o("stat_position"),
    legend_position = .o("legend_position")) {
  .stats_label <- NULL

  scheme <- match.arg(scheme); stat <- match.arg(stat)
  metric <- match.arg(metric)

  # Compute the per-subject value with the requested metric and time-point
  ma <- ctdna_metric_at(df, metric = metric, at = at)
  # Join the per-subject RECIST and dose
  meta_cols <- intersect(c(.o("recist"), .o("dose")), names(df))
  meta <- unique(df[, c(.o("subject"), meta_cols), drop = FALSE])
  d <- merge(ma, meta, by = .o("subject"), all.x = TRUE)

  d$.r <- ctdna_stratify_recist(d[[.o("recist")]], scheme)
  d[[.o("dose")]] <- factor(d[[.o("dose")]])

  # Decide y-axis & log scaling based on metric
  use_log <- metric %in% c("ratio","tf")
  if (use_log) {
    d$.y <- ctdna_floor_tf(d$value)
  } else {
    d$.y <- d$value          # pct_change can be negative; linear scale
  }

  # MR classification (only meaningful for the ratio metric)
  if (metric == "ratio") {
    d$MR <- ifelse(is.na(d$value), NA_character_,
                    ifelse(d$value <= mr_threshold,
                           "Response", "NonResponse"))
  }

  # Default ylab / caption based on metric
  if (is.null(ylab)) ylab <- switch(metric,
    ratio      = sprintf("TF(%s) / TF(baseline) [log]",
                          if (identical(at, "best")) "best" else at),
    tf         = sprintf("TF at %s [log]",
                          if (identical(at, "best")) "best" else at),
    pct_change = sprintf("Percent change in TF at %s",
                          if (identical(at, "best")) "best" else at))
  if (is.null(caption)) caption <- switch(metric,
    ratio      = sprintf("metric = ratio at %s; floor=%g, log y; MR threshold = %g (ratio<=thr -> Response)",
                          if (identical(at, "best")) "best" else at,
                          .o("display_floor"), mr_threshold),
    tf         = sprintf("metric = TF at %s; floor=%g, log y",
                          if (identical(at, "best")) "best" else at,
                          .o("display_floor")),
    pct_change = sprintf("metric = pct_change at %s; negative = reduction",
                          if (identical(at, "best")) "best" else at))

  sub_extra <- NULL
  if (show_stats && stat != "none") {
    pw <- do.call(rbind, lapply(split(d, d[[.o("dose")]]), function(s) {
      r <- ctdna_pairwise_ranksum(s, ".y", ".r", method = stat)
      if (is.null(r)) return(NULL)
      r$dose <- unique(s[[.o("dose")]]); r
    }))
    if (!is.null(pw))
      sub_extra <- sprintf("Pairwise (%s) within dose, scheme=%s - %s",
                           if (stat == "wilcox") "Wilcoxon" else "t-test",
                           scheme, .pairwise_str(pw))
  }

  p <- ggplot2::ggplot(d, ggplot2::aes(.data[[.o("dose")]], .data$.y,
                                       color = .data$.r, fill = .data$.r)) +
    ggplot2::geom_boxplot(outlier.shape = NA, alpha = 0.3,
                          linewidth = 0.7, fatten = 2.2,
                          position = ggplot2::position_dodge(0.8)) +
    ggplot2::geom_point(position = ggplot2::position_jitterdodge(
      jitter.width = 0.15, dodge.width = 0.8),
      size = point_size, alpha = point_alpha,
      shape = 21, stroke = 0.3, color = "grey20") +
    ctdna_scale_recist(aesthetics = c("color", "fill")) +
    ggplot2::labs(x = .o("dose"), color = "RECIST", fill = "RECIST") +
    ctdna_theme()

  # Log scale + clearance line only for ratio / tf
  if (use_log) p <- p + .log_clearance()

  # Dashed line at the MR threshold so MR responders are visually
  # obvious. Label sits at the LEFT edge so it never overlaps boxplot
  # data on the right.
  if (metric == "ratio" && !is.null(mr_threshold) &&
      is.finite(mr_threshold) && mr_threshold > 0) {
    p <- p +
      ggplot2::geom_hline(yintercept = mr_threshold, linetype = "dashed",
                            color = "grey25", linewidth = 0.4) +
      ggplot2::annotate("text", x = -Inf, y = mr_threshold,
                         label = sprintf("MR threshold = %g", mr_threshold),
                         hjust = -0.05, vjust = -0.5,
                         size = 3, color = "grey25")
  }

  if (show_n) {
    counts <- as.data.frame(table(d[[.o("dose")]]))
    names(counts) <- c("g", "n"); counts$label <- paste0("n=", counts$n)
    new_labels <- setNames(
      paste0(as.character(counts$g), "\n(n=", counts$n, ")"),
      as.character(counts$g))
    p <- p +
      ggplot2::scale_x_discrete(labels = new_labels) +
      ggplot2::theme(
        plot.margin = ggplot2::margin(8, 8, 18, 8),
        axis.text.x = ggplot2::element_text(margin = ggplot2::margin(t = 6))
      )
  }
  if (show_stats && !is.null(sub_extra) )
    .stats_label <- sub_extra
    # Route stats label per stat_position option
  if (!is.null(.stats_label)) {
    .routed <- .route_stats(.stats_label, stat_position, subtitle, caption)
    subtitle <- .routed$subtitle; caption <- .routed$caption
  
    on_plot_label <- .routed$on_plot
  } else on_plot_label <- NULL
  # (on_plot_label annotated below after .finalize)
  .annotate_stat(.finalize(p, title, subtitle, caption, xlab, ylab, legend_position = legend_position), on_plot_label)
}


# ---- D4: MR-RECIST concordance ----------------------------------------------

#' D4: MR-RECIST concordance with kappa and agreement
#'
#' Heatmap of the MR x RECIST contingency table with diagonal-emphasis
#' coloring. Reports overall % agreement, Cohen's kappa, and (for 2x2)
#' McNemar's test.
#'
#' @section Recommended statistic:
#' `"both"` (default): shows agreement % and Cohen's kappa together.
#' Use `"mcnemar"` if you specifically want a marginal-homogeneity test
#' (only valid for 2x2 tables).
#'
#' @section Source of MR values:
#' By default MR is **recomputed from longitudinal ctDNA dynamics** via
#' [ctdna_compute_mr()] — taking the deepest on-treatment / baseline TF ratio
#' per subject and calling Response if that best ratio is at or below
#' `mr_threshold` (default 0.5).
#'
#' Set `mr_timepoint = "C5D1"` (or any other on-treatment label) to use
#' the MR call at that specific visit instead of the best.
#'
#' Set `mr_timepoint = "use_column"` to fall back to a pre-computed MR
#' column already present in `df` (the legacy behaviour) — useful when
#' the MR call was made upstream (e.g. by the vendor or by a separate
#' clinical script).
#'
#' @param df Longitudinal ctDNA data (subject × time × TF × RECIST).
#' @param scheme RECIST stratification.
#' @param mr_timepoint One of `"best"` (default — deepest ratio across
#'   visits), a specific on-treatment time-point label (e.g. `"C5D1"`),
#'   or `"use_column"` (use the MR column already on `df`).
#' @param mr_threshold Ratio (TF / baseline TF) at or below which a
#'   subject is called a molecular responder. Default 0.5.
#' @param stat One of `"both"` (default), `"kappa"`, `"agreement"`,
#'   `"mcnemar"`, `"none"`. Recommended: `"both"`.
#' @param show_stats,title,subtitle,caption,xlab,ylab Display options.
#' @return list(plot, table, agreement, kappa, mcnemar_p, mr_source).
#' @export
ctdna_plot_mr_recist <- function(df,
                           scheme = c("two","three","four"),
                           mr_timepoint = "best",
                           mr_threshold = 0.5,
                           stat = c("both","kappa","agreement","mcnemar","none"),
                           show_stats = .o("show_stats"),
                           title = "MR-RECIST concordance",
                           subtitle = NULL,
                           caption = NULL,
                           xlab = "RECIST",
                           ylab = "Molecular Response",
    stat_position = .o("stat_position"),
    legend_position = .o("legend_position")) {
  .stats_label <- NULL

  scheme <- match.arg(scheme); stat <- match.arg(stat)

  # Resolve MR values: compute fresh, or use the column already on df.
  if (identical(mr_timepoint, "use_column")) {
    if (!.o("mr") %in% names(df))
      stop("mr_timepoint='use_column' requested but column '", .o("mr"),
           "' not present in df.")
    per_subj <- unique(df[, c(.o("subject"), .o("mr"), .o("recist"))])
    mr_vals  <- per_subj[[.o("mr")]]
    rec_vals <- per_subj[[.o("recist")]]
    mr_source <- sprintf("MR taken from df$%s", .o("mr"))
  } else {
    mr_df <- ctdna_compute_mr(df, at = mr_timepoint, threshold = mr_threshold)
    rec_lookup <- unique(df[, c(.o("subject"), .o("recist"))])
    merged <- merge(mr_df, rec_lookup, by = .o("subject"))
    mr_vals  <- merged$MR
    rec_vals <- merged[[.o("recist")]]
    mr_source <- sprintf(
      "MR recomputed at %s; ratio threshold = %g",
      if (identical(mr_timepoint, "best")) "best on-treatment visit"
      else paste0("visit ", mr_timepoint),
      mr_threshold)
  }

  if (is.null(caption)) caption <- mr_source

  r <- ctdna_stratify_recist(rec_vals, scheme)
  m <- factor(mr_vals)
  tab <- table(MR = m, RECIST = r)
  ct <- ctdna_concordance_test(tab, method = stat)

  if (show_stats && stat != "none" ) {
    parts <- c()
    if (stat %in% c("both","agreement"))
      parts <- c(parts, sprintf("Agreement = %.0f%%",
                                100 * ct$agreement))
    if (stat %in% c("both","kappa"))
      parts <- c(parts, sprintf("kappa = %.2f", ct$kappa))
    if (stat == "mcnemar" && !is.na(ct$mcnemar_p))
      parts <- c(parts, sprintf("McNemar %s", ctdna_pval_label(ct$mcnemar_p)))
    parts <- c(parts, sprintf("N = %d", ct$n))
    .stats_label <- paste(parts, collapse = "  |  ")
  }

  long <- as.data.frame(tab)
  p <- ggplot2::ggplot(long, ggplot2::aes(.data$RECIST, .data$MR,
                                          fill = .data$Freq)) +
    ggplot2::geom_tile(color = "white") +
    ggplot2::geom_text(ggplot2::aes(label = .data$Freq)) +
    ggplot2::scale_fill_gradient(low = "white", high = "#3182BD") +
    ctdna_theme()
  # Route stats label per stat_position option
  if (!is.null(.stats_label)) {
    .routed <- .route_stats(.stats_label, stat_position, subtitle, caption)
    subtitle <- .routed$subtitle; caption <- .routed$caption

    on_plot_label <- .routed$on_plot
  } else on_plot_label <- NULL
  # (on_plot_label annotated below after .finalize)
  p <- .annotate_stat(.finalize(p, title, subtitle, caption, xlab, ylab, legend_position = legend_position), on_plot_label)

  # Publication-style table panel for the same contingency
  tbl_caption <- paste(
    "Agreement = % of patients whose MR class matches their RECIST class on the diagonal.",
    if (!is.null(mr_source)) mr_source else "",
    sep = "  ")
  table_plot <- ctdna_table(
    as.data.frame.matrix(tab),
    title    = if (is.null(title)) NULL else paste(title, "(table)"),
    subtitle = sprintf("Agreement %.0f%% | Cohen's kappa = %.2f | N = %d",
                       100 * ct$agreement, ct$kappa, ct$n),
    caption  = tbl_caption,
    highlight_diag = TRUE)

  list(plot = p, table = tab, table_plot = table_plot,
       agreement = ct$agreement,
       kappa = ct$kappa, mcnemar_p = ct$mcnemar_p,
       mr_source = mr_source)
}


# ---- D5: Longitudinal by dose -----------------------------------------------

#' D5: Longitudinal ctDNA reduction by dose (RECIST aggregated)
#'
#' Per-subject spaghetti + thick median per dose. Computes a paired test
#' between baseline and each on-treatment time point, per dose.
#'
#' @section Recommended statistic:
#' `"paired_wilcox"` (default): paired Wilcoxon — appropriate because
#' the same subject is observed at baseline and each on-treatment time
#' point. Switch to `"paired_t"` only if log-ratios appear normal.
#'
#' @param df Longitudinal data.
#' @param stat One of `"paired_wilcox"` (default), `"paired_t"`,
#'   `"wilcox"`, `"t"`, `"none"`. Recommended: `"paired_wilcox"`.
#' @param show_stats,show_n,title,subtitle,caption,xlab,ylab Display options.
#' @param point_size,point_alpha Display.
#' @export
ctdna_plot_longitudinal <- function(df,
                              stat = c("paired_wilcox","paired_t","wilcox","t","none"),
                              recist_color = FALSE,
                              scheme = c("two","three","four"),
                              show_stats = .o("show_stats"),
                              show_n = .o("show_n"),
                              title = "Longitudinal ctDNA reduction by dose",
                              subtitle = "Thick line = median",
                              caption = sprintf("Floor=%g; LOQ=%g; baseline vs each timepoint per dose",
                                                .o("display_floor"), .o("loq")),
                              xlab = "Time point",
                              ylab = "Reduction ratio (log)",
                              point_size = .o("point_size"),
                              point_alpha = .o("point_alpha"),
    stat_position = .o("stat_position"),
    legend_position = .o("legend_position")) {
  stat <- match.arg(stat)
  scheme <- match.arg(scheme)
  d <- ctdna_ratio(df)
  d$.ratio <- ctdna_floor_tf(d$ratio)
  d[[.o("dose")]] <- factor(d[[.o("dose")]])
  d[[.o("time")]] <- factor(d[[.o("time")]])
  if (recist_color && .o("recist") %in% names(d)) {
    d$.r <- ctdna_stratify_recist(d[[.o("recist")]], scheme)
  }
  med <- stats::aggregate(.ratio ~ get(.o("dose")) + get(.o("time")),
                          data = d, FUN = stats::median)
  names(med) <- c(.o("dose"), .o("time"), ".m")

  pw <- NULL
  if (show_stats && stat != "none") {
    bl_lbl <- .o("baseline"); rows <- list()
    for (ds in levels(d[[.o("dose")]])) {
      sub <- d[d[[.o("dose")]] == ds, ]
      # subject-aligned: take only subjects with both BL and the timepoint
      bl_df <- sub[sub[[.o("time")]] == bl_lbl, c(.o("subject"), ".ratio")]
      names(bl_df)[2] <- ".bl"
      for (tp in setdiff(levels(d[[.o("time")]]), bl_lbl)) {
        ot_df <- sub[sub[[.o("time")]] == tp, c(.o("subject"), ".ratio")]
        names(ot_df)[2] <- ".ot"
        joined <- merge(bl_df, ot_df, by = .o("subject"))
        if (nrow(joined) < 2) next
        r <- ctdna_paired_test(joined$.bl, joined$.ot, method = stat)
        rows[[length(rows) + 1]] <- data.frame(
          dose = ds, time = tp, label = ctdna_pval_label(r$p),
          stringsAsFactors = FALSE)
      }
    }
    pw <- if (length(rows)) do.call(rbind, rows) else NULL
    if (!is.null(pw)) names(pw) <- c(.o("dose"), .o("time"), "label")
  }

  p <- if (recist_color && ".r" %in% names(d)) {
    ggplot2::ggplot(d, ggplot2::aes(.data[[.o("time")]], .data$.ratio,
                                     group = .data[[.o("subject")]],
                                     color = .data$.r)) +
      ggplot2::geom_line(alpha = 0.45) +
      ggplot2::geom_line(data = med,
                          ggplot2::aes(.data[[.o("time")]], .data$.m,
                                       group = .data[[.o("dose")]]),
                          color = .o("median_color"), linewidth = 1.5,
                          inherit.aes = FALSE) +
      ctdna_scale_recist() +
      ggplot2::labs(color = "RECIST")
  } else {
    ggplot2::ggplot(d, ggplot2::aes(.data[[.o("time")]], .data$.ratio,
                                     group = .data[[.o("subject")]])) +
      ggplot2::geom_line(alpha = 0.25, color = "grey50") +
      ggplot2::geom_line(data = med,
                          ggplot2::aes(.data[[.o("time")]], .data$.m,
                                       group = .data[[.o("dose")]]),
                          color = .o("median_color"), linewidth = 1.5,
                          inherit.aes = FALSE)
  }
  p <- p +
    ggplot2::facet_wrap(stats::as.formula(paste("~", .o("dose")))) +
    .log_clearance() + ctdna_theme() +
    ggplot2::theme(
      axis.text.x = ggplot2::element_text(angle = 30, vjust = 1, hjust = 1,
                                            size = 7))

  if (show_stats && !is.null(pw)) {
    p <- p + ggplot2::geom_text(data = pw,
                                ggplot2::aes(x = .data[[.o("time")]], y = -Inf,
                                             label = .data$label),
                                vjust = -1.5, size = 2.7,
                                color = "grey20",
                                inherit.aes = FALSE)
  }
  if (show_n) {
    counts <- stats::aggregate(get(.o("subject")) ~ get(.o("dose")) +
                                 get(.o("time")), data = d,
                               FUN = function(x) length(unique(x)))
    names(counts) <- c(.o("dose"), .o("time"), "n")
    counts$label <- paste0("n=", counts$n)
    p <- p + ggplot2::geom_text(data = counts,
                                ggplot2::aes(x = .data[[.o("time")]], y = Inf,
                                             label = .data$label),
                                vjust = 1.2, size = 2.7, color = "grey50",
                                inherit.aes = FALSE)
  }
  .finalize(p, title, subtitle, caption, xlab, ylab, legend_position = legend_position)
}


# ---- D6: Longitudinal by dose AND RECIST ------------------------------------

#' D6: Longitudinal ctDNA reduction by dose AND RECIST
#'
#' Subject-level lines faceted by both dose (columns) and RECIST (rows).
#' Reports a per-RECIST overall dose-effect test in the subtitle.
#'
#' @section Recommended statistic:
#' `"kruskal"` (default): non-parametric test of dose effect within each
#' RECIST stratum. Use `"wilcox"` if dose has exactly two levels;
#' `"anova"` only if log-ratios are approximately normal.
#'
#' @param df Longitudinal data.
#' @param scheme RECIST stratification.
#' @param stat One of `"kruskal"` (default), `"wilcox"`, `"anova"`, `"none"`.
#'   Recommended: `"kruskal"`.
#' @param show_stats,show_n,title,subtitle,caption,xlab,ylab,point_size,point_alpha
#'   Display.
#' @export
ctdna_plot_longitudinal_recist <- function(df,
                                     scheme = c("two","three","four"),
                                     stat = c("kruskal","wilcox","anova","none"),
                                     show_stats = .o("show_stats"),
                                     show_n = .o("show_n"),
                                     title = "ctDNA reduction by dose x RECIST",
                                     subtitle = NULL,
                                     caption = sprintf("Floor=%g; LOQ=%g",
                                                       .o("display_floor"), .o("loq")),
                                     xlab = "Time point",
                                     ylab = "Reduction ratio (log)",
                                     point_size = .o("point_size"),
                                     point_alpha = .o("point_alpha"),
    stat_position = .o("stat_position"),
    legend_position = .o("legend_position")) {
  .stats_label <- NULL

  scheme <- match.arg(scheme); stat <- match.arg(stat)
  d <- ctdna_ratio(df)
  d$.ratio <- ctdna_floor_tf(d$ratio)
  d$.r <- ctdna_stratify_recist(d[[.o("recist")]], scheme)
  d[[.o("dose")]] <- factor(d[[.o("dose")]])
  d[[.o("time")]] <- factor(d[[.o("time")]])

  if (show_stats && stat != "none" ) {
    parts <- lapply(split(d, d$.r), function(s) {
      r <- ctdna_run_group_test(s, ".ratio", .o("dose"), method = stat)
      # Abbreviate test names (KW = Kruskal-Wallis, WX = Wilcoxon)
      tname <- switch(r$name,
                      "Kruskal-Wallis" = "KW",
                      "Wilcoxon"       = "WX",
                      "ANOVA"          = "ANOVA",
                      "t-test"         = "t",
                      r$name)
      sprintf("%s: %s %s", unique(s$.r), tname, ctdna_pval_label(r$p))
    })
    .stats_label <- paste(unlist(parts), collapse = " | ")
  }

  ggplot2::ggplot(d, ggplot2::aes(.data[[.o("time")]], .data$.ratio,
                                  group = .data[[.o("subject")]],
                                  color = .data$.r)) +
    ggplot2::geom_line(alpha = 0.45) +
    ggplot2::geom_point(size = point_size, alpha = point_alpha) +
    ggplot2::facet_grid(stats::as.formula(paste(".r ~", .o("dose")))) +
    ctdna_scale_recist() + .log_clearance() + ctdna_theme() +
    ggplot2::labs(color = "RECIST", x = "Time point",
                   y = "Reduction ratio (log)") +
    ggplot2::theme(
      axis.text.x = ggplot2::element_text(angle = 30, vjust = 1, hjust = 1,
                                            size = 7)) -> p
    # Route stats label per stat_position option
  if (!is.null(.stats_label)) {
    .routed <- .route_stats(.stats_label, stat_position, subtitle, caption)
    subtitle <- .routed$subtitle; caption <- .routed$caption
  
    on_plot_label <- .routed$on_plot
  } else on_plot_label <- NULL
  if (is.null(caption))
    caption <- sprintf("Dotted line = display floor (%g)", .o("display_floor"))
  # (on_plot_label annotated below after .finalize)
  .annotate_stat(.finalize(p, title, subtitle, caption, xlab, ylab, legend_position = legend_position), on_plot_label)
}


# ---- D7: Best reduction vs best % tumor change ------------------------------

#' D7: Best ctDNA reduction vs best % change in target lesions
#'
#' Scatter of per-subject best log-scale reduction ratio (x) vs the best
#' % change in sum of target lesions (y), with the -30% RECIST threshold.
#'
#' @section Recommended statistic:
#' `"spearman"` (default): preferred because ratios at clearance produce
#' many ties; Spearman handles ties robustly. Use `"pearson"` only if
#' both axes are approximately linear-Gaussian. `"kendall"` is an
#' alternative rank-based option.
#'
#' @param df Longitudinal data.
#' @param scheme RECIST stratification (used for shape encoding).
#' @param stat One of `"spearman"` (default), `"pearson"`, `"kendall"`,
#'   `"none"`. Recommended: `"spearman"`.
#' @param show_stats,title,subtitle,caption,xlab,ylab,point_size,point_alpha
#'   Display.
#' @export
ctdna_plot_reduction_vs_tumor <- function(df,
                                    scheme = c("two","three","four"),
                                    stat = c("spearman","pearson","kendall","none"),
                                    show_stats = .o("show_stats"),
                                    title = "ctDNA reduction vs best % tumor change",
                                    subtitle = NULL,
                                    caption = "Red dashed = -30% (RECIST PR threshold)",
                                    xlab = "Best reduction ratio (log)",
                                    ylab = "Best % change in target lesions",
                                    point_size = .o("point_size") + 1,
                                    point_alpha = .o("point_alpha"),
    stat_position = .o("stat_position"),
    legend_position = .o("legend_position")) {
  .stats_label <- NULL

  scheme <- match.arg(scheme); stat <- match.arg(stat)
  d <- ctdna_summary(df)
  d$.ratio <- ctdna_floor_tf(d$best_ratio)
  d$.r <- ctdna_stratify_recist(d[[.o("recist")]], scheme)
  d[[.o("dose")]] <- factor(d[[.o("dose")]])
  if (show_stats && stat != "none" ) {
    ct <- ctdna_cor_test(d$.ratio, d[[.o("best_change")]], method = stat)
    .stats_label <- sprintf("%s rho = %.2f, %s, n = %d",
                        ct$name, ct$rho, ctdna_pval_label(ct$p), ct$n)
  }

  ggplot2::ggplot(d, ggplot2::aes(.data$.ratio,
                                  .data[[.o("best_change")]],
                                  color = .data$.r,
                                  shape = .data[[.o("dose")]])) +
    ggplot2::geom_hline(yintercept = -30, color = "red", linetype = "dashed") +
    ggplot2::geom_vline(xintercept = .o("display_floor"), color = .o("clearance_color"),
                        linetype = "dotted") +
    ggplot2::geom_point(size = point_size, alpha = point_alpha) +
    ggplot2::scale_x_log10() +
    ctdna_scale_recist() +
    ctdna_scale_dose_shape() +
    ggplot2::labs(color = "RECIST", shape = .o("dose")) +
    ctdna_theme() -> p
    # Route stats label per stat_position option
  if (!is.null(.stats_label)) {
    .routed <- .route_stats(.stats_label, stat_position, subtitle, caption)
    subtitle <- .routed$subtitle; caption <- .routed$caption
  
    on_plot_label <- .routed$on_plot
  } else on_plot_label <- NULL
  # (on_plot_label annotated below after .finalize)
  .annotate_stat(.finalize(p, title, subtitle, caption, xlab, ylab, legend_position = legend_position), on_plot_label)
}


# ---- D8 supplemental: maxAF vs methylTF -------------------------------------

#' D8: maxAF vs methylTF concordance
#'
#' Log-log scatter with identity line. Flags points beyond a configurable
#' log10 distance (default >1, i.e. >10-fold) as discordant.
#'
#' @section Recommended statistic:
#' `"spearman"` (default): robust to ties caused by flooring.
#' `"pearson"` works if both axes are normal on the log scale.
#'
#' @param df Data with maxAF and methylTF.
#' @param stat One of `"spearman"` (default), `"pearson"`, `"kendall"`,
#'   `"none"`. Recommended: `"spearman"`.
#' @param show_stats,title,subtitle,caption,xlab,ylab,point_size,point_alpha
#'   Display.
#' @export
ctdna_plot_mut_methyl <- function(df,
                            stat = c("spearman","pearson","kendall","none"),
                            recist_shape = FALSE,
                            scheme = c("two","three","four"),
                            show_stats = .o("show_stats"),
                            title = "maxAF vs methylTF concordance",
                            subtitle = NULL,
                            caption = sprintf("Discordant if log10 distance > %g",
                                              .o("discord_log10")),
                            xlab = "maxAF (log)",
                            ylab = "methylTF (log)",
                            point_size = .o("point_size"),
                            point_alpha = .o("point_alpha"),
    stat_position = .o("stat_position"),
    legend_position = .o("legend_position")) {
  .stats_label <- NULL

  stat <- match.arg(stat)
  scheme <- match.arg(scheme)
  d <- data.frame(maxaf = ctdna_floor_tf(df[[.o("maxaf")]]),
                  tf    = ctdna_floor_tf(df[[.o("tf")]]))
  d$.disc <- abs(log10(d$maxaf) - log10(d$tf)) > .o("discord_log10")
  if (recist_shape && .o("recist") %in% names(df)) {
    d$.r <- ctdna_stratify_recist(df[[.o("recist")]], scheme)
  }
  n_disc <- sum(d$.disc, na.rm = TRUE)
  if (show_stats && stat != "none" ) {
    ct <- ctdna_cor_test(d$maxaf, d$tf, method = stat)
    .stats_label <- sprintf("%s rho = %.2f, %s, n = %d; %d discordant",
                        ct$name, ct$rho, ctdna_pval_label(ct$p), ct$n, n_disc)
  }
  p <- if (recist_shape && ".r" %in% names(d)) {
    ggplot2::ggplot(d, ggplot2::aes(.data$maxaf, .data$tf,
                                     color = .data$.disc,
                                     shape = .data$.r)) +
      ggplot2::geom_abline(slope = 1, color = "grey50", linetype = "dashed") +
      ggplot2::geom_point(size = point_size + 0.5, alpha = point_alpha) +
      ggplot2::scale_color_manual(values = c(`FALSE` = "grey20",
                                              `TRUE` = "#E31A1C"),
                                   labels = c("concordant", "discordant"),
                                   name = NULL) +
      ggplot2::scale_shape_manual(values = c("CR/PR" = 16, "uCR/PR" = 17,
                                              "SD" = 15, "PD/NE/NA" = 18,
                                              "R" = 16, "NR" = 15,
                                              "SD/PD/NE/NA" = 15),
                                   na.value = 4, name = "RECIST")
  } else {
    ggplot2::ggplot(d, ggplot2::aes(.data$maxaf, .data$tf,
                                     color = .data$.disc)) +
      ggplot2::geom_abline(slope = 1, color = "grey50", linetype = "dashed") +
      ggplot2::geom_point(size = point_size, alpha = point_alpha) +
      ggplot2::scale_color_manual(values = c(`FALSE` = "grey20",
                                              `TRUE` = "#E31A1C"),
                                   labels = c("concordant", "discordant"),
                                   name = NULL)
  }
  p <- p + ggplot2::scale_x_log10() + ggplot2::scale_y_log10() + ctdna_theme()
    # Route stats label per stat_position option
  if (!is.null(.stats_label)) {
    .routed <- .route_stats(.stats_label, stat_position, subtitle, caption)
    subtitle <- .routed$subtitle; caption <- .routed$caption
  
    on_plot_label <- .routed$on_plot
  } else on_plot_label <- NULL
  # (on_plot_label annotated below after .finalize)
  .annotate_stat(.finalize(p, title, subtitle, caption, xlab, ylab, legend_position = legend_position), on_plot_label)
}
