# ============================================================================
# ctdnaTM — statistics helpers
# ============================================================================
# Each plotting function exposes a `stat` parameter that selects the test.
# This file provides the test catalog and small executors.

#' Format p-values for plot annotations
#'
#' Vectorized: accepts a scalar or numeric vector.
#'
#' @param p Numeric p-value(s).
#' @return Character vector of the same length, with entries like
#'   \code{"p=0.012"}, \code{"p<0.001"}, or \code{"p=NA"}.
#' @export
ctdna_pval_label <- function(p) {
  vapply(p, function(x) {
    if (is.na(x)) return("p=NA")
    if (x < 0.001) return("p<0.001")
    sprintf("p=%.3f", x)
  }, character(1))
}

# ---- catalogs ---------------------------------------------------------------
# Allowed `stat` values for group / correlation / concordance / paired plots.
.STAT_GROUP    <- c("auto","wilcox","t","kruskal","anova","none")
.STAT_TWO      <- c("wilcox","t","none")
.STAT_MULTI    <- c("kruskal","anova","wilcox","none")
.STAT_COR      <- c("spearman","pearson","kendall","none")
.STAT_PAIRED   <- c("paired_wilcox","paired_t","wilcox","t","none")
.STAT_CONCORD  <- c("both","kappa","agreement","mcnemar","none")


# ---- two-group + multi-group ------------------------------------------------

#' Run a single group-comparison test
#'
#' Used inside plot functions. `method = "auto"` selects Kruskal-Wallis
#' for >2 groups and Wilcoxon rank-sum for 2 groups.
#'
#' @param data Data frame.
#' @param value Numeric column name.
#' @param group Grouping column name.
#' @param method One of `"auto","wilcox","t","kruskal","anova","none"`.
#' @return list(method, name, p, n).
#' @export
ctdna_run_group_test <- function(data, value, group, method = "auto") {
  g <- data[[group]]; v <- data[[value]]
  groups <- unique(stats::na.omit(g))
  k <- length(groups); n <- sum(!is.na(v) & !is.na(g))
  if (method == "none" || k < 2)
    return(list(method = "none", name = "none", p = NA_real_, n = n))
  if (method == "auto") method <- if (k > 2) "kruskal" else "wilcox"
  p <- tryCatch({
    switch(method,
      wilcox  = stats::wilcox.test(v ~ g, exact = FALSE)$p.value,
      t       = stats::t.test(v ~ g)$p.value,
      kruskal = stats::kruskal.test(v ~ g)$p.value,
      anova   = stats::anova(stats::lm(v ~ g))$`Pr(>F)`[1])
  }, error = function(e) NA_real_)
  name <- switch(method,
    wilcox = "Wilcoxon", t = "t-test",
    kruskal = "Kruskal-Wallis", anova = "ANOVA")
  list(method = method, name = name, p = p, n = n)
}

# Back-compat alias used internally by older code
ctdna_overall_group_test <- function(data, value, group,
                               method = .o("pairwise_test")) {
  r <- ctdna_run_group_test(data, value, group, method = method)
  r
}

#' All-pairs comparison test
#' @param data,value,group See [ctdna_run_group_test()].
#' @param method `"wilcox"` (default) or `"t"`.
#' @return Data frame: group1, group2, p, n1, n2.
#' @export
ctdna_pairwise_ranksum <- function(data, value, group, method = "wilcox") {
  g <- data[[group]]; v <- data[[value]]
  groups <- as.character(unique(stats::na.omit(g)))
  if (length(groups) < 2) return(NULL)
  pairs <- utils::combn(groups, 2, simplify = FALSE)
  do.call(rbind, lapply(pairs, function(p) {
    a <- v[g == p[1]]; b <- v[g == p[2]]
    na <- length(stats::na.omit(a)); nb <- length(stats::na.omit(b))
    if (na < 2 || nb < 2)
      return(data.frame(group1 = p[1], group2 = p[2], p = NA_real_,
                        n1 = na, n2 = nb))
    pv <- tryCatch({
      if (method == "wilcox") stats::wilcox.test(a, b, exact = FALSE)$p.value
      else stats::t.test(a, b)$p.value
    }, error = function(e) NA_real_)
    data.frame(group1 = p[1], group2 = p[2], p = pv, n1 = na, n2 = nb)
  }))
}


# ---- correlations -----------------------------------------------------------

#' Correlation test with rho, p, n
#'
#' @param x,y Numeric vectors.
#' @param method One of `"spearman"` (default), `"pearson"`, `"kendall"`.
#' @return list(method, name, rho, p, n).
#' @export
ctdna_cor_test <- function(x, y, method = "spearman") {
  ok <- !is.na(x) & !is.na(y); n <- sum(ok)
  if (method == "none" || n < 3)
    return(list(method = method, name = "none",
                rho = NA, p = NA, n = n))
  ct <- suppressWarnings(stats::cor.test(x[ok], y[ok], method = method,
                                         exact = FALSE))
  list(method = method,
       name = switch(method, spearman = "Spearman",
                     pearson = "Pearson", kendall = "Kendall"),
       rho = unname(ct$estimate), p = ct$p.value, n = n)
}


# ---- paired tests (baseline vs each timepoint) ------------------------------

#' Paired test
#' @param x,y Numeric vectors of equal length (paired observations).
#' @param method One of `"paired_wilcox"`, `"paired_t"`, `"wilcox"`, `"t"`.
#' @return list(method, name, p, n).
#' @export
ctdna_paired_test <- function(x, y, method = "paired_wilcox") {
  ok <- !is.na(x) & !is.na(y); n <- sum(ok)
  if (method == "none" || n < 2)
    return(list(method = "none", name = "none", p = NA, n = n))
  paired <- method %in% c("paired_wilcox","paired_t")
  base <- if (paired) sub("paired_", "", method) else method
  p <- tryCatch({
    if (base == "wilcox")
      stats::wilcox.test(x[ok], y[ok], paired = paired, exact = FALSE)$p.value
    else
      stats::t.test(x[ok], y[ok], paired = paired)$p.value
  }, error = function(e) NA_real_)
  list(method = method,
       name = paste0(if (paired) "paired " else "",
                     if (base == "wilcox") "Wilcoxon" else "t-test"),
       p = p, n = n)
}


# ---- concordance ------------------------------------------------------------

#' Cohen's kappa from a contingency table
#' @param tab Square table or matrix.
#' @return Numeric kappa.
#' @export
ctdna_cohen_kappa <- function(tab) {
  tab <- as.matrix(tab)
  common <- intersect(rownames(tab), colnames(tab))
  tab <- tab[common, common, drop = FALSE]
  n <- sum(tab); if (n == 0) return(NA_real_)
  po <- sum(diag(tab)) / n
  pe <- sum(rowSums(tab) * colSums(tab)) / n^2
  if (pe == 1) return(NA_real_)
  (po - pe) / (1 - pe)
}

#' Concordance summary for a 2-way table
#' @param tab Contingency table.
#' @param method One of `"both","kappa","agreement","mcnemar","none"`.
#' @return list with named numeric components.
#' @export
ctdna_concordance_test <- function(tab, method = "both") {
  if (method == "none") return(list(method = "none"))
  agree <- {
    cm <- intersect(rownames(tab), colnames(tab))
    sum(diag(as.matrix(tab)[cm, cm, drop = FALSE])) / sum(tab)
  }
  k <- ctdna_cohen_kappa(tab)
  mcn <- if (method %in% c("mcnemar","both") &&
              nrow(tab) == 2 && ncol(tab) == 2) {
    tryCatch(stats::mcnemar.test(tab)$p.value, error = function(e) NA_real_)
  } else NA_real_
  list(method = method, agreement = agree, kappa = k,
       mcnemar_p = mcn, n = sum(tab))
}


# ---- internal: finalize titles and clearance markers ------------------------

.finalize <- function(p, title = NULL, subtitle = NULL, caption = NULL,
                     xlab = NULL, ylab = NULL,
                     legend_position = .o("legend_position")) {
  l <- list()
  if (!is.null(title))    l$title    <- title
  if (!is.null(subtitle)) l$subtitle <- subtitle
  if (!is.null(caption))  l$caption  <- caption
  if (!is.null(xlab))     l$x        <- xlab
  if (!is.null(ylab))     l$y        <- ylab
  if (length(l)) p <- p + do.call(ggplot2::labs, l)
  if (!is.null(legend_position))
    p <- p + ggplot2::theme(legend.position = legend_position)
  p
}

# Routes a stats label string to its display location.
#  position = "subtitle" : returns list(subtitle = label, caption = caption, on_plot = NULL)
#  position = "caption"  : returns list(subtitle = subtitle, caption = label_or_appended, on_plot = NULL)
#  position = "on_plot"  : returns list(subtitle = subtitle, caption = caption, on_plot = label)
#  position = "none"     : returns list(subtitle = subtitle, caption = caption, on_plot = NULL)
.route_stats <- function(label, position,
                          subtitle = NULL, caption = NULL,
                          wrap_width = 70) {
  position <- match.arg(position,
                         c("subtitle","caption","on_plot","none"))
  out <- list(subtitle = subtitle, caption = caption, on_plot = NULL)
  if (position == "none" || is.null(label) || !nzchar(label)) return(out)
  # Helper: wrap a long stats label across multiple lines using existing
  # separators (`|`, `;`, ` - `) as soft break points.
  wrap_label <- function(s, width) {
    if (nchar(s) <= width) return(s)
    # Replace " - " with a sentinel so it's treated as a break, then split
    s_norm <- gsub(" - ", "\u0001", s, fixed = TRUE)
    parts <- strsplit(s_norm, "\\s*(\\||;|\u0001)\\s*")[[1]]
    out_lines <- character(0); cur <- ""
    for (p in parts) {
      cand <- if (nzchar(cur)) paste(cur, p, sep = "; ") else p
      if (nchar(cand) > width && nzchar(cur)) {
        out_lines <- c(out_lines, cur); cur <- p
      } else cur <- cand
    }
    if (nzchar(cur)) out_lines <- c(out_lines, cur)
    paste(out_lines, collapse = "\n")
  }
  label <- wrap_label(label, wrap_width)
  if (position == "subtitle") {
    out$subtitle <- if (is.null(subtitle) || !nzchar(subtitle)) label
                    else paste(subtitle, label, sep = "\n")
  } else if (position == "caption") {
    out$caption  <- if (is.null(caption) || !nzchar(caption)) label
                    else paste(caption, label, sep = "\n")
  } else if (position == "on_plot") {
    out$on_plot  <- label
  }
  out
}

# Annotate a single overall-stat label inside the plot panel. Uses
# `annotation_custom` with grid::textGrob in NPC coordinates so the label
# is anchored to the panel even when scales are log / transformed and
# never falls outside the panel boundaries (which the older -Inf/Inf
# approach did with clip = 'on').
.annotate_stat <- function(p, label, x_npc = 0.02, y_npc = 0.97,
                            hjust = 0, vjust = 1) {
  if (is.null(label) || !nzchar(label)) return(p)
  grob <- grid::textGrob(
    label = label,
    x = grid::unit(x_npc, "npc"),
    y = grid::unit(y_npc, "npc"),
    hjust = hjust, vjust = vjust,
    gp = grid::gpar(col = "grey20", fontsize = 9))
  p + ggplot2::annotation_custom(grob = grob,
                                  xmin = -Inf, xmax = Inf,
                                  ymin = -Inf, ymax = Inf)
}

# Draw pairwise-comparison brackets above a discrete x-axis boxplot.
# pw_df: data frame with columns group1, group2, p (in plotting order)
# x_levels: factor levels of the x-axis variable (used for positions)
# y_top: log10 (if log=TRUE) or linear top-of-data y-value
# log: TRUE if y-axis is log10
# max_show: cap number of brackets to avoid stacking
.add_pairwise_brackets <- function(p, pw_df, x_levels, y_top,
                                    log = TRUE, max_show = 5) {
  if (is.null(pw_df) || nrow(pw_df) == 0) return(p)
  pw_df <- pw_df[!is.na(pw_df$p), ]
  pw_df <- pw_df[order(pw_df$p), ]
  if (nrow(pw_df) > max_show) pw_df <- utils::head(pw_df, max_show)
  if (nrow(pw_df) == 0) return(p)
  pw_df$x1 <- match(as.character(pw_df$group1), x_levels)
  pw_df$x2 <- match(as.character(pw_df$group2), x_levels)
  pw_df    <- pw_df[!is.na(pw_df$x1) & !is.na(pw_df$x2), ]
  if (nrow(pw_df) == 0) return(p)

  # Stack brackets vertically: bigger stack for more pairs
  step <- if (log) 0.12 else (y_top * 0.08)
  for (i in seq_len(nrow(pw_df))) {
    y_level <- if (log) 10 ^ (log10(y_top) + step * i)
               else y_top + step * i
    p <- p +
      ggplot2::annotate("segment",
                         x = pw_df$x1[i], xend = pw_df$x2[i],
                         y = y_level, yend = y_level,
                         color = "grey30", linewidth = 0.4) +
      ggplot2::annotate("text",
                         x = (pw_df$x1[i] + pw_df$x2[i]) / 2,
                         y = y_level,
                         label = ctdna_pval_label(pw_df$p[i]),
                         vjust = -0.3, size = 3, color = "grey20")
  }
  p
}

.log_clearance <- function() {
  # Dotted horizontal line at the display floor. The label that used to
  # be drawn in-panel is now communicated via the plot caption (set by
  # each calling plot), avoiding overlap with data and with facet ticks.
  list(
    ggplot2::geom_hline(yintercept = .o("display_floor"), linetype = "dotted",
                        color = .o("clearance_color"), linewidth = 0.4),
    ggplot2::scale_y_log10()
  )
}

.pairwise_str <- function(pw, max_show = 3) {
  if (is.null(pw) || nrow(pw) == 0) return("")
  pw <- pw[order(pw$p), ]
  shown <- utils::head(pw, max_show)
  paste(sprintf("%s vs %s: %s", shown$group1, shown$group2,
                vapply(shown$p, ctdna_pval_label, character(1))),
        collapse = "; ")
}
